import { useState, useEffect, useCallback } from 'react'
import { getJournals, addJournal, getParties } from '@/lib/db'
import { useAuth } from '@/contexts/AuthContext'
import { Dialog, Table, Toolbar, SearchBar, StatusBar, Field, toast, fmtAmt } from '@/components/ui'
import { Plus, RefreshCw } from 'lucide-react'

const today=()=>new Date().toISOString().slice(0,10)
const COLS=[
  {key:'voucher_no',label:'Voucher No',width:110},
  {key:'voucher_date',label:'Date',width:90},
  {key:'narration',label:'Narration',width:300},
  {key:'dr',label:'Total Dr ₹',width:130,right:true,render:r=><span className="font-mono text-red-700">{fmtAmt((r.journal_entries||[]).reduce((s,e)=>s+(e.dr_amount||0),0))}</span>},
  {key:'cr',label:'Total Cr ₹',width:130,right:true,render:r=><span className="font-mono text-green-700">{fmtAmt((r.journal_entries||[]).reduce((s,e)=>s+(e.cr_amount||0),0))}</span>},
]
const EMPTY={voucher_date:today(),narration:''}

export default function Journals() {
  const { company }=useAuth(); const cid=company?.id
  const fyStart=company?.fy_start||'2024-04-01', fyEnd=company?.fy_end||'2025-03-31'
  const [rows,setRows]=useState([]); const [loading,setLoading]=useState(true)
  const [from,setFrom]=useState(fyStart); const [to,setTo]=useState(fyEnd)
  const [dlg,setDlg]=useState(false); const [form,setForm]=useState(EMPTY)
  const [entries,setEntries]=useState([{party_id:'',party_name:'',dr_amount:0,cr_amount:0,narration:''}])
  const [saving,setSaving]=useState(false); const [parties,setParties]=useState([])

  const load=useCallback(async()=>{
    if(!cid)return; setLoading(true)
    try{ setRows(await getJournals(cid,{from,to})) }
    catch(e){toast.error(e.message)}
    finally{setLoading(false)}
  },[cid,from,to])
  useEffect(()=>{load()},[load])
  useEffect(()=>{ if(cid) getParties(cid).then(setParties) },[cid])

  const totalDr=entries.reduce((s,e)=>s+(+e.dr_amount||0),0)
  const totalCr=entries.reduce((s,e)=>s+(+e.cr_amount||0),0)
  const balanced=Math.abs(totalDr-totalCr)<0.01&&totalDr>0

  const save=async()=>{
    if(!balanced){toast.error('Dr and Cr must be equal and > 0');return}
    setSaving(true)
    try{
      await addJournal(cid,form,entries.filter(e=>e.party_id||e.dr_amount||e.cr_amount))
      toast.success('Journal saved'); setDlg(false); load()
    }catch(e){toast.error(e.message)}
    finally{setSaving(false)}
  }

  return (
    <div className="flex flex-col h-full">
      <Toolbar>
        <button className="btn-primary" onClick={()=>{setForm({...EMPTY,voucher_date:today()});setEntries([{party_id:'',party_name:'',dr_amount:0,cr_amount:0,narration:''},{party_id:'',party_name:'',dr_amount:0,cr_amount:0,narration:''}]);setDlg(true)}}><Plus size={13}/> New JV</button>
        <button className="btn-secondary" onClick={load}><RefreshCw size={12}/> Refresh</button>
      </Toolbar>
      <SearchBar from={from} to={to} onFrom={setFrom} onTo={setTo}/>
      <Table columns={COLS} rows={rows} loading={loading} emptyMsg="No journal vouchers."/>
      <StatusBar left={`  JVs: ${rows.length}`}/>

      <Dialog open={dlg} onClose={()=>setDlg(false)} title="➕  New Journal Voucher" size="lg">
        <div className="dialog-body space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Date"><input type="date" className="erp-input" value={form.voucher_date} onChange={e=>setForm(p=>({...p,voucher_date:e.target.value}))}/></Field>
            <Field label="Narration"><input className="erp-input" value={form.narration} onChange={e=>setForm(p=>({...p,narration:e.target.value}))} placeholder="Purpose…"/></Field>
          </div>
          <table className="items-table w-full">
            <thead><tr><th>Party / Ledger</th><th className="text-right">Dr ₹</th><th className="text-right">Cr ₹</th><th>Narration</th><th></th></tr></thead>
            <tbody>
              {entries.map((e,i)=>(
                <tr key={i}>
                  <td>
                    <select className="items-table select" value={e.party_id} onChange={ev=>{
                      const p=parties.find(x=>x.id==ev.target.value)
                      setEntries(prev=>{const n=[...prev];n[i]={...n[i],party_id:ev.target.value,party_name:p?.name||''};return n})
                    }}>
                      <option value="">Select…</option>
                      {parties.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </td>
                  {['dr_amount','cr_amount'].map(k=>(
                    <td key={k}>
                      <input type="number" className="td-inp text-right font-mono" value={e[k]||0}
                        onChange={ev=>setEntries(prev=>{const n=[...prev];n[i]={...n[i],[k]:+ev.target.value};return n})}/>
                    </td>
                  ))}
                  <td><input className="td-inp" value={e.narration||''} onChange={ev=>setEntries(prev=>{const n=[...prev];n[i]={...n[i],narration:ev.target.value};return n})}/></td>
                  <td><button onClick={()=>setEntries(p=>p.filter((_,j)=>j!==i))} className="text-red-400 hover:text-red-600 px-1">×</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="flex items-center gap-4">
            <button onClick={()=>setEntries(p=>[...p,{party_id:'',party_name:'',dr_amount:0,cr_amount:0,narration:''}])} className="btn-secondary text-[11px] py-1 px-3">+ Add Row</button>
            <span className={`text-sm font-semibold ${balanced?'text-green-700':'text-red-600'}`}>
              Dr: {fmtAmt(totalDr)}  Cr: {fmtAmt(totalCr)} {balanced?'✓  Balanced':'✗  Not balanced'}
            </span>
          </div>
        </div>
        <div className="dialog-footer">
          <button className="btn-cancel" onClick={()=>setDlg(false)}>Cancel</button>
          <button className="btn-save" onClick={save} disabled={saving||!balanced}>{saving?'Saving…':'💾  Save JV'}</button>
        </div>
      </Dialog>
    </div>
  )
}
