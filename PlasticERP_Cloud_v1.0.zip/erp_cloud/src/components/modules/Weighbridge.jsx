import { useState, useEffect, useCallback } from 'react'
import { getWeighbridgeSlips, addWeighbridgeSlip, deleteWeighbridgeSlip, getParties, getItems } from '@/lib/db'
import { useAuth } from '@/contexts/AuthContext'
import { Dialog, Table, Toolbar, SearchBar, StatusBar, KPIStrip, Field, Select, Confirm, FilterTabs, toast, fmtAmtK, fmt3 } from '@/components/ui'
import { Plus, Trash2, RefreshCw } from 'lucide-react'

const today=()=>new Date().toISOString().slice(0,10)
const COLS=[
  {key:'slip_no',label:'Slip No',width:100},
  {key:'slip_date',label:'Date',width:90},
  {key:'slip_type',label:'Type',width:80,render:r=><span className={r.slip_type==='INWARD'?'badge-blue':'badge-amber'}>{r.slip_type}</span>},
  {key:'party_name',label:'Party',width:180},
  {key:'item_name',label:'Material',width:160},
  {key:'vehicle_no',label:'Vehicle',width:100},
  {key:'gross_wt',label:'Gross KG',width:90,right:true,render:r=>fmt3(r.gross_wt)},
  {key:'tare_wt',label:'Tare KG',width:90,right:true,render:r=>fmt3(r.tare_wt)},
  {key:'net_wt',label:'Net KG',width:90,right:true,render:r=><span className="font-mono font-semibold">{fmt3(r.net_wt)}</span>},
  {key:'actual_wt',label:'Actual KG',width:90,right:true,render:r=><span className="font-mono font-bold text-primary">{fmt3(r.actual_wt)}</span>},
]
const TABS=[{label:'All',value:'ALL'},{label:'Inward',value:'INWARD'},{label:'Outward',value:'OUTWARD'}]
const EMPTY={party_id:'',party_name:'',item_id:'',item_name:'',slip_date:today(),slip_type:'INWARD',vehicle_no:'',gross_wt:0,tare_wt:0,net_wt:0,moisture_pct:2.5,moisture_deduct:0,actual_wt:0,remarks:'',bill_ref:''}

function calc(d){
  const gross=+d.gross_wt||0,tare=+d.tare_wt||0,net=gross-tare
  const mDed=net*((+d.moisture_pct||0)/100), act=net-mDed
  return {...d,net_wt:+net.toFixed(3),moisture_deduct:+mDed.toFixed(3),actual_wt:+act.toFixed(3)}
}

export default function Weighbridge() {
  const { company }=useAuth(); const cid=company?.id
  const fyStart=company?.fy_start||'2024-04-01', fyEnd=company?.fy_end||'2025-03-31'
  const [rows,setRows]=useState([]); const [loading,setLoading]=useState(true)
  const [from,setFrom]=useState(fyStart); const [to,setTo]=useState(fyEnd)
  const [typeF,setTypeF]=useState('ALL'); const [selId,setSelId]=useState(null)
  const [dlg,setDlg]=useState(false); const [form,setForm]=useState(EMPTY)
  const [delDlg,setDelDlg]=useState(false); const [saving,setSaving]=useState(false)
  const [parties,setParties]=useState([]); const [items,setItems]=useState([])

  const load=useCallback(async()=>{
    if(!cid)return; setLoading(true)
    try{ setRows(await getWeighbridgeSlips(cid,{from,to,type:typeF})) }
    catch(e){toast.error(e.message)}
    finally{setLoading(false)}
  },[cid,from,to,typeF])
  useEffect(()=>{load()},[load])
  useEffect(()=>{
    if(!cid)return
    Promise.all([getParties(cid),getItems(cid)]).then(([p,i])=>{setParties(p);setItems(i)})
  },[cid])

  const f=k=>e=>{const next={...form,[k]:e.target?.value??e};setForm(calc(next))}
  const save=async()=>{
    if(!form.party_id){toast.error('Select party');return}
    setSaving(true)
    try{ await addWeighbridgeSlip(cid,form); toast.success('Slip saved'); setDlg(false); load() }
    catch(e){toast.error(e.message)}
    finally{setSaving(false)}
  }
  const doDelete=async()=>{
    try{await deleteWeighbridgeSlip(selId);toast.success('Deleted');setDelDlg(false);setSelId(null);load()}
    catch(e){toast.error(e.message)}
  }

  const totNet=rows.reduce((s,r)=>s+(+r.net_wt||0),0)
  const totAct=rows.reduce((s,r)=>s+(+r.actual_wt||0),0)

  return (
    <div className="flex flex-col h-full">
      <KPIStrip cards={[
        {label:'Total Slips',value:rows.length,sub:'in period'},
        {label:'Total Gross KG',value:fmt3(rows.reduce((s,r)=>s+(+r.gross_wt||0),0)),sub:'gross weight',accent:'slate'},
        {label:'Total Net KG',value:fmt3(totNet),sub:'after tare',accent:'blue',color:'text-primary'},
        {label:'Total Actual KG',value:fmt3(totAct),sub:'after moisture',accent:'green',color:'text-green-700'},
      ]}/>
      <Toolbar>
        <button className="btn-primary" onClick={()=>{setForm({...EMPTY,slip_date:today()});setDlg(true)}}><Plus size={13}/> New Slip</button>
        <button className="btn-danger" onClick={()=>selId&&setDelDlg(true)}><Trash2 size={13}/> Delete</button>
        <button className="btn-secondary" onClick={load}><RefreshCw size={12}/> Refresh</button>
        <div className="ml-2"><FilterTabs tabs={TABS} active={typeF} onChange={setTypeF}/></div>
      </Toolbar>
      <SearchBar from={from} to={to} onFrom={setFrom} onTo={setTo}/>
      <Table columns={COLS} rows={rows} loading={loading} selectedId={selId}
        onRowClick={r=>setSelId(r.id)} emptyMsg="No weighbridge slips."/>
      <StatusBar left={`  Slips: ${rows.length}`} right={`Net: ${fmt3(totNet)} KG  ·  Actual: ${fmt3(totAct)} KG`}/>

      <Dialog open={dlg} onClose={()=>setDlg(false)} title="➕  New Weighbridge Slip" size="md">
        <div className="dialog-body">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Slip Type">
              <select className="erp-select" value={form.slip_type} onChange={f('slip_type')}>
                <option value="INWARD">Inward (Purchase)</option>
                <option value="OUTWARD">Outward (Sale)</option>
              </select>
            </Field>
            <Field label="Date"><input type="date" className="erp-input" value={form.slip_date} onChange={f('slip_date')}/></Field>
            <Field label="Party *">
              <select className="erp-select" value={form.party_id} onChange={e=>{
                const p=parties.find(x=>x.id==e.target.value)
                setForm(prev=>({...prev,party_id:e.target.value,party_name:p?.name||''}))
              }}>
                <option value="">Select Party…</option>
                {parties.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </Field>
            <Field label="Material">
              <select className="erp-select" value={form.item_id} onChange={e=>{
                const it=items.find(x=>x.id==e.target.value)
                const next={...form,item_id:e.target.value,item_name:it?.name||'',moisture_pct:it?.moisture_pct||form.moisture_pct}
                setForm(calc(next))
              }}>
                <option value="">Select…</option>
                {items.map(i=><option key={i.id} value={i.id}>{i.name}</option>)}
              </select>
            </Field>
            <Field label="Vehicle No"><input className="erp-input" value={form.vehicle_no} onChange={f('vehicle_no')}/></Field>
            <Field label="Bill Ref"><input className="erp-input" value={form.bill_ref} onChange={f('bill_ref')}/></Field>
            <div className="form-section">Weight Details</div>
            <Field label="Gross Weight KG">
              <input type="number" step="0.001" className="erp-input font-mono text-right" value={form.gross_wt} onChange={f('gross_wt')} autoFocus/>
            </Field>
            <Field label="Tare Weight KG">
              <input type="number" step="0.001" className="erp-input font-mono text-right" value={form.tare_wt} onChange={f('tare_wt')}/>
            </Field>
            <Field label="Net Weight KG (auto)">
              <input className="erp-input" readOnly value={fmt3(form.net_wt)}/>
            </Field>
            <Field label="Moisture %">
              <input type="number" step="0.1" className="erp-input font-mono text-right" value={form.moisture_pct} onChange={f('moisture_pct')}/>
            </Field>
            <Field label="Actual Weight KG (auto)">
              <input className="erp-input font-bold" readOnly value={fmt3(form.actual_wt)}/>
            </Field>
            <Field label="Remarks"><input className="erp-input" value={form.remarks} onChange={f('remarks')}/></Field>
          </div>
        </div>
        <div className="dialog-footer">
          <button className="btn-cancel" onClick={()=>setDlg(false)}>Cancel</button>
          <button className="btn-save" onClick={save} disabled={saving}>{saving?'Saving…':'💾  Save Slip'}</button>
        </div>
      </Dialog>
      <Confirm open={delDlg} onCancel={()=>setDelDlg(false)} onConfirm={doDelete}
        message={`Delete slip "${rows.find(r=>r.id===selId)?.slip_no}"?`}/>
    </div>
  )
}
