import { useState } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { getSales, getPurchases } from '@/lib/db'
import { Field, toast, fmtAmt, fmt3 } from '@/components/ui'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import { RefreshCw } from 'lucide-react'

const BLUES=['#2563EB','#1D4ED8','#1E40AF','#0369A1','#15803D']

function SummaryTable({ headers, rows }) {
  return (
    <div className="overflow-auto flex-1">
      <table className="erp-table">
        <thead><tr>{headers.map(h=><th key={h}>{h}</th>)}</tr></thead>
        <tbody>
          {rows.map((r,i)=>(
            <tr key={i}>{r.map((c,j)=><td key={j} className={typeof c==="number"||String(c).startsWith("₹")?"text-right font-mono":""}>{c}</td>)}</tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default function Reports() {
  const { company }=useAuth(); const cid=company?.id
  const fyStart=company?.fy_start||'2024-04-01', fyEnd=company?.fy_end||'2025-03-31'
  const [report,setReport]=useState('sales')
  const [from,setFrom]=useState(fyStart); const [to,setTo]=useState(fyEnd)
  const [data,setData]=useState(null); const [loading,setLoading]=useState(false)

  const REPORTS=[
    {key:'sales',label:'Sales Summary'},
    {key:'purchases',label:'Purchase Summary'},
    {key:'monthly',label:'Monthly Trend (Sales)'},
  ]

  const run=async()=>{
    if(!cid)return; setLoading(true); setData(null)
    try{
      if(report==='sales'){
        const rows=await getSales(cid,{from,to})
        const total=rows.reduce((s,r)=>s+(r.grand_total||0),0)
        const outstanding=rows.reduce((s,r)=>s+(r.outstanding||0),0)
        const qty=rows.reduce((s,r)=>s+(r.total_qty||0),0)
        setData({type:'table',
          summary:[
            {label:'Bills',value:rows.length},{label:'Total Qty',value:fmt3(qty)+' KG'},
            {label:'Grand Total',value:fmtAmt(total)},{label:'Outstanding',value:fmtAmt(outstanding)},
          ],
          headers:['Bill No','Date','Party','Qty KG','Amount','Outstanding'],
          rows:rows.map(r=>[r.bill_no,r.bill_date,r.party_name,fmt3(r.total_qty),fmtAmt(r.grand_total),fmtAmt(r.outstanding)])
        })
      } else if(report==='purchases'){
        const rows=await getPurchases(cid,{from,to})
        const total=rows.reduce((s,r)=>s+(r.grand_total||0),0)
        setData({type:'table',
          summary:[{label:'Bills',value:rows.length},{label:'Total',value:fmtAmt(total)}],
          headers:['Bill No','Date','Supplier','Qty KG','Amount'],
          rows:rows.map(r=>[r.bill_no,r.bill_date,r.party_name,fmt3(r.total_qty),fmtAmt(r.grand_total)])
        })
      } else if(report==='monthly'){
        const rows=await getSales(cid,{from,to})
        const monthly={}
        rows.forEach(r=>{const m=(r.bill_date||'???').slice(0,7);monthly[m]=(monthly[m]||0)+(r.grand_total||0)})
        const chartData=Object.entries(monthly).sort().map(([month,value])=>({month,value}))
        setData({type:'bar',chartData,
          headers:['Month','Sales ₹'],
          rows:chartData.map(({month,value})=>[month,fmtAmt(value)])
        })
      }
    }catch(e){toast.error(e.message)}
    finally{setLoading(false)}
  }

  const exportCSV=()=>{
    if(!data)return
    const csv=[data.headers.join(','),...data.rows.map(r=>r.join(','))].join('\n')
    const a=document.createElement('a')
    a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}))
    a.download=`${report}_report.csv`; a.click()
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-end gap-3 px-4 py-3 bg-white border-b border-slate-200 flex-shrink-0 flex-wrap">
        <Field label="Report">
          <select className="erp-select w-52" value={report} onChange={e=>setReport(e.target.value)}>
            {REPORTS.map(r=><option key={r.key} value={r.key}>{r.label}</option>)}
          </select>
        </Field>
        <Field label="From"><input type="date" className="erp-input w-36" value={from} onChange={e=>setFrom(e.target.value)}/></Field>
        <Field label="To"><input type="date" className="erp-input w-36" value={to} onChange={e=>setTo(e.target.value)}/></Field>
        <button className="btn-primary self-end" onClick={run} disabled={loading}>
          <RefreshCw size={13} className={loading?'animate-spin':''}/> {loading?'Loading...':'Run Report'}
        </button>
        {data&&<button className="btn-secondary self-end" onClick={exportCSV}>CSV Export</button>}
      </div>

      {!data&&!loading&&(
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center text-slate-400">
            <div className="text-4xl mb-3">📊</div>
            <div className="font-semibold">Select a report and click Run Report</div>
          </div>
        </div>
      )}

      {data?.summary&&(
        <div className="flex gap-3 px-4 py-3 bg-slate-50 border-b border-slate-200 flex-shrink-0">
          {data.summary.map((s,i)=>(
            <div key={i} className="bg-white border border-slate-200 rounded-lg px-4 py-2 min-w-[120px]">
              <div className="text-[9px] font-bold uppercase text-slate-400">{s.label}</div>
              <div className="text-base font-black text-primary">{s.value}</div>
            </div>
          ))}
        </div>
      )}

      {data?.type==='bar'&&(
        <div className="px-4 py-4 bg-white border-b border-slate-200 flex-shrink-0">
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={data.chartData}>
              <XAxis dataKey="month" tick={{fontSize:10}}/>
              <YAxis tick={{fontSize:10}} tickFormatter={v=>v>=1e5?`${(v/1e5).toFixed(1)}L`:v}/>
              <Tooltip formatter={v=>fmtAmt(v)}/>
              <Bar dataKey="value" fill="#2563EB" radius={[3,3,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {data&&<SummaryTable headers={data.headers} rows={data.rows}/>}
    </div>
  )
}
