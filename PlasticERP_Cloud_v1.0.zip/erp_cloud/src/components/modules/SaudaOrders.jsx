import { useState, useEffect, useCallback } from 'react'
import { getSaudaOrders, addSaudaOrder, updateSaudaOrder, deleteSaudaOrder, getParties, getItems } from '@/lib/db'
import { useAuth } from '@/contexts/AuthContext'
import { Dialog, Table, Toolbar, StatusBar, Field, Select, Confirm, FilterTabs, toast, fmtAmt } from '@/components/ui'
import { Plus, Edit2, Trash2, RefreshCw } from 'lucide-react'

const today=()=>new Date().toISOString().slice(0,10)
const COLS=[
  {key:'order_no',label:'Order No',width:100},
  {key:'order_date',label:'Date',width:90},
  {key:'party_name',label:'Buyer',width:200},
  {key:'status',label:'Status',width:90,render:r=>{
    const c={PENDING:'badge-amber',PARTIAL:'badge-blue',COMPLETE:'badge-green',CANCELLED:'badge-red'}
    return <span className={c[r.status]||'badge-slate'}>{r.status}</span>
  }},
  {key:'items_summary',label:'Items',width:250,render:r=>(r.sauda_items||[]).map(i=>`${i.item_name} ${i.order_qty}KG`).join(', ')},
  {key:'total',label:'Total ₹',width:110,right:true,render:r=><span className="font-mono">{fmtAmt((r.sauda_items||[]).reduce((s,i)=>s+(+i.order_qty||0)*(+i.rate||0),0))}</span>},
]
const TABS=[{label:'All',value:'ALL'},{label:'Pending',value:'PENDING'},{label:'Partial',value:'PARTIAL'},{label:'Complete',value:'COMPLETE'}]
const EMPTY={party_id:'',party_name:'',order_date:today(),remarks:'',status:'PENDING'}
const EMPTY_ITEM={item_id:'',item_name:'',order_qty:0,rate:0}

export default function SaudaOrders() {
  const { company }=useAuth(); const cid=company?.id
  const [rows,setRows]=useState([]); const [loading,setLoading]=useState(true)
  const [statusF,setStatusF]=useState('ALL'); const [selId,setSelId]=useState(null)
  const [dlg,setDlg]=useState(false); const [editing,setEditing]=useState(null)
  const [form,setForm]=useState(EMPTY); const [items_,setItems_]=useState([{...EMPTY_ITEM}])
  const [delDlg,setDelDlg]=useState(false); const [saving,setSaving]=useState(false)
  const [parties,setParties]=useState([]); const [materials,setMaterials]=useState([])

  const load=useCallback(async()=>{
    if(!cid)return; setLoading(true)
    try{ setRows(await getSaudaOrders(cid,{status:statusF})) }
    catch(e){toast.error(e.message)}
    finally{setLoading(false)}
  },[cid,statusF])
  useEffect(()=>{load()},[load])
  useEffect(()=>{
    if(!cid)return
    Promise.all([getParties(cid,'','BUYER'),getItems(cid)]).then(([p,i])=>{setParties(p);setMaterials(i)})
  },[cid])

  const openAdd=()=>{setEditing(null);setForm({...EMPTY,order_date:today()});setItems_([{...EMPTY_ITEM}]);setDlg(true)}
  const openEdit=()=>{
    const r=rows.find(x=>x.id===selId); if(!r){toast.info('Select an order');return}
    setEditing(r)
    setForm({party_id:r.party_id||'',party_name:r.party_name||'',order_date:r.order_date||today(),remarks:r.remarks||'',status:r.status||'PENDING'})
    setItems_(r.sauda_items?.length?r.sauda_items:[{...EMPTY_ITEM}])
    setDlg(true)
  }
  const h=k=>e=>setForm(p=>({...p,[k]:e.target?.value??e}))
  const save=async()=>{
    if(!form.party_id){toast.error('Select buyer');return}
    if(items_.every(i=>!i.item_id)){toast.error('Add at least one item');return}
    setSaving(true)
    try{
      const validItems=items_.filter(i=>i.item_id).map(i=>({...i,balance_qty:(+i.order_qty)-(+i.delivered_qty||0)}))
      if(editing){await updateSaudaOrder(editing.id,form,validItems);toast.success('Updated')}
      else{await addSaudaOrder(cid,form,validItems);toast.success('Order saved')}
      setDlg(false);load()
    }catch(e){toast.error(e.message)}
    finally{setSaving(false)}
  }
  const doDelete=async()=>{
    try{await deleteSaudaOrder(selId);toast.success('Deleted');setDelDlg(false);setSelId(null);load()}
    catch(e){toast.error(e.message)}
  }

  return (
    <div className="flex flex-col h-full">
      <Toolbar>
        <button className="btn-primary" onClick={openAdd}><Plus size={13}/> New Order</button>
        <button className="btn-secondary" onClick={openEdit}><Edit2 size={13}/> Edit</button>
        <button className="btn-danger" onClick={()=>selId&&setDelDlg(true)}><Trash2 size={13}/> Delete</button>
        <button className="btn-secondary" onClick={load}><RefreshCw size={12}/> Refresh</button>
        <div className="ml-2"><FilterTabs tabs={TABS} active={statusF} onChange={setStatusF}/></div>
      </Toolbar>
      <Table columns={COLS} rows={rows} loading={loading} selectedId={selId}
        onRowClick={r=>setSelId(r.id)} onRowDblClick={r=>{setSelId(r.id);setTimeout(openEdit,10)}}
        emptyMsg="No sauda orders. Click + New Order."/>
      <StatusBar left={`  Orders: ${rows.length}`}/>

      <Dialog open={dlg} onClose={()=>setDlg(false)} title={editing?'✏️  Edit Sauda Order':'➕  New Sauda Order'} size="lg">
        <div className="dialog-body space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Buyer *">
              <select className="erp-select" value={form.party_id} onChange={e=>{
                const p=parties.find(x=>x.id==e.target.value)
                setForm(prev=>({...prev,party_id:e.target.value,party_name:p?.name||''}))
              }}>
                <option value="">Select Buyer…</option>
                {parties.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </Field>
            <Field label="Order Date"><input type="date" className="erp-input" value={form.order_date} onChange={h('order_date')}/></Field>
            {editing&&<Field label="Status"><Select value={form.status} onChange={v=>setForm(p=>({...p,status:v}))} options={['PENDING','PARTIAL','COMPLETE','CANCELLED']} placeholder=""/></Field>}
            <Field label="Remarks" className={editing?'':'col-span-2'}><input className="erp-input" value={form.remarks} onChange={h('remarks')}/></Field>
          </div>
          <table className="items-table w-full">
            <thead><tr><th>Material</th><th className="text-right">Order Qty KG</th><th className="text-right">Rate ₹/KG</th><th className="text-right">Amount ₹</th><th></th></tr></thead>
            <tbody>
              {items_.map((r,i)=>(
                <tr key={i}>
                  <td>
                    <select className="items-table select" value={r.item_id||''} onChange={e=>{
                      const it=materials.find(x=>x.id==e.target.value)
                      setItems_(p=>{const n=[...p];n[i]={...n[i],item_id:e.target.value,item_name:it?.name||'',rate:it?.rate||n[i].rate};return n})
                    }}>
                      <option value="">Select…</option>
                      {materials.map(m=><option key={m.id} value={m.id}>{m.name}</option>)}
                    </select>
                  </td>
                  {['order_qty','rate'].map(k=>(
                    <td key={k}>
                      <input type="number" className="td-inp text-right font-mono" value={r[k]||0}
                        onChange={e=>setItems_(p=>{const n=[...p];n[i]={...n[i],[k]:+e.target.value};return n})}/>
                    </td>
                  ))}
                  <td className="text-right font-mono td-ro">{fmtAmt((+r.order_qty||0)*(+r.rate||0))}</td>
                  <td><button onClick={()=>setItems_(p=>p.filter((_,j)=>j!==i))} className="text-red-400 hover:text-red-600 px-1">×</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <button onClick={()=>setItems_(p=>[...p,{...EMPTY_ITEM}])} className="btn-secondary text-[11px] py-1 px-3">+ Add Item</button>
        </div>
        <div className="dialog-footer">
          <button className="btn-cancel" onClick={()=>setDlg(false)}>Cancel</button>
          <button className="btn-save" onClick={save} disabled={saving}>{saving?'Saving…':'💾  Save'}</button>
        </div>
      </Dialog>
      <Confirm open={delDlg} onCancel={()=>setDelDlg(false)} onConfirm={doDelete}
        message={`Delete order "${rows.find(r=>r.id===selId)?.order_no}"?`}/>
    </div>
  )
}
