import { useState, useEffect } from 'react'
import { getLedger, getParties } from '@/lib/db'
import { useAuth } from '@/contexts/AuthContext'
import { Table, Toolbar, StatusBar, KPIStrip, Field, toast, fmtAmt, fmtAmtK } from '@/components/ui'
import { RefreshCw } from 'lucide-react'

const COLS=[
  {key:'date',label:'Date',width:90},
  {key:'particulars',label:'Particulars',width:280},
  {key:'dr',label:'Dr ₹',width:120,right:true,render:r=>r.dr>0?<span className="font-mono text-red-700">{fmtAmt(r.dr)}</span>:'—'},
  {key:'cr',label:'Cr ₹',width:120,right:true,render:r=>r.cr>0?<span className="font-mono text-green-700">{fmtAmt(r.cr)}</span>:'—'},
  {key:'balance',label:'Balance ₹',width:130,right:true,render:r=><span className={`font-mono font-semibold ${r.balance>=0?'text-red-700':'text-green-700'}`}>{fmtAmt(Math.abs(r.balance))} {r.balance>=0?'Dr':'Cr'}</span>},
]

export default function Ledger() {
  const { company }=useAuth(); const cid=company?.id
  const fyStart=company?.fy_start||'2024-04-01', fyEnd=company?.fy_end||'2025-03-31'
  const [parties,setParties]=useState([]); const [partyId,setPartyId]=useState('')
  const [from,setFrom]=useState(fyStart); const [to,setTo]=useState(fyEnd)
  const [rows,setRows]=useState([]); const [loading,setLoading]=useState(false)

  useEffect(()=>{ if(cid) getParties(cid).then(setParties) },[cid])
  const load=async()=>{
    if(!partyId){toast.info('Select a party');return}
    setLoading(true)
    try{ setRows(await getLedger(cid,partyId,from,to)) }
    catch(e){toast.error(e.message)}
    finally{setLoading(false)}
  }
  useEffect(()=>{ if(partyId) load() },[partyId,from,to])

  const totalDr=rows.reduce((s,r)=>s+(r.dr||0),0)
  const totalCr=rows.reduce((s,r)=>s+(r.cr||0),0)
  const closing=rows.length>0?rows[rows.length-1].balance:0
  const partyName=parties.find(p=>p.id==partyId)?.name||''

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-end gap-3 px-4 py-3 bg-white border-b border-slate-200 flex-shrink-0 flex-wrap">
        <Field label="Select Party">
          <select className="erp-select w-72" value={partyId} onChange={e=>setPartyId(e.target.value)}>
            <option value="">Choose a party…</option>
            {parties.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </Field>
        <Field label="From"><input type="date" className="erp-input w-36" value={from} onChange={e=>setFrom(e.target.value)}/></Field>
        <Field label="To"><input type="date" className="erp-input w-36" value={to} onChange={e=>setTo(e.target.value)}/></Field>
        <button className="btn-primary self-end" onClick={load}><RefreshCw size={13}/> Load</button>
      </div>
      {partyId&&<KPIStrip cards={[
        {label:'Party',value:partyName.slice(0,18),sub:'ledger account',accent:''},
        {label:'Total Dr ₹',value:fmtAmtK(totalDr),sub:'sales / outflow',accent:'red',color:'text-red-700'},
        {label:'Total Cr ₹',value:fmtAmtK(totalCr),sub:'receipts / inflow',accent:'green',color:'text-green-700'},
        {label:'Closing Balance',value:fmtAmtK(Math.abs(closing)),sub:closing>=0?'You are owed (Dr)':'You owe (Cr)',accent:closing>=0?'amber':'blue',color:closing>=0?'text-red-700':'text-green-700'},
      ]}/>}
      <Table columns={COLS} rows={rows} loading={loading}
        emptyMsg={partyId?"No transactions in this period.":"← Select a party to view ledger."}/>
      <StatusBar left={`  Entries: ${rows.length}`}
        right={rows.length>0?`Closing: ${fmtAmt(Math.abs(closing))} ${closing>=0?'Dr':'Cr'}`:''}/>
    </div>
  )
}
