import { useState, useEffect, useCallback } from 'react'
import { getItems, addItem, updateItem, deleteItem, getMasterList } from '@/lib/db'
import { useAuth } from '@/contexts/AuthContext'
import { Dialog, Table, Toolbar, SearchBar, StatusBar, Field, Select, Confirm, toast } from '@/components/ui'
import { Plus, Edit2, Trash2, RefreshCw } from 'lucide-react'

const COLS=[
  {key:'code',label:'Code',width:80},
  {key:'name',label:'Material Name',width:200},
  {key:'colour',label:'Colour',width:100},
  {key:'plastic_type',label:'Type',width:80},
  {key:'rate',label:'Rate ₹/KG',width:90,right:true,render:r=>`₹${r.rate||0}`},
  {key:'moisture_pct',label:'Moist%',width:70,right:true,render:r=>`${r.moisture_pct||0}%`},
  {key:'unit',label:'Unit',width:60},
  {key:'hsn',label:'HSN',width:100},
]
const EMPTY={name:'',colour:'',plastic_type:'PP',rate:0,moisture_pct:2.5,hsn:'39151000',unit:'KG',form:'Loose',quality_grade:'A Grade',remarks:''}

export default function Items() {
  const { company }=useAuth(); const cid=company?.id
  const [rows,setRows]=useState([]); const [loading,setLoading]=useState(true)
  const [search,setSearch]=useState(''); const [selId,setSelId]=useState(null)
  const [dlg,setDlg]=useState(false); const [editing,setEditing]=useState(null)
  const [form,setForm]=useState(EMPTY); const [delDlg,setDelDlg]=useState(false)
  const [saving,setSaving]=useState(false)
  const [plasticTypes,setPT]=useState(['PP','HDPE','LDPE','PET','ABS','PVC','Nylon','PC','Other'])
  const [colours,setCols]=useState(['Natural','Black','White','Mixed','Blue','Red','Yellow'])
  const [forms,setForms]=useState(['Loose','Baled','Granules','Powder','Flakes','Regrind'])
  const [qualities,setQuals]=useState(['A Grade','B Grade','C Grade','Mixed','Rejection'])

  const load=useCallback(async()=>{
    if(!cid)return; setLoading(true)
    try{
      const [r,pt,col,fm,q]=await Promise.all([
        getItems(cid,search),
        getMasterList(cid,'PLASTIC_TYPE'),getMasterList(cid,'COLOUR'),
        getMasterList(cid,'FORM'),getMasterList(cid,'QUALITY'),
      ])
      setRows(r); if(pt.length)setPT(pt); if(col.length)setCols(col)
      if(fm.length)setForms(fm); if(q.length)setQuals(q)
    }catch(e){toast.error(e.message)}
    finally{setLoading(false)}
  },[cid,search])
  useEffect(()=>{load()},[load])

  const openAdd=()=>{setEditing(null);setForm(EMPTY);setDlg(true)}
  const openEdit=()=>{
    const r=rows.find(x=>x.id===selId)
    if(!r){toast.info('Select an item');return}
    setEditing(r)
    setForm({name:r.name||'',colour:r.colour||'',plastic_type:r.plastic_type||'PP',
      rate:r.rate||0,moisture_pct:r.moisture_pct||2.5,hsn:r.hsn||'',
      unit:r.unit||'KG',form:r.form||'Loose',quality_grade:r.quality_grade||'A Grade',remarks:r.remarks||''})
    setDlg(true)
  }
  const f=k=>e=>setForm(p=>({...p,[k]:e.target?.value??e}))
  const save=async()=>{
    if(!form.name.trim()){toast.error('Name required');return}
    setSaving(true)
    try{
      const data={...form,rate:+form.rate||0,moisture_pct:+form.moisture_pct||0}
      if(editing){await updateItem(editing.id,data);toast.success('Item updated')}
      else{await addItem(cid,data);toast.success('Item added')}
      setDlg(false);load()
    }catch(e){toast.error(e.message)}
    finally{setSaving(false)}
  }
  const doDelete=async()=>{
    try{await deleteItem(selId);toast.success('Deleted');setDelDlg(false);setSelId(null);load()}
    catch(e){toast.error(e.message)}
  }

  return (
    <div className="flex flex-col h-full">
      <Toolbar>
        <button className="btn-primary" onClick={openAdd}><Plus size={13}/> New Item</button>
        <button className="btn-secondary" onClick={openEdit}><Edit2 size={13}/> Edit</button>
        <button className="btn-danger" onClick={()=>selId&&setDelDlg(true)}><Trash2 size={13}/> Delete</button>
        <button className="btn-secondary" onClick={load}><RefreshCw size={12}/> Refresh</button>
      </Toolbar>
      <SearchBar search={search} onSearch={setSearch}/>
      <Table columns={COLS} rows={rows} loading={loading} selectedId={selId}
        onRowClick={r=>setSelId(r.id)} onRowDblClick={r=>{setSelId(r.id);setTimeout(openEdit,10)}}
        emptyMsg="No items. Click + New Item."/>
      <StatusBar left={`  Items: ${rows.length}`}/>

      <Dialog open={dlg} onClose={()=>setDlg(false)}
        title={editing?`✏️  Edit — ${editing.name}`:'➕  New Material / Item'}>
        <div className="dialog-body">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Material Name *" className="col-span-2">
              <input className="erp-input" value={form.name} onChange={f('name')} autoFocus placeholder="PP Natural / HDPE Black…"/>
            </Field>
            <Field label="Colour">
              <select className="erp-select" value={form.colour} onChange={f('colour')}>
                <option value="">Select…</option>
                {colours.map(c=><option key={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Plastic Type">
              <select className="erp-select" value={form.plastic_type} onChange={f('plastic_type')}>
                {plasticTypes.map(c=><option key={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Rate ₹/KG">
              <input type="number" className="erp-input font-mono text-right" value={form.rate} onChange={f('rate')}/>
            </Field>
            <Field label="Moisture %">
              <input type="number" step="0.1" className="erp-input font-mono text-right" value={form.moisture_pct} onChange={f('moisture_pct')}/>
            </Field>
            <Field label="HSN Code"><input className="erp-input" value={form.hsn} onChange={f('hsn')} placeholder="39151000"/></Field>
            <Field label="Unit">
              <Select value={form.unit} onChange={v=>setForm(p=>({...p,unit:v}))} options={['KG','MT','PCS','BAG','LOT']} placeholder=""/>
            </Field>
            <Field label="Form / State">
              <select className="erp-select" value={form.form} onChange={f('form')}>
                {forms.map(c=><option key={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Quality Grade">
              <select className="erp-select" value={form.quality_grade} onChange={f('quality_grade')}>
                {qualities.map(c=><option key={c}>{c}</option>)}
              </select>
            </Field>
          </div>
        </div>
        <div className="dialog-footer">
          <button className="btn-cancel" onClick={()=>setDlg(false)}>Cancel</button>
          <button className="btn-save" onClick={save} disabled={saving}>{saving?'Saving…':'💾  Save'}</button>
        </div>
      </Dialog>
      <Confirm open={delDlg} onCancel={()=>setDelDlg(false)} onConfirm={doDelete}
        message={`Delete "${rows.find(r=>r.id===selId)?.name}"?`}/>
    </div>
  )
}
