// src/components/modules/Dashboard.jsx
import { useEffect, useState } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { getDashboardStats } from '@/lib/db'
import { KPICard, Loading, fmtAmtK, fmtAmt } from '@/components/ui'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Legend } from 'recharts'
import { useNavigate } from 'react-router-dom'

const QUICK_ACTIONS = [
  ['🧾 New Sale',    '/sales'],     ['🛒 New Purchase','/purchases'],
  ['💸 Payment',     '/payment'],   ['📋 Sales Order', '/sauda'],
  ['⚖️ Weighbridge', '/weighbridge'],['📄 Quotation',  '/quotations'],
]

export default function Dashboard() {
  const { company } = useAuth()
  const [stats,   setStats]   = useState(null)
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    if (!company) return
    getDashboardStats(company.id, company.fy_start||'2024-04-01', company.fy_end||'2025-03-31')
      .then(setStats).catch(console.error).finally(()=>setLoading(false))
  }, [company])

  if (loading) return <div className="p-6"><Loading text="Loading dashboard…"/></div>
  const s = stats || {}

  const chartData = (s.monthly||[]).map(([m,v]) => ({
    month: ['Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar'][parseInt(m.slice(5))-1] || m.slice(5),
    sales: Math.round(v)
  }))

  return (
    <div className="p-4 space-y-4 overflow-auto">

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KPICard icon="🧾" label="Total Sales (FY)"    value={fmtAmtK(s.totalSales||0)}     accent="blue"/>
        <KPICard icon="⏳" label="Outstanding"         value={fmtAmtK(s.outstanding||0)}    accent="red"/>
        <KPICard icon="✅" label="Total Receipts"      value={fmtAmtK(s.totalReceipts||0)}  accent="green"/>
        <KPICard icon="🛒" label="Total Purchases"     value={fmtAmtK(s.totalPurchases||0)} accent="amber"/>
        <KPICard icon="📦" label="Total Qty (FY)"      value={`${(s.totalQty||0).toFixed(0)} KG`} accent="slate"/>
        <KPICard icon="👥" label="Parties"             value={s.totalParties||0}             accent="slate"/>
        <KPICard icon="🏷" label="Materials"           value={s.totalItems||0}               accent="slate"/>
        <KPICard icon="💸" label="Total Payments Out"  value={fmtAmtK(s.totalPayments||0)}  accent="red"/>
      </div>

      <div className="grid grid-cols-3 gap-3">

        {/* Monthly Sales Chart */}
        <div className="card-plain p-4 col-span-2">
          <div className="text-[11px] font-bold text-primary uppercase tracking-wide mb-3">
            📈  Monthly Sales — {company?.fy_start?.slice(0,4)}-{company?.fy_end?.slice(2,4)}
          </div>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={chartData} barSize={28}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9"/>
                <XAxis dataKey="month" tick={{ fontSize:10, fill:'#94A3B8' }}/>
                <YAxis tick={{ fontSize:9, fill:'#94A3B8' }} tickFormatter={v=>v>=1e5?`₹${(v/1e5).toFixed(0)}L`:v}/>
                <Tooltip formatter={v=>[`₹${(+v).toLocaleString('en-IN')}`, 'Sales']}
                  contentStyle={{ background:'#1E293B', border:'none', borderRadius:6, color:'#E2E8F0', fontSize:11 }}/>
                <Bar dataKey="sales" fill="#2563EB" radius={[4,4,0,0]}/>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-44 flex items-center justify-center text-slate-400 text-sm">
              No sales data yet for this financial year
            </div>
          )}
        </div>

        {/* Quick actions + company info */}
        <div className="space-y-3">
          <div className="card-plain p-4">
            <div className="text-[11px] font-bold text-primary uppercase tracking-wide mb-3">⚡ Quick Actions</div>
            <div className="grid grid-cols-2 gap-1.5">
              {QUICK_ACTIONS.map(([label, path]) => (
                <button key={path} onClick={()=>navigate(path)}
                  className="text-left px-2.5 py-2 bg-slate-50 hover:bg-primary-lighter hover:text-primary
                             border border-slate-200 hover:border-primary rounded-md text-[11px] font-medium transition-colors">
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="card-plain p-4">
            <div className="text-[11px] font-bold text-primary uppercase tracking-wide mb-3">🏢 Company</div>
            <div className="space-y-1.5 text-[11px]">
              {[
                ['Name',   company?.name   || '—'],
                ['GSTIN',  company?.gstin  || '—'],
                ['City',   company?.city   || '—'],
                ['Phone',  company?.phone  || '—'],
                ['FY',     company?.fy_start ? `${company.fy_start} → ${company.fy_end}` : '—'],
              ].map(([k,v]) => (
                <div key={k} className="flex gap-2">
                  <span className="text-slate-400 w-14 shrink-0">{k}:</span>
                  <span className="text-slate-800 font-medium truncate">{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
