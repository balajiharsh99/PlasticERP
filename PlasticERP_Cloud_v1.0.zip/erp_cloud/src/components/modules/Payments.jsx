import { useState, useEffect, useCallback } from 'react'
import { getPayments, addPayment, deletePayment, getParties } from '@/lib/db'
import { useAuth } from '@/contexts/AuthContext'
import { Dialog, Table, Toolbar, SearchBar, StatusBar, KPIStrip, Field, Select, Confirm, FilterTabs, toast, fmtAmt, fmtAmtK } from '@/components/ui'
import { Plus, Trash2, RefreshCw } from 'lucide-react'

const today=()=>new Date().toISOString().slice(0,10)
const COLS=[
  {key:'voucher_no',label:'Voucher No',width:110},
  {key:'voucher_date',label:'Date',width:90},
  {key:'voucher_type',label:'Type',width:90,render:r=><span className={r.voucher_type==='RECEIPT'?'badge-green':'badge-red'}>{r.voucher_type}</span>},
  {key:'party_name',label:'Party',width:200},
  {key:'amount',label:'Amount ₹',width:120,right:true,render:r=><span className="font-mono">{fmtAmt(r.amount)}</span>},
  {key:'narration',label:'Narration',width:200},
  {key:'cheque_no',label:'Cheque No',width:110},
]
const TABS=[{label:'All',value:'ALL'},{label:'Receipts',value:'RECEIPT'},{label:'Payments',value:'PAYMENT'}]
const EMPTY={party_id:'',party_name:'',voucher_date:today(),voucher_type:'RECEIPT',amount:0,narration:'',cheque_no:'',settlement_type:'AGAINST_BILL'}

export default function Payments() {
  const { company }=useAuth(); const cid=company?.id
  const fyStart=company?.fy_start||'2024-04-01', fyEnd=company?.fy_end||'2025-03-31'
  const [rows,setRows]=useState([]); const [loading,setLoading]=useState(true)
  const [from,setFrom]=useState(fyStart); const [to,setTo]=useState(fyEnd)
  const [typeF,setTypeF]=useState('ALL'); const [selId,setSelId]=useState(null)
  const [dlg,setDlg]=useState(false); const [form,setForm]=useState(EMPTY)
  const [delDlg,setDelDlg]=useState(false); const [saving,setSaving]=useState(false)
  const [parties,setParties]=useState([])

  const load=useCallback(async()=>{
    if(!cid)return; setLoading(true)
    try{ setRows(await getPayments(cid,{from,to,type:typeF})) }
    catch(e){toast.error(e.message)}
    finally{setLoading(false)}
  },[cid,from,to,typeF])
  useEffect(()=>{load()},[load])
  useEffect(()=>{ if(cid) getParties(cid).then(setParties) },[cid])

  const f=k=>e=>setForm(p=>({...p,[k]:e.target?.value??e}))
  const save=async()=>{
    if(!form.party_id){toast.error('Select party');return}
    if(!form.amount||+form.amount<=0){toast.error('Enter amount');return}
    setSaving(true)
    try{
      const d={...form,amount:+form.amount}
      await addPayment(cid,d); toast.success('Saved')
      setDlg(false); load()
    }catch(e){toast.error(e.message)}
    finally{setSaving(false)}
  }
  const doDelete=async()=>{
    try{await deletePayment(selId);toast.success('Deleted');setDelDlg(false);setSelId(null);load()}
    catch(e){toast.error(e.message)}
  }

  const rec=rows.filter(r=>r.voucher_type==='RECEIPT').reduce((s,r)=>s+(r.amount||0),0)
  const pay=rows.filter(r=>r.voucher_type==='PAYMENT').reduce((s,r)=>s+(r.amount||0),0)

  return (
    <div className="flex flex-col h-full">
      <KPIStrip cards={[
        {label:'Total Vouchers',value:rows.length,sub:'in period'},
        {label:'Receipts ₹',value:fmtAmtK(rec),sub:'money received',accent:'green',color:'text-green-700'},
        {label:'Payments ₹',value:fmtAmtK(pay),sub:'money paid',accent:'red',color:'text-red-700'},
        {label:'Net Flow ₹',value:fmtAmtK(rec-pay),sub:'net position',accent:'blue',color:rec>=pay?'text-green-700':'text-red-700'},
      ]}/>
      <Toolbar>
        <button className="btn-primary" onClick={()=>{setForm({...EMPTY,voucher_date:today()});setDlg(true)}}><Plus size={13}/> New Voucher</button>
        <button className="btn-danger" onClick={()=>selId&&setDelDlg(true)}><Trash2 size={13}/> Delete</button>
        <button className="btn-secondary" onClick={load}><RefreshCw size={12}/> Refresh</button>
        <div className="ml-2"><FilterTabs tabs={TABS} active={typeF} onChange={setTypeF}/></div>
      </Toolbar>
      <SearchBar from={from} to={to} onFrom={setFrom} onTo={setTo}/>
      <Table columns={COLS} rows={rows} loading={loading} selectedId={selId}
        onRowClick={r=>setSelId(r.id)} emptyMsg="No vouchers in this period."/>
      <StatusBar left={`  Vouchers: ${rows.length}`}
        right={`Receipts: ${fmtAmt(rec)}  ·  Payments: ${fmtAmt(pay)}`}/>

      <Dialog open={dlg} onClose={()=>setDlg(false)} title="➕  New Payment / Receipt Voucher">
        <div className="dialog-body">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Type">
              <select className="erp-select" value={form.voucher_type} onChange={f('voucher_type')}>
                <option value="RECEIPT">Receipt (Money In)</option>
                <option value="PAYMENT">Payment (Money Out)</option>
              </select>
            </Field>
            <Field label="Date">
              <input type="date" className="erp-input" value={form.voucher_date} onChange={f('voucher_date')}/>
            </Field>
            <Field label="Party *" className="col-span-2">
              <select className="erp-select" value={form.party_id} onChange={e=>{
                const p=parties.find(x=>x.id==e.target.value)
                setForm(prev=>({...prev,party_id:e.target.value,party_name:p?.name||''}))
              }}>
                <option value="">Select Party…</option>
                {parties.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </Field>
            <Field label="Amount ₹ *">
              <input type="number" className="erp-input font-mono text-right" value={form.amount} onChange={f('amount')} autoFocus/>
            </Field>
            <Field label="Settlement">
              <Select value={form.settlement_type} onChange={v=>setForm(p=>({...p,settlement_type:v}))}
                options={['AGAINST_BILL','ADVANCE','REFUND']} placeholder=""/>
            </Field>
            <Field label="Cheque / UTR No">
              <input className="erp-input" value={form.cheque_no} onChange={f('cheque_no')} placeholder="Optional"/>
            </Field>
            <Field label="Narration">
              <input className="erp-input" value={form.narration} onChange={f('narration')} placeholder="Purpose…"/>
            </Field>
          </div>
        </div>
        <div className="dialog-footer">
          <button className="btn-cancel" onClick={()=>setDlg(false)}>Cancel</button>
          <button className="btn-save" onClick={save} disabled={saving}>{saving?'Saving…':'💾  Save'}</button>
        </div>
      </Dialog>
      <Confirm open={delDlg} onCancel={()=>setDelDlg(false)} onConfirm={doDelete}
        message={`Delete voucher "${rows.find(r=>r.id===selId)?.voucher_no}"?`}/>
    </div>
  )
}
