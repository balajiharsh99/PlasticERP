import { useState, useEffect } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { updateCompany } from '@/lib/db'
import { Field, toast } from '@/components/ui'
import { Save } from 'lucide-react'

export default function Settings() {
  const { company, refreshProfile }=useAuth()
  const [form,setForm]=useState({name:'',gstin:'',pan:'',address:'',city:'',state:'Gujarat',phone:'',email:'',fy_start:'',fy_end:''})
  const [saving,setSaving]=useState(false)

  useEffect(()=>{
    if(company) setForm({
      name:company.name||'',gstin:company.gstin||'',pan:company.pan||'',
      address:company.address||'',city:company.city||'',state:company.state||'Gujarat',
      phone:company.phone||'',email:company.email||'',
      fy_start:company.fy_start||'2024-04-01',fy_end:company.fy_end||'2025-03-31',
    })
  },[company])

  const f=k=>e=>setForm(p=>({...p,[k]:e.target.value}))
  const save=async()=>{
    setSaving(true)
    try{
      await updateCompany(company.id,form)
      await refreshProfile()
      toast.success('Company settings saved')
    }catch(e){toast.error(e.message)}
    finally{setSaving(false)}
  }

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <div className="max-w-2xl mx-auto w-full px-6 py-6">
        <div className="card p-6 space-y-4">
          <div className="text-lg font-bold text-primary mb-2">Company Settings</div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Company Name *" className="col-span-2">
              <input className="erp-input" value={form.name} onChange={f('name')}/>
            </Field>
            <Field label="GSTIN"><input className="erp-input" value={form.gstin} onChange={f('gstin')} placeholder="24AAAAA0000A1Z5"/></Field>
            <Field label="PAN"><input className="erp-input" value={form.pan} onChange={f('pan')}/></Field>
            <Field label="Phone"><input className="erp-input" value={form.phone} onChange={f('phone')}/></Field>
            <Field label="Email"><input type="email" className="erp-input" value={form.email} onChange={f('email')}/></Field>
            <Field label="Address" className="col-span-2"><input className="erp-input" value={form.address} onChange={f('address')}/></Field>
            <Field label="City"><input className="erp-input" value={form.city} onChange={f('city')}/></Field>
            <Field label="State"><input className="erp-input" value={form.state} onChange={f('state')}/></Field>
            <div className="form-section">Financial Year</div>
            <Field label="FY Start"><input type="date" className="erp-input" value={form.fy_start} onChange={f('fy_start')}/></Field>
            <Field label="FY End"><input type="date" className="erp-input" value={form.fy_end} onChange={f('fy_end')}/></Field>
          </div>
          <div className="pt-4 flex justify-end">
            <button className="btn-save" onClick={save} disabled={saving}><Save size={14}/>{saving?'Saving...':' Save Settings'}</button>
          </div>
        </div>
      </div>
    </div>
  )
}
