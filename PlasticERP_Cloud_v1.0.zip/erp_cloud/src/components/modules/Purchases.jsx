import { useState, useEffect, useCallback } from 'react'
import { getPurchases, getPurchaseById, addPurchase, updatePurchase, deletePurchase, getParties, getItems } from '@/lib/db'
import { useAuth } from '@/contexts/AuthContext'
import { Dialog, Table, Toolbar, SearchBar, StatusBar, KPIStrip, Field, Select, BillItemsTable, Confirm, Loading, toast, fmtAmt, fmtAmtK, fmt3 } from '@/components/ui'
import { Plus, Edit2, Eye, Trash2, RefreshCw, Printer } from 'lucide-react'
import { exportBillPDF } from '@/lib/pdf'

const today=()=>new Date().toISOString().slice(0,10)
const COLS=[
  {key:'bill_no',label:'Bill No',width:90},
  {key:'bill_date',label:'Date',width:90},
  {key:'party_name',label:'Supplier',width:200},
  {key:'total_qty',label:'Qty KG',width:90,right:true,render:r=>fmt3(r.total_qty)},
  {key:'grand_total',label:'Amount ₹',width:110,right:true,render:r=><span className="font-mono">{fmtAmt(r.grand_total)}</span>},
  {key:'outstanding',label:'Outstanding',width:110,right:true,
    render:r=><span className={`font-mono ${(r.outstanding||0)>0.01?'text-red-700':'text-green-700'}`}>{fmtAmt(r.outstanding)}</span>},
  {key:'vehicle_no',label:'Vehicle',width:100},
]
const EMPTY_HDR={party_id:'',party_name:'',bill_date:today(),transport_name:'',vehicle_no:'',lr_no:'',remarks:'',gst_percent:0,discount:0}
const EMPTY_ITEM={item_id:'',item_name:'',gross_wt:0,tare_wt:0,net_wt:0,moisture_pct:2.5,moisture_deduct:0,actual_wt:0,quantity:0,rate:0,amount:0}

function BillDialog({ open, onClose, onSaved, editId=null, viewOnly=false, parties=[], items=[] }) {
  const { company }=useAuth()
  const [hdr,setHdr]=useState(EMPTY_HDR)
  const [rows,setRows]=useState([{...EMPTY_ITEM}])
  const [saving,setSaving]=useState(false)
  const [loading,setLoading]=useState(false)

  useEffect(()=>{
    if(!open){return}
    if(editId){
      setLoading(true)
      getPurchaseById(editId).then(d=>{
        setHdr({party_id:d.party_id||'',party_name:d.party_name||'',bill_date:d.bill_date||today(),
          transport_name:d.transport_name||'',vehicle_no:d.vehicle_no||'',lr_no:d.lr_no||'',
          remarks:d.remarks||'',gst_percent:d.gst_percent||0,discount:d.discount||0})
        setRows(d.items?.length?d.items:[{...EMPTY_ITEM}])
      }).finally(()=>setLoading(false))
    } else { setHdr({...EMPTY_HDR,bill_date:today()}); setRows([{...EMPTY_ITEM}]) }
  },[open,editId])

  const subtotal=rows.reduce((s,r)=>s+(+r.amount||0),0)
  const gstAmt=subtotal*((+hdr.gst_percent||0)/100)
  const grandTotal=subtotal+gstAmt-(+hdr.discount||0)
  const totalQty=rows.reduce((s,r)=>s+(+r.actual_wt||0),0)

  const save=async()=>{
    if(!hdr.party_id){toast.error('Select supplier');return}
    if(rows.every(r=>!r.item_id)){toast.error('Add at least one item');return}
    setSaving(true)
    try{
      const bd={...hdr,subtotal,gst_amount:gstAmt,grand_total:grandTotal,
        total_qty:totalQty,outstanding:grandTotal,gst_percent:+hdr.gst_percent||0,discount:+hdr.discount||0}
      const validRows=rows.filter(r=>r.item_id)
      if(editId){await updatePurchase(editId,bd,validRows);toast.success('Updated')}
      else{const r=await addPurchase(company.id,bd,validRows);toast.success(`Saved: ${r.bill_no}`)}
      onSaved?.();onClose()
    }catch(e){toast.error(e.message)}
    finally{setSaving(false)}
  }

  const h=k=>e=>setHdr(p=>({...p,[k]:e.target?.value??e}))
  const title=viewOnly?'👁  View Purchase Bill':editId?'✏️  Edit Purchase Bill':'➕  New Purchase Bill'

  return (
    <Dialog open={open} onClose={onClose} title={title} size="xl" hint="Ctrl+S Save · Esc Cancel">
      {loading?<div className="dialog-body"><Loading/></div>:(
        <>
        <div className="dialog-body space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <Field label="Supplier *" className="col-span-1">
              <select className="erp-select" value={hdr.party_id} disabled={viewOnly} onChange={e=>{
                const p=parties.find(x=>x.id==e.target.value)
                setHdr(prev=>({...prev,party_id:e.target.value,party_name:p?.name||''}))
              }}>
                <option value="">Select Supplier…</option>
                {parties.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </Field>
            <Field label="Date">
              <input type="date" className="erp-input" value={hdr.bill_date} disabled={viewOnly} onChange={h('bill_date')} max={company?.fy_end||'2025-03-31'}/>
            </Field>
            <Field label="Vehicle No">
              <input className="erp-input" value={hdr.vehicle_no} disabled={viewOnly} onChange={h('vehicle_no')} placeholder="GJ05AB1234"/>
            </Field>
            <Field label="Transport"><input className="erp-input" value={hdr.transport_name} disabled={viewOnly} onChange={h('transport_name')}/></Field>
            <Field label="LR No"><input className="erp-input" value={hdr.lr_no} disabled={viewOnly} onChange={h('lr_no')}/></Field>
            <Field label="Remarks"><input className="erp-input" value={hdr.remarks} disabled={viewOnly} onChange={h('remarks')}/></Field>
          </div>
          <div className="font-semibold text-[11px] text-primary mt-2">Material Items</div>
          <BillItemsTable rows={rows} items={items} readOnly={viewOnly}
            onRow={(i,r)=>setRows(p=>{const n=[...p];n[i]=r;return n})}
            onAdd={()=>setRows(p=>[...p,{...EMPTY_ITEM}])}
            onRemove={i=>setRows(p=>p.filter((_,j)=>j!==i))}/>
          <div className="flex justify-end">
            <div className="w-64 space-y-1 text-sm border-t border-slate-200 pt-2">
              <div className="flex justify-between text-slate-600"><span>Subtotal:</span><span className="font-mono">{fmtAmt(subtotal)}</span></div>
              <div className="flex justify-between items-center text-slate-600">
                <span>GST %:</span>
                <input type="number" className="erp-input !w-16 !py-0.5 text-right font-mono text-xs" disabled={viewOnly} value={hdr.gst_percent} onChange={h('gst_percent')}/>
              </div>
              <div className="flex justify-between items-center text-slate-600">
                <span>Discount ₹:</span>
                <input type="number" className="erp-input !w-28 !py-0.5 text-right font-mono text-xs" disabled={viewOnly} value={hdr.discount} onChange={h('discount')}/>
              </div>
              <div className="flex justify-between font-bold text-primary border-t border-blue-200 pt-1 text-base">
                <span>Grand Total:</span><span className="font-mono">{fmtAmt(grandTotal)}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="dialog-footer">
          <button className="btn-cancel" onClick={onClose}>Close</button>
          {!viewOnly&&<button className="btn-save" onClick={save} disabled={saving}>{saving?'Saving…':'💾  Save Purchase'}</button>}
        </div>
        </>
      )}
    </Dialog>
  )
}

export default function Purchases() {
  const { company }=useAuth(); const cid=company?.id
  const fyStart=company?.fy_start||'2024-04-01', fyEnd=company?.fy_end||'2025-03-31'
  const [rows,setRows]=useState([]); const [loading,setLoading]=useState(true)
  const [from,setFrom]=useState(fyStart); const [to,setTo]=useState(fyEnd)
  const [search,setSearch]=useState(''); const [selId,setSelId]=useState(null)
  const [dlg,setDlg]=useState(null); const [delDlg,setDelDlg]=useState(false)
  const [parties,setParties]=useState([]); const [items,setItems]=useState([])

  const load=useCallback(async()=>{
    if(!cid)return; setLoading(true)
    try{ setRows(await getPurchases(cid,{from,to,search})) }
    catch(e){toast.error(e.message)}
    finally{setLoading(false)}
  },[cid,from,to,search])

  useEffect(()=>{load()},[load])
  useEffect(()=>{
    if(!cid)return
    Promise.all([getParties(cid),getItems(cid)]).then(([p,i])=>{setParties(p);setItems(i)})
  },[cid])

  const doDelete=async()=>{
    try{await deletePurchase(selId);toast.success('Deleted');setDelDlg(false);setSelId(null);load()}
    catch(e){toast.error(e.message)}
  }

  const tot=rows.reduce((s,r)=>s+(r.grand_total||0),0)
  const out=rows.reduce((s,r)=>s+(r.outstanding||0),0)
  const qty=rows.reduce((s,r)=>s+(r.total_qty||0),0)

  return (
    <div className="flex flex-col h-full">
      <KPIStrip cards={[
        {label:'Total Bills',value:rows.length,sub:'in period',accent:''},
        {label:'Total Qty KG',value:fmt3(qty),sub:'net weight',accent:'slate'},
        {label:'Grand Total',value:fmtAmtK(tot),sub:'purchased',accent:'blue',color:'text-primary'},
        {label:'Outstanding',value:fmtAmtK(out),sub:'payable',accent:'red',color:'text-red-700'},
      ]}/>
      <Toolbar>
        <button className="btn-primary" onClick={()=>setDlg('new')}><Plus size={13}/> New Purchase</button>
        <button className="btn-secondary" onClick={()=>{if(!selId){toast.info('Select a bill');return}setDlg('edit')}}><Edit2 size={13}/> Edit</button>
        <button className="btn-secondary" onClick={()=>{if(!selId){toast.info('Select a bill');return}setDlg('view')}}><Eye size={13}/> View</button>
        <button className="btn-secondary" onClick={()=>{const r=rows.find(x=>x.id===selId);if(r)exportBillPDF(r,'PURCHASE',company);else toast.info('Select a bill')}}><Printer size={13}/> Print/PDF</button>
        <button className="btn-danger" onClick={()=>selId&&setDelDlg(true)}><Trash2 size={13}/> Delete</button>
        <button className="btn-secondary" onClick={load}><RefreshCw size={12}/> Refresh</button>
      </Toolbar>
      <SearchBar from={from} to={to} onFrom={setFrom} onTo={setTo} search={search} onSearch={setSearch}/>
      <Table columns={COLS} rows={rows} loading={loading} selectedId={selId}
        onRowClick={r=>setSelId(r.id)} onRowDblClick={r=>{setSelId(r.id);setDlg('view')}}
        emptyMsg="No purchase bills in this period."/>
      <StatusBar left={`  Bills: ${rows.length}  ·  Qty: ${fmt3(qty)} KG`}
        right={`${fmtAmt(tot)} total  ·  ${fmtAmt(out)} outstanding`}/>

      <BillDialog open={!!dlg} onClose={()=>setDlg(null)} onSaved={load}
        editId={dlg==='edit'||dlg==='view'?selId:null}
        viewOnly={dlg==='view'} parties={parties} items={items}/>
      <Confirm open={delDlg} onCancel={()=>setDelDlg(false)} onConfirm={doDelete}
        message={`Delete purchase "${rows.find(r=>r.id===selId)?.bill_no}"?`}/>
    </div>
  )
}
