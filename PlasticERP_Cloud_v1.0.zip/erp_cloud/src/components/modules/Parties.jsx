import { useState, useEffect, useCallback } from 'react'
import { getParties, addParty, updateParty, deleteParty } from '@/lib/db'
import { useAuth } from '@/contexts/AuthContext'
import { Dialog, Table, Toolbar, SearchBar, StatusBar, Field, Select, Confirm, Loading, FilterTabs, toast } from '@/components/ui'
import { Plus, Edit2, Trash2, RefreshCw } from 'lucide-react'

const TYPES=['BUYER','SELLER','BOTH','BROKER','TRANSPORTER','RCM_SUPPLIER','BANK','CASH','OTHER']
const COLS=[
  {key:'code',label:'Code',width:80},
  {key:'name',label:'Ledger Name',width:220},
  {key:'party_type',label:'Type',width:100,render:r=><span className="badge-blue">{r.party_type}</span>},
  {key:'city',label:'City',width:110},
  {key:'phone',label:'Phone',width:120},
  {key:'gstin',label:'GSTIN',width:160},
  {key:'opening_balance',label:'Op. Bal',width:120,right:true,
    render:r=><span className={r.opening_type==='Dr'?'text-red-700 font-mono':'text-green-700 font-mono'}>
      ₹{(r.opening_balance||0).toLocaleString('en-IN')} {r.opening_type}
    </span>},
]
const EMPTY={name:'',party_type:'BUYER',address:'',city:'',phone:'',gstin:'',opening_balance:0,opening_type:'Dr',state_code:'24',remarks:''}
const TABS=[{label:'All',value:'ALL'},{label:'Buyers',value:'BUYER'},{label:'Sellers',value:'SELLER'},{label:'Brokers',value:'BROKER'},{label:'⚡ RCM',value:'RCM_SUPPLIER'}]

export default function Parties() {
  const { company } = useAuth()
  const cid = company?.id
  const [rows,setRows]=useState([]); const [loading,setLoading]=useState(true)
  const [search,setSearch]=useState(''); const [typeF,setTypeF]=useState('ALL')
  const [selId,setSelId]=useState(null); const [dlg,setDlg]=useState(false)
  const [editing,setEditing]=useState(null); const [form,setForm]=useState(EMPTY)
  const [delDlg,setDelDlg]=useState(false); const [saving,setSaving]=useState(false)

  const load = useCallback(async()=>{
    if (!cid) return
    setLoading(true)
    try { setRows(await getParties(cid,search,typeF)) }
    catch(e){ toast.error(e.message) }
    finally { setLoading(false) }
  },[cid,search,typeF])
  useEffect(()=>{ load() },[load])

  const openAdd  = ()=>{ setEditing(null);setForm(EMPTY);setDlg(true) }
  const openEdit = ()=>{
    const r=rows.find(x=>x.id===selId)
    if (!r){ toast.info('Select a party'); return }
    setEditing(r)
    setForm({name:r.name||'',party_type:r.party_type||'BUYER',address:r.address||'',
      city:r.city||'',phone:r.phone||'',gstin:r.gstin||'',
      opening_balance:r.opening_balance||0,opening_type:r.opening_type||'Dr',
      state_code:r.state_code||'24',remarks:r.remarks||''})
    setDlg(true)
  }
  const f = k => e => setForm(p=>({...p,[k]:e.target?.value??e}))

  const save = async()=>{
    if (!form.name.trim()){ toast.error('Name is required'); return }
    setSaving(true)
    try {
      const data={...form,name:form.name.toUpperCase(),opening_balance:+form.opening_balance||0}
      if (editing){ await updateParty(editing.id,data); toast.success('Party updated') }
      else { await addParty(cid,data); toast.success('Party added') }
      setDlg(false); load()
    } catch(e){ toast.error(e.message) }
    finally { setSaving(false) }
  }

  const doDelete = async()=>{
    try{ await deleteParty(selId); toast.success('Deleted'); setDelDlg(false); setSelId(null); load() }
    catch(e){ toast.error(e.message) }
  }

  return (
    <div className="flex flex-col h-full">
      <Toolbar hint="Double-click to edit">
        <button className="btn-primary" onClick={openAdd}><Plus size={13}/> New Ledger</button>
        <button className="btn-secondary" onClick={openEdit}><Edit2 size={13}/> Edit</button>
        <button className="btn-danger" onClick={()=>selId&&setDelDlg(true)}><Trash2 size={13}/> Delete</button>
        <button className="btn-secondary" onClick={load}><RefreshCw size={12}/> Refresh</button>
        <div className="ml-3"><FilterTabs tabs={TABS} active={typeF} onChange={setTypeF}/></div>
      </Toolbar>
      <SearchBar search={search} onSearch={setSearch}/>
      <Table columns={COLS} rows={rows} loading={loading} selectedId={selId}
        onRowClick={r=>setSelId(r.id)} onRowDblClick={r=>{setSelId(r.id);setTimeout(openEdit,10)}}
        emptyMsg="No parties found. Click + New Ledger to add."/>
      <StatusBar left={`  Ledgers: ${rows.length}`}
        right={rows.length>0?`${rows.filter(r=>(r.opening_balance||0)>0).length} with opening balance`:''}/>

      <Dialog open={dlg} onClose={()=>setDlg(false)}
        title={editing?`✏️  Edit — ${editing.name}`:'➕  New Ledger Account'}
        hint="Enter · Save   Esc · Cancel">
        <div className="dialog-body">
          <div className="grid grid-cols-2 gap-3">
            {editing&&<Field label="Code"><input className="erp-input" readOnly value={editing.code||''}/></Field>}
            <Field label="Ledger Name *" className={editing?'':'col-span-2'}>
              <input className="erp-input" value={form.name} onChange={f('name')} autoFocus placeholder="Party / Firm Name"/>
            </Field>
            <Field label="Party Type">
              <Select value={form.party_type} onChange={v=>setForm(p=>({...p,party_type:v}))} options={TYPES} placeholder=""/>
            </Field>
            <Field label="Phone"><input className="erp-input" value={form.phone} onChange={f('phone')} placeholder="9876543210"/></Field>
            <Field label="GSTIN"><input className="erp-input" value={form.gstin} onChange={f('gstin')} placeholder="24AAAAA0000A1Z5"/></Field>
            <Field label="State Code"><input className="erp-input" value={form.state_code} onChange={f('state_code')}/></Field>
            <div className="form-section">Contact</div>
            <Field label="Address" className="col-span-2"><input className="erp-input" value={form.address} onChange={f('address')}/></Field>
            <Field label="City"><input className="erp-input" value={form.city} onChange={f('city')}/></Field>
            <Field label="Remarks"><input className="erp-input" value={form.remarks} onChange={f('remarks')}/></Field>
            <div className="form-section">Opening Balance</div>
            <Field label="Opening Balance ₹">
              <input type="number" className="erp-input font-mono" value={form.opening_balance} onChange={f('opening_balance')}/>
            </Field>
            <Field label="Dr / Cr">
              <Select value={form.opening_type} onChange={v=>setForm(p=>({...p,opening_type:v}))} options={['Dr','Cr']} placeholder=""/>
            </Field>
          </div>
        </div>
        <div className="dialog-footer">
          <button className="btn-cancel" onClick={()=>setDlg(false)}>Cancel</button>
          <button className="btn-save" onClick={save} disabled={saving}>{saving?'Saving…':'💾  Save'}</button>
        </div>
      </Dialog>
      <Confirm open={delDlg} onCancel={()=>setDelDlg(false)} onConfirm={doDelete}
        message={`Delete "${rows.find(r=>r.id===selId)?.name}"? Cannot be undone.`}/>
    </div>
  )
}
