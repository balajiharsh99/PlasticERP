import { useState, useEffect, useCallback } from 'react'
import { getQuotations, addQuotation, updateQuotation, getParties, getItems } from '@/lib/db'
import { useAuth } from '@/contexts/AuthContext'
import { Dialog, Table, Toolbar, StatusBar, Field, Select, Confirm, FilterTabs, Badge, toast, fmtAmt } from '@/components/ui'
import { Plus, Edit2, Trash2, RefreshCw } from 'lucide-react'

const today=()=>new Date().toISOString().slice(0,10)
const COLS=[
  {key:'quot_no',label:'Quot No',width:100},
  {key:'quot_date',label:'Date',width:90},
  {key:'party_name',label:'Party',width:200},
  {key:'valid_upto',label:'Valid Upto',width:100},
  {key:'status',label:'Status',width:90,render:r=><Badge status={r.status}/>},
  {key:'grand_total',label:'Amount ₹',width:120,right:true,render:r=><span className="font-mono">{fmtAmt(r.grand_total)}</span>},
  {key:'remarks',label:'Remarks',width:200},
]
const TABS=[{label:'All',value:'ALL'},{label:'Draft',value:'DRAFT'},{label:'Sent',value:'SENT'},{label:'Won',value:'COMPLETE'},{label:'Lost',value:'CANCELLED'}]
const EMPTY={party_id:'',party_name:'',quot_date:today(),valid_upto:'',remarks:'',status:'DRAFT'}
const EMPTY_ITEM={item_id:'',item_name:'',quantity:0,rate:0,amount:0,quality_grade:'A Grade'}

export default function Quotations() {
  const { company }=useAuth(); const cid=company?.id
  const [rows,setRows]=useState([]); const [loading,setLoading]=useState(true)
  const [statusF,setStatusF]=useState('ALL'); const [selId,setSelId]=useState(null)
  const [dlg,setDlg]=useState(false); const [editing,setEditing]=useState(null)
  const [form,setForm]=useState(EMPTY); const [items_,setItems_]=useState([{...EMPTY_ITEM}])
  const [saving,setSaving]=useState(false)
  const [parties,setParties]=useState([]); const [materials,setMaterials]=useState([])

  const load=useCallback(async()=>{
    if(!cid)return; setLoading(true)
    try{ setRows(await getQuotations(cid,{status:statusF})) }
    catch(e){toast.error(e.message)}
    finally{setLoading(false)}
  },[cid,statusF])
  useEffect(()=>{load()},[load])
  useEffect(()=>{
    if(!cid)return
    Promise.all([getParties(cid),getItems(cid)]).then(([p,i])=>{setParties(p);setMaterials(i)})
  },[cid])

  const openAdd=()=>{setEditing(null);setForm({...EMPTY,quot_date:today()});setItems_([{...EMPTY_ITEM}]);setDlg(true)}
  const openEdit=()=>{
    const r=rows.find(x=>x.id===selId); if(!r){toast.info('Select a quotation');return}
    setEditing(r)
    setForm({party_id:r.party_id||'',party_name:r.party_name||'',quot_date:r.quot_date||today(),
      valid_upto:r.valid_upto||'',remarks:r.remarks||'',status:r.status||'DRAFT'})
    setItems_(r.quotation_items?.length?r.quotation_items:[{...EMPTY_ITEM}])
    setDlg(true)
  }

  const grandTotal=items_.reduce((s,i)=>s+(+i.amount||0),0)
  const save=async()=>{
    if(!form.party_id){toast.error('Select party');return}
    setSaving(true)
    try{
      const data={...form,grand_total:grandTotal}
      const validItems=items_.filter(i=>i.item_id).map(i=>({...i,amount:(+i.quantity||0)*(+i.rate||0)}))
      if(editing){await updateQuotation(editing.id,data,validItems);toast.success('Updated')}
      else{await addQuotation(cid,data,validItems);toast.success('Saved')}
      setDlg(false);load()
    }catch(e){toast.error(e.message)}
    finally{setSaving(false)}
  }

  return (
    <div className="flex flex-col h-full">
      <Toolbar>
        <button className="btn-primary" onClick={openAdd}><Plus size={13}/> New Quotation</button>
        <button className="btn-secondary" onClick={openEdit}><Edit2 size={13}/> Edit</button>
        <button className="btn-secondary" onClick={load}><RefreshCw size={12}/> Refresh</button>
        <div className="ml-2"><FilterTabs tabs={TABS} active={statusF} onChange={setStatusF}/></div>
      </Toolbar>
      <Table columns={COLS} rows={rows} loading={loading} selectedId={selId}
        onRowClick={r=>setSelId(r.id)} onRowDblClick={r=>{setSelId(r.id);setTimeout(openEdit,10)}}
        emptyMsg="No quotations. Click + New Quotation."/>
      <StatusBar left={`  Quotations: ${rows.length}`}/>

      <Dialog open={dlg} onClose={()=>setDlg(false)} title={editing?'✏️  Edit Quotation':'➕  New Quotation'} size="lg">
        <div className="dialog-body space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Party *">
              <select className="erp-select" value={form.party_id} onChange={e=>{
                const p=parties.find(x=>x.id==e.target.value)
                setForm(prev=>({...prev,party_id:e.target.value,party_name:p?.name||''}))
              }}>
                <option value="">Select Party…</option>
                {parties.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </Field>
            <Field label="Quotation Date"><input type="date" className="erp-input" value={form.quot_date} onChange={e=>setForm(p=>({...p,quot_date:e.target.value}))}/></Field>
            <Field label="Valid Upto"><input type="date" className="erp-input" value={form.valid_upto} onChange={e=>setForm(p=>({...p,valid_upto:e.target.value}))}/></Field>
            {editing&&<Field label="Status"><Select value={form.status} onChange={v=>setForm(p=>({...p,status:v}))} options={['DRAFT','SENT','COMPLETE','CANCELLED']} placeholder=""/></Field>}
            <Field label="Remarks" className="col-span-2"><input className="erp-input" value={form.remarks} onChange={e=>setForm(p=>({...p,remarks:e.target.value}))}/></Field>
          </div>
          <table className="items-table w-full">
            <thead><tr><th>Material</th><th className="text-right">Qty KG</th><th className="text-right">Rate ₹</th><th className="text-right">Amount ₹</th><th></th></tr></thead>
            <tbody>
              {items_.map((r,i)=>(
                <tr key={i}>
                  <td>
                    <select className="items-table select" value={r.item_id||''} onChange={e=>{
                      const it=materials.find(x=>x.id==e.target.value)
                      setItems_(p=>{const n=[...p];n[i]={...n[i],item_id:e.target.value,item_name:it?.name||'',rate:it?.rate||0};return n})
                    }}>
                      <option value="">Select…</option>
                      {materials.map(m=><option key={m.id} value={m.id}>{m.name}</option>)}
                    </select>
                  </td>
                  {['quantity','rate'].map(k=>(
                    <td key={k}>
                      <input type="number" step="0.001" className="td-inp text-right font-mono" value={r[k]||0}
                        onChange={e=>{const n=[...items_];n[i]={...n[i],[k]:+e.target.value,amount:(+n[i].quantity||0)*(+n[i].rate||0)};
                          if(k==='quantity')n[i].amount=(+e.target.value)*(+n[i].rate||0);
                          else n[i].amount=(+n[i].quantity||0)*(+e.target.value);setItems_(n)}}/>
                    </td>
                  ))}
                  <td className="text-right"><span className="font-mono">{fmtAmt((+r.quantity||0)*(+r.rate||0))}</span></td>
                  <td><button onClick={()=>setItems_(p=>p.filter((_,j)=>j!==i))} className="text-red-400 hover:text-red-600 px-1">×</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="flex items-center justify-between">
            <button onClick={()=>setItems_(p=>[...p,{...EMPTY_ITEM}])} className="btn-secondary text-[11px] py-1 px-3">+ Add Row</button>
            <div className="text-base font-bold text-primary">Total: {fmtAmt(grandTotal)}</div>
          </div>
        </div>
        <div className="dialog-footer">
          <button className="btn-cancel" onClick={()=>setDlg(false)}>Cancel</button>
          <button className="btn-save" onClick={save} disabled={saving}>{saving?'Saving…':'💾  Save'}</button>
        </div>
      </Dialog>
    </div>
  )
}
