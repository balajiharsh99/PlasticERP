export default function ComingSoon() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
      <div className="text-6xl mb-4">🚧</div>
      <div className="text-xl font-bold text-slate-600 mb-2">Coming Soon</div>
      <div className="text-sm">This module is under development.</div>
    </div>
  )
}
