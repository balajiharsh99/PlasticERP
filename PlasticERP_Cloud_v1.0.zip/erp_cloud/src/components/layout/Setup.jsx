// src/components/layout/Setup.jsx
import { useState } from 'react'
import { createCompany } from '@/lib/db'
import { useAuth } from '@/contexts/AuthContext'
import { toast } from '@/components/ui'

export default function Setup() {
  const { refreshProfile } = useAuth()
  const [form, setForm] = useState({
    name:'', gstin:'', pan:'', address:'', city:'', phone:'',
    fy_start:'2024-04-01', fy_end:'2025-03-31'
  })
  const [busy, setBusy] = useState(false)
  const f = k => e => setForm(p=>({...p,[k]:e.target.value}))

  const submit = async e => {
    e.preventDefault()
    if (!form.name) { toast.error('Company name required'); return }
    setBusy(true)
    try {
      await createCompany(form)
      await refreshProfile()
      toast.success('Company created! Welcome to Plastic Scrap ERP.')
    } catch(err) {
      toast.error(err.message); setBusy(false)
    }
  }

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
        <div className="bg-primary px-6 py-4">
          <div className="text-white font-bold text-base">🏢  Company Setup</div>
          <div className="text-blue-200 text-xs mt-0.5">Enter your company details to get started</div>
        </div>
        <form onSubmit={submit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="form-label">Company Name *</label>
              <input className="erp-input" value={form.name} onChange={f('name')} placeholder="SGM Plastics Pvt Ltd" required autoFocus/>
            </div>
            <div>
              <label className="form-label">GSTIN</label>
              <input className="erp-input" value={form.gstin} onChange={f('gstin')} placeholder="24AAAAA0000A1Z5"/>
            </div>
            <div>
              <label className="form-label">Phone</label>
              <input className="erp-input" value={form.phone} onChange={f('phone')} placeholder="9876543210"/>
            </div>
            <div className="col-span-2">
              <label className="form-label">Address</label>
              <input className="erp-input" value={form.address} onChange={f('address')} placeholder="Street, Area"/>
            </div>
            <div>
              <label className="form-label">City</label>
              <input className="erp-input" value={form.city} onChange={f('city')} placeholder="Surat"/>
            </div>
            <div>
              <label className="form-label">FY Start</label>
              <input type="date" className="erp-input" value={form.fy_start} onChange={f('fy_start')}/>
            </div>
          </div>
          <button type="submit" disabled={busy} className="btn-save w-full justify-center py-3">
            {busy ? 'Creating…' : '✅  Create Company & Start'}
          </button>
        </form>
      </div>
    </div>
  )
}
