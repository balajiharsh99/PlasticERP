// src/components/layout/Login.jsx
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { signIn } from '@/lib/db'
import { toast } from '@/components/ui'

export default function Login() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [pass,  setPass]  = useState('')
  const [busy,  setBusy]  = useState(false)

  const submit = async e => {
    e.preventDefault()
    setBusy(true)
    const { error } = await signIn(email, pass)
    if (error) { toast.error('Invalid email or password'); setBusy(false) }
    else { toast.success('Welcome back!'); navigate('/') }
  }

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden">

        <div className="bg-primary px-8 py-7 text-center">
          <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center text-white font-black text-2xl mx-auto mb-3">P</div>
          <div className="text-white text-xl font-bold">Plastic Scrap ERP</div>
          <div className="text-blue-200 text-xs mt-1">Cloud Edition · Powered by Supabase</div>
        </div>

        <form onSubmit={submit} className="px-8 py-7 space-y-4">
          <div>
            <label className="form-label">Email Address</label>
            <input type="email" className="erp-input" placeholder="admin@yourcompany.com"
              value={email} onChange={e=>setEmail(e.target.value)} required autoFocus/>
          </div>
          <div>
            <label className="form-label">Password</label>
            <input type="password" className="erp-input" placeholder="••••••••"
              value={pass} onChange={e=>setPass(e.target.value)} required/>
          </div>
          <button type="submit" disabled={busy} className="btn-save w-full justify-center py-3 mt-2 text-sm">
            {busy ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"/>
                Signing in…
              </span>
            ) : '🔑  Sign In'}
          </button>
          <p className="text-center text-[10px] text-slate-400 border-t border-slate-100 pt-4">
            Commodity ERP for Plastic Scrap Trading Industry
          </p>
        </form>
      </div>
    </div>
  )
}
