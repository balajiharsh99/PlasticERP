// src/components/ui/index.jsx  — All shared UI primitives
import { useEffect, useCallback, useState } from 'react'
import { X, AlertTriangle, CheckCircle, Info } from 'lucide-react'

/* ── Amount formatters ─────────────────────────────────── */
export const fmt2  = v => (+(v)||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})
export const fmt3  = v => (+(v)||0).toLocaleString('en-IN',{minimumFractionDigits:3,maximumFractionDigits:3})
export const fmtAmt  = v => `₹${fmt2(v)}`
export const fmtAmtK = v => {
  const n = +(v)||0
  if (n>=1e7) return `₹${(n/1e7).toFixed(2)}Cr`
  if (n>=1e5) return `₹${(n/1e5).toFixed(2)}L`
  return fmtAmt(n)
}
export const fmtQty  = v => fmt3(v)
export const today   = () => new Date().toISOString().slice(0,10)

/* ── Status badge ──────────────────────────────────────── */
export function Badge({ status }) {
  const map = {
    PAID:'green',COMPLETE:'green',RECEIVED:'green',
    PENDING:'red',UNPAID:'red',
    PARTIAL:'amber',
    DRAFT:'slate',CLOSED:'slate',
    SENT:'blue',OPEN:'blue',INWARD:'blue',
    OUTWARD:'amber',CANCELLED:'red',
    PAYMENT:'red',RECEIPT:'green',
  }
  const c = map[(status||'').toUpperCase()] || 'slate'
  return <span className={`badge-${c}`}>{status}</span>
}

/* ── Dialog ────────────────────────────────────────────── */
export function Dialog({ open, onClose, title, children, size='md', hint='' }) {
  useEffect(() => {
    const fn = e => { if (e.key==='Escape') onClose?.() }
    if (open) document.addEventListener('keydown', fn)
    return () => document.removeEventListener('keydown', fn)
  }, [open, onClose])
  if (!open) return null
  const W = { sm:'max-w-md',md:'max-w-2xl',lg:'max-w-4xl',xl:'max-w-5xl',full:'max-w-[96vw]' }
  return (
    <div className="dialog-overlay" onClick={e=>e.target===e.currentTarget&&onClose?.()}>
      <div className={`dialog-box w-full ${W[size]}`}>
        <div className="dialog-header">
          <span className="font-bold text-sm">{title}</span>
          <div className="flex items-center gap-3">
            {hint && <span className="text-blue-200 text-[10px]">{hint}</span>}
            <button onClick={onClose} className="text-blue-200 hover:text-white transition-colors">
              <X size={16}/>
            </button>
          </div>
        </div>
        {children}
      </div>
    </div>
  )
}

/* ── Confirm Delete ────────────────────────────────────── */
export function Confirm({ open, title='Confirm Delete', message, onConfirm, onCancel }) {
  if (!open) return null
  return (
    <div className="dialog-overlay">
      <div className="dialog-box w-full max-w-sm">
        <div className="dialog-header bg-red-600">
          <span className="font-bold text-sm flex items-center gap-2">
            <AlertTriangle size={16}/>  {title}
          </span>
        </div>
        <div className="dialog-body">
          <p className="text-slate-700 text-sm">{message||'This cannot be undone.'}</p>
        </div>
        <div className="dialog-footer">
          <button onClick={onCancel} className="btn-cancel">Cancel</button>
          <button onClick={onConfirm} className="btn-danger px-5 py-2 text-sm">Delete</button>
        </div>
      </div>
    </div>
  )
}

/* ── ERP Table ─────────────────────────────────────────── */
export function Table({ columns, rows, onRowClick, onRowDblClick, selectedId, emptyMsg='No records found.', loading }) {
  if (loading) return <div className="flex-1 flex items-center justify-center"><Loading/></div>
  return (
    <div className="overflow-auto flex-1">
      <table className="erp-table">
        <thead>
          <tr>{columns.map(c=>(
            <th key={c.key} style={{width:c.width}} className={c.right?'text-right':''}>
              {c.label}
            </th>
          ))}</tr>
        </thead>
        <tbody>
          {rows.length===0 ? (
            <tr><td colSpan={columns.length} className="text-center py-12 text-slate-400 italic">{emptyMsg}</td></tr>
          ) : rows.map((row,i)=>(
            <tr key={row.id||i}
              className={row.id===selectedId?'selected':''}
              onClick={()=>onRowClick?.(row)}
              onDoubleClick={()=>onRowDblClick?.(row)}>
              {columns.map(c=>(
                <td key={c.key} className={c.right?'text-right font-mono text-[11px]':''}>
                  {c.render?c.render(row):(row[c.key]??'')}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

/* ── KPI Card ──────────────────────────────────────────── */
export function KPICard({ label, value, sub, color='text-primary', accent='', icon }) {
  const accMap = {blue:'',red:'red',green:'green',amber:'amber',slate:'slate'}
  return (
    <div className={`card-stat ${accMap[accent]||''}`}>
      <div className="flex items-start justify-between">
        <div>
          <div className="kpi-label">{label}</div>
          <div className={`kpi-value ${color}`}>{value}</div>
          {sub && <div className="kpi-sub">{sub}</div>}
        </div>
        {icon && <span className="text-2xl opacity-20">{icon}</span>}
      </div>
    </div>
  )
}

/* ── KPI Strip ─────────────────────────────────────────── */
export function KPIStrip({ cards }) {
  return (
    <div className="grid gap-3 px-4 py-3 bg-white border-b border-slate-200 flex-shrink-0"
      style={{gridTemplateColumns:`repeat(${Math.min(cards.length,5)},minmax(0,1fr))`}}>
      {cards.map((c,i) => <KPICard key={i} {...c}/>)}
    </div>
  )
}

/* ── Toolbar ───────────────────────────────────────────── */
export function Toolbar({ children, hint }) {
  return (
    <div className="toolbar">
      {children}
      {hint&&<span className="toolbar-hint">{hint}</span>}
    </div>
  )
}

/* ── Search + Date Bar ─────────────────────────────────── */
export function SearchBar({ from, to, onFrom, onTo, search, onSearch, children }) {
  return (
    <div className="search-bar">
      <label className="text-[10px] font-semibold text-slate-500">From:</label>
      <input type="date" className="erp-input !w-36 !py-1.5" value={from||''} onChange={e=>onFrom(e.target.value)}/>
      <label className="text-[10px] font-semibold text-slate-500">To:</label>
      <input type="date" className="erp-input !w-36 !py-1.5" value={to||''} onChange={e=>onTo(e.target.value)}/>
      {onSearch&&<input type="text" className="erp-input !w-56 !py-1.5" placeholder="🔍  Search…"
        value={search||''} onChange={e=>onSearch(e.target.value)}/>}
      {children}
    </div>
  )
}

/* ── Status Bar ────────────────────────────────────────── */
export function StatusBar({ left, right }) {
  return (
    <div className="status-bar">
      <span>{left}</span>
      {right&&<span className="right">{right}</span>}
    </div>
  )
}

/* ── Form Field ────────────────────────────────────────── */
export function Field({ label, required, children, className='' }) {
  return (
    <div className={className}>
      <label className="form-label">{label}{required&&<span className="text-red-500"> *</span>}</label>
      {children}
    </div>
  )
}

/* ── Select ────────────────────────────────────────────── */
export function Select({ value, onChange, options=[], placeholder='Select…', className='', disabled }) {
  return (
    <select className={`erp-select ${className}`} value={value??''} onChange={e=>onChange(e.target.value)} disabled={disabled}>
      {placeholder&&<option value="">{placeholder}</option>}
      {options.map(o=><option key={o.value??o} value={o.value??o}>{o.label??o}</option>)}
    </select>
  )
}

/* ── Filter Tabs ───────────────────────────────────────── */
export function FilterTabs({ tabs, active, onChange }) {
  return (
    <div className="flex gap-1 flex-wrap">
      {tabs.map(t=>(
        <button key={t.value} onClick={()=>onChange(t.value)}
          className={`badge cursor-pointer px-3 py-1 text-[10px] font-semibold rounded-md transition-colors
            ${active===t.value?'bg-primary text-white':'bg-white border border-slate-200 text-slate-600 hover:border-primary hover:text-primary'}`}>
          {t.label}
        </button>
      ))}
    </div>
  )
}

/* ── Loading ───────────────────────────────────────────── */
export function Loading({ text='Loading…' }) {
  return (
    <div className="flex items-center justify-center h-48 text-slate-400 gap-2">
      <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin"/>
      <span className="text-sm">{text}</span>
    </div>
  )
}

/* ── Toast ─────────────────────────────────────────────── */
let _addToast = null
export function Toaster() {
  const [toasts, setToasts] = useState([])
  _addToast = useCallback(t=>{
    const id = Date.now()
    setToasts(p=>[...p,{...t,id}])
    setTimeout(()=>setToasts(p=>p.filter(x=>x.id!==id)), 3500)
  },[])
  const icons = { success:<CheckCircle size={14}/>, error:<AlertTriangle size={14}/>, info:<Info size={14}/> }
  const colors = { success:'bg-green-700', error:'bg-red-700', info:'bg-slate-700' }
  return (
    <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2 pointer-events-none">
      {toasts.map(t=>(
        <div key={t.id} className={`pointer-events-auto flex items-center gap-2 px-4 py-2.5 rounded-lg shadow-xl text-sm font-medium text-white min-w-[240px] ${colors[t.type]||colors.info}`}>
          {icons[t.type]||icons.info} {t.message}
        </div>
      ))}
    </div>
  )
}
export const toast = {
  success: msg=>_addToast?.({type:'success',message:msg}),
  error:   msg=>_addToast?.({type:'error',  message:msg}),
  info:    msg=>_addToast?.({type:'info',   message:msg}),
}

/* ── Bill Items Table ──────────────────────────────────── */
export function BillItemsTable({ rows, onRow, onAdd, onRemove, items=[], readOnly=false }) {
  return (
    <div className="border border-slate-200 rounded-lg overflow-x-auto">
      <table className="items-table w-full">
        <thead><tr>
          <th style={{width:180}}>Material</th>
          <th style={{width:80}} className="text-right">Gross KG</th>
          <th style={{width:70}} className="text-right">Tare KG</th>
          <th style={{width:70}} className="text-right">Net KG</th>
          <th style={{width:55}} className="text-right">Moist%</th>
          <th style={{width:80}} className="text-right">Actual KG</th>
          <th style={{width:75}} className="text-right">Rate ₹</th>
          <th style={{width:90}} className="text-right">Amount ₹</th>
          <th style={{width:28}}></th>
        </tr></thead>
        <tbody>
          {rows.map((r,i)=>(
            <tr key={i}>
              <td>
                <select className="items-table select w-full"
                  value={r.item_id||''} disabled={readOnly}
                  onChange={e=>{
                    const it=items.find(x=>x.id==e.target.value)
                    onRow(i,{...r,item_id:e.target.value,item_name:it?.name||'',
                      moisture_pct:it?.moisture_pct||0,rate:it?.rate||r.rate||0})
                  }}>
                  <option value="">Select…</option>
                  {items.map(it=><option key={it.id} value={it.id}>{it.name}{it.colour?` - ${it.colour}`:''}</option>)}
                </select>
              </td>
              {['gross_wt','tare_wt','net_wt','moisture_pct','actual_wt','rate','amount'].map(k=>{
                const ro = ['net_wt','actual_wt','amount'].includes(k) || readOnly
                return (
                  <td key={k} className="text-right">
                    <input type="number" step="0.001"
                      className={ro?'items-table td-ro text-right':'items-table td-inp text-right'}
                      value={r[k]||0} readOnly={ro}
                      onChange={e=>{
                        const next={...r,[k]:+e.target.value}
                        const gross=+next.gross_wt||0,tare=+next.tare_wt||0,net=gross-tare
                        const mDed=net*((+next.moisture_pct||0)/100)
                        const act=net-mDed
                        next.net_wt=+net.toFixed(3)
                        next.moisture_deduct=+mDed.toFixed(3)
                        next.actual_wt=+act.toFixed(3)
                        next.quantity=+act.toFixed(3)
                        next.amount=+(act*(+next.rate||0)).toFixed(2)
                        onRow(i,next)
                      }}/>
                  </td>
                )
              })}
              <td className="text-center">
                {!readOnly&&<button onClick={()=>onRemove(i)}
                  className="text-red-400 hover:text-red-600 font-bold px-1">×</button>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {!readOnly&&(
        <div className="p-2 bg-slate-50 border-t border-slate-200">
          <button onClick={onAdd} className="btn-secondary text-[11px] py-1 px-3">+ Add Item</button>
        </div>
      )}
    </div>
  )
}
