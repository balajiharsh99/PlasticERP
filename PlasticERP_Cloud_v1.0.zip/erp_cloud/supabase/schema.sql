-- ============================================================
-- Plastic Scrap ERP — Supabase Schema
-- Run this entire script in your Supabase SQL editor
-- Dashboard: https://app.supabase.com → SQL Editor
-- ============================================================

-- Enable UUID extension
create extension if not exists "pgcrypto";

-- ── Companies ──────────────────────────────────────────────
create table if not exists companies (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  gstin       text default '',
  pan         text default '',
  address     text default '',
  city        text default '',
  state       text default 'Gujarat',
  phone       text default '',
  email       text default '',
  fy_start    date default '2024-04-01',
  fy_end      date default '2025-03-31',
  currency    text default 'INR',
  created_at  timestamptz default now()
);
alter table companies enable row level security;
create policy "Users can manage own company" on companies for all using (
  id in (select company_id from profiles where id = auth.uid())
);

-- ── Profiles ───────────────────────────────────────────────
create table if not exists profiles (
  id           uuid primary key references auth.users on delete cascade,
  company_id   uuid references companies(id),
  display_name text default 'Admin',
  role         text default 'admin',
  created_at   timestamptz default now()
);
alter table profiles enable row level security;
create policy "Own profile" on profiles for all using (id = auth.uid());

-- ── Sequences ──────────────────────────────────────────────
create table if not exists sequences (
  company_id  uuid references companies(id) on delete cascade,
  seq_name    text not null,
  prefix      text default '',
  suffix      text default '',
  last_num    integer default 0,
  pad_len     integer default 4,
  primary key (company_id, seq_name)
);
alter table sequences enable row level security;
create policy "Company sequences" on sequences for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

-- Atomic sequence functions
create or replace function peek_sequence(p_company uuid, p_name text)
returns text language plpgsql as $$
declare r sequences%rowtype;
begin
  select * into r from sequences where company_id=p_company and seq_name=p_name;
  if not found then return p_name || '-0001'; end if;
  return r.prefix || lpad((r.last_num+1)::text, r.pad_len, '0') || r.suffix;
end $$;

create or replace function next_sequence(p_company uuid, p_name text)
returns text language plpgsql as $$
declare r sequences%rowtype; new_num integer; result text;
begin
  select * into r from sequences where company_id=p_company and seq_name=p_name for update;
  if not found then
    insert into sequences(company_id,seq_name,prefix,suffix,last_num,pad_len)
    values(p_company,p_name,'',''  ,1,4);
    return '0001';
  end if;
  new_num := r.last_num + 1;
  update sequences set last_num=new_num where company_id=p_company and seq_name=p_name;
  result := r.prefix || lpad(new_num::text, r.pad_len, '0') || r.suffix;
  return result;
end $$;

-- ── Master Lists ───────────────────────────────────────────
create table if not exists master_lists (
  id          bigserial primary key,
  company_id  uuid references companies(id) on delete cascade,
  list_name   text not null,
  value       text not null,
  sort_order  integer default 0,
  is_active   boolean default true,
  unique(company_id, list_name, value)
);
alter table master_lists enable row level security;
create policy "Company master_lists" on master_lists for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

-- ── Bill Series ────────────────────────────────────────────
create table if not exists bill_series (
  id           bigserial primary key,
  company_id   uuid references companies(id) on delete cascade,
  name         text not null,
  prefix       text default '',
  suffix       text default '',
  last_num     integer default 0,
  pad_len      integer default 4,
  voucher_type text default 'SALES',
  is_default   boolean default false
);
alter table bill_series enable row level security;
create policy "Company bill_series" on bill_series for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

-- ── Parties ────────────────────────────────────────────────
create table if not exists parties (
  id               bigserial primary key,
  company_id       uuid references companies(id) on delete cascade,
  code             text not null,
  name             text not null,
  party_type       text default 'BUYER',
  address          text default '',
  city             text default '',
  phone            text default '',
  gstin            text default '',
  pan              text default '',
  state_code       text default '24',
  transport        text default '',
  remarks          text default '',
  opening_balance  numeric(15,2) default 0,
  opening_type     text default 'Dr',
  opening_date     date,
  is_active        boolean default true,
  created_at       timestamptz default now()
);
alter table parties enable row level security;
create policy "Company parties" on parties for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

-- ── Items / Materials ──────────────────────────────────────
create table if not exists items (
  id            bigserial primary key,
  company_id    uuid references companies(id) on delete cascade,
  code          text not null,
  name          text not null,
  colour        text default '',
  plastic_type  text default 'PP',
  form          text default 'Loose',
  quality_grade text default 'A Grade',
  unit          text default 'KG',
  rate          numeric(10,2) default 0,
  moisture_pct  numeric(5,2) default 2.5,
  hsn           text default '39151000',
  opening_stock numeric(12,3) default 0,
  min_stock     numeric(12,3) default 0,
  max_stock     numeric(12,3) default 0,
  remarks       text default '',
  is_active     boolean default true,
  created_at    timestamptz default now()
);
alter table items enable row level security;
create policy "Company items" on items for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

-- ── Vehicles ───────────────────────────────────────────────
create table if not exists vehicles (
  id           bigserial primary key,
  company_id   uuid references companies(id) on delete cascade,
  vehicle_no   text not null,
  owner_name   text default '',
  driver_name  text default '',
  driver_phone text default '',
  capacity_ton numeric(8,2) default 0,
  remarks      text default '',
  is_active    boolean default true
);
alter table vehicles enable row level security;
create policy "Company vehicles" on vehicles for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

-- ── Sales ──────────────────────────────────────────────────
create table if not exists sales (
  id             bigserial primary key,
  company_id     uuid references companies(id) on delete cascade,
  bill_no        text not null,
  bill_date      date not null,
  party_id       bigint references parties(id),
  party_name     text default '',
  transport_name text default '',
  vehicle_no     text default '',
  lr_no          text default '',
  wb_slip_no     text default '',
  eway_bill_no   text default '',
  remarks        text default '',
  subtotal       numeric(15,2) default 0,
  gst_percent    numeric(5,2)  default 0,
  gst_amount     numeric(15,2) default 0,
  charges        numeric(15,2) default 0,
  discount       numeric(15,2) default 0,
  grand_total    numeric(15,2) default 0,
  total_qty      numeric(12,3) default 0,
  outstanding    numeric(15,2) default 0,
  paid_amount    numeric(15,2) default 0,
  is_cancelled   boolean default false,
  created_at     timestamptz default now()
);
alter table sales enable row level security;
create policy "Company sales" on sales for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

create table if not exists sale_items (
  id               bigserial primary key,
  sale_id          bigint references sales(id) on delete cascade,
  item_id          bigint references items(id),
  item_name        text default '',
  gross_wt         numeric(12,3) default 0,
  tare_wt          numeric(12,3) default 0,
  net_wt           numeric(12,3) default 0,
  moisture_pct     numeric(5,2)  default 0,
  moisture_deduct  numeric(12,3) default 0,
  actual_wt        numeric(12,3) default 0,
  quantity         numeric(12,3) default 0,
  rate             numeric(10,2) default 0,
  amount           numeric(15,2) default 0,
  quality_grade    text default 'A Grade',
  remarks          text default '',
  sort_order       integer default 0
);
alter table sale_items enable row level security;
create policy "Company sale_items" on sale_items for all using (
  sale_id in (select id from sales where company_id in (select company_id from profiles where id = auth.uid()))
);

-- ── Purchases ──────────────────────────────────────────────
create table if not exists purchases (
  id             bigserial primary key,
  company_id     uuid references companies(id) on delete cascade,
  bill_no        text not null,
  bill_date      date not null,
  party_id       bigint references parties(id),
  party_name     text default '',
  transport_name text default '',
  vehicle_no     text default '',
  lr_no          text default '',
  remarks        text default '',
  subtotal       numeric(15,2) default 0,
  gst_percent    numeric(5,2)  default 0,
  gst_amount     numeric(15,2) default 0,
  charges        numeric(15,2) default 0,
  discount       numeric(15,2) default 0,
  grand_total    numeric(15,2) default 0,
  total_qty      numeric(12,3) default 0,
  outstanding    numeric(15,2) default 0,
  paid_amount    numeric(15,2) default 0,
  is_cancelled   boolean default false,
  created_at     timestamptz default now()
);
alter table purchases enable row level security;
create policy "Company purchases" on purchases for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

create table if not exists purchase_items (
  id               bigserial primary key,
  purchase_id      bigint references purchases(id) on delete cascade,
  item_id          bigint references items(id),
  item_name        text default '',
  gross_wt         numeric(12,3) default 0,
  tare_wt          numeric(12,3) default 0,
  net_wt           numeric(12,3) default 0,
  moisture_pct     numeric(5,2)  default 0,
  moisture_deduct  numeric(12,3) default 0,
  actual_wt        numeric(12,3) default 0,
  quantity         numeric(12,3) default 0,
  rate             numeric(10,2) default 0,
  amount           numeric(15,2) default 0,
  quality_grade    text default 'A Grade',
  remarks          text default '',
  sort_order       integer default 0
);
alter table purchase_items enable row level security;
create policy "Company purchase_items" on purchase_items for all using (
  purchase_id in (select id from purchases where company_id in (select company_id from profiles where id = auth.uid()))
);

-- ── Payments ───────────────────────────────────────────────
create table if not exists payments (
  id             bigserial primary key,
  company_id     uuid references companies(id) on delete cascade,
  voucher_no     text not null,
  voucher_date   date not null,
  voucher_type   text default 'RECEIPT',
  party_id       bigint references parties(id),
  party_name     text default '',
  amount         numeric(15,2) default 0,
  narration      text default '',
  cheque_no      text default '',
  cheque_date    date,
  settlement_type text default 'AGAINST_BILL',
  created_at     timestamptz default now()
);
alter table payments enable row level security;
create policy "Company payments" on payments for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

-- ── Journal Vouchers ───────────────────────────────────────
create table if not exists journals (
  id           bigserial primary key,
  company_id   uuid references companies(id) on delete cascade,
  voucher_no   text not null,
  voucher_date date not null,
  narration    text default '',
  created_at   timestamptz default now()
);
alter table journals enable row level security;
create policy "Company journals" on journals for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

create table if not exists journal_entries (
  id          bigserial primary key,
  journal_id  bigint references journals(id) on delete cascade,
  party_id    bigint references parties(id),
  party_name  text default '',
  dr_amount   numeric(15,2) default 0,
  cr_amount   numeric(15,2) default 0,
  narration   text default ''
);
alter table journal_entries enable row level security;
create policy "Company journal_entries" on journal_entries for all using (
  journal_id in (select id from journals where company_id in (select company_id from profiles where id = auth.uid()))
);

-- ── Sauda Orders ───────────────────────────────────────────
create table if not exists sauda_orders (
  id          bigserial primary key,
  company_id  uuid references companies(id) on delete cascade,
  order_no    text not null,
  order_date  date not null,
  party_id    bigint references parties(id),
  party_name  text default '',
  remarks     text default '',
  status      text default 'PENDING',
  created_at  timestamptz default now()
);
alter table sauda_orders enable row level security;
create policy "Company sauda_orders" on sauda_orders for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

create table if not exists sauda_items (
  id           bigserial primary key,
  sauda_id     bigint references sauda_orders(id) on delete cascade,
  item_id      bigint references items(id),
  item_name    text default '',
  order_qty    numeric(12,3) default 0,
  delivered_qty numeric(12,3) default 0,
  balance_qty  numeric(12,3) default 0,
  rate         numeric(10,2) default 0,
  remarks      text default ''
);
alter table sauda_items enable row level security;
create policy "Company sauda_items" on sauda_items for all using (
  sauda_id in (select id from sauda_orders where company_id in (select company_id from profiles where id = auth.uid()))
);

-- ── Quotations ─────────────────────────────────────────────
create table if not exists quotations (
  id          bigserial primary key,
  company_id  uuid references companies(id) on delete cascade,
  quot_no     text not null,
  quot_date   date not null,
  valid_upto  date,
  party_id    bigint references parties(id),
  party_name  text default '',
  grand_total numeric(15,2) default 0,
  remarks     text default '',
  status      text default 'DRAFT',
  created_at  timestamptz default now()
);
alter table quotations enable row level security;
create policy "Company quotations" on quotations for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

create table if not exists quotation_items (
  id            bigserial primary key,
  quotation_id  bigint references quotations(id) on delete cascade,
  item_id       bigint references items(id),
  item_name     text default '',
  quantity      numeric(12,3) default 0,
  rate          numeric(10,2) default 0,
  amount        numeric(15,2) default 0,
  quality_grade text default 'A Grade'
);
alter table quotation_items enable row level security;
create policy "Company quotation_items" on quotation_items for all using (
  quotation_id in (select id from quotations where company_id in (select company_id from profiles where id = auth.uid()))
);

-- ── Weighbridge Slips ──────────────────────────────────────
create table if not exists weighbridge_slips (
  id               bigserial primary key,
  company_id       uuid references companies(id) on delete cascade,
  slip_no          text not null,
  slip_date        date not null,
  slip_type        text default 'INWARD',
  party_id         bigint references parties(id),
  party_name       text default '',
  item_id          bigint references items(id),
  item_name        text default '',
  vehicle_no       text default '',
  gross_wt         numeric(12,3) default 0,
  tare_wt          numeric(12,3) default 0,
  net_wt           numeric(12,3) default 0,
  moisture_pct     numeric(5,2) default 0,
  moisture_deduct  numeric(12,3) default 0,
  actual_wt        numeric(12,3) default 0,
  remarks          text default '',
  bill_ref         text default '',
  created_at       timestamptz default now()
);
alter table weighbridge_slips enable row level security;
create policy "Company weighbridge_slips" on weighbridge_slips for all using (
  company_id in (select company_id from profiles where id = auth.uid())
);

-- ── Indexes for performance ────────────────────────────────
create index if not exists idx_sales_company_date     on sales(company_id, bill_date desc);
create index if not exists idx_purchases_company_date on purchases(company_id, bill_date desc);
create index if not exists idx_payments_company_date  on payments(company_id, voucher_date desc);
create index if not exists idx_parties_company        on parties(company_id, name);
create index if not exists idx_items_company          on items(company_id, name);
