-- ============================================================
--  Plastic Scrap ERP — Supabase Schema
--  Run this in: Supabase Dashboard → SQL Editor → Run
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── Companies ────────────────────────────────────────────────
CREATE TABLE companies (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        TEXT NOT NULL,
  gstin       TEXT,
  pan         TEXT,
  address     TEXT,
  city        TEXT,
  state       TEXT DEFAULT 'Gujarat',
  phone       TEXT,
  email       TEXT,
  fy_start    DATE DEFAULT '2024-04-01',
  fy_end      DATE DEFAULT '2025-03-31',
  currency    TEXT DEFAULT 'INR',
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── User profiles (linked to auth.users) ─────────────────────
CREATE TABLE profiles (
  id           UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  company_id   UUID REFERENCES companies(id),
  display_name TEXT,
  role         TEXT DEFAULT 'admin' CHECK (role IN ('admin','manager','viewer')),
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ── Sequences (auto-increment codes) ─────────────────────────
CREATE TABLE sequences (
  company_id  UUID REFERENCES companies(id) ON DELETE CASCADE,
  seq_name    TEXT NOT NULL,
  prefix      TEXT DEFAULT '',
  last_num    INT  DEFAULT 0,
  pad_len     INT  DEFAULT 4,
  suffix      TEXT DEFAULT '',
  PRIMARY KEY (company_id, seq_name)
);

-- ── Parties / Ledger Master ───────────────────────────────────
CREATE TABLE parties (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id       UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code             TEXT NOT NULL,
  name             TEXT NOT NULL,
  party_type       TEXT DEFAULT 'BUYER' CHECK (party_type IN ('BUYER','SELLER','BOTH','BROKER','TRANSPORTER','RCM_SUPPLIER','BANK','CASH','OTHER')),
  gstin            TEXT,
  pan              TEXT,
  phone            TEXT,
  email            TEXT,
  address          TEXT,
  city             TEXT,
  state_code       TEXT DEFAULT '24',
  opening_balance  NUMERIC(15,2) DEFAULT 0,
  opening_type     TEXT DEFAULT 'Dr' CHECK (opening_type IN ('Dr','Cr')),
  remarks          TEXT,
  is_active        BOOLEAN DEFAULT TRUE,
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (company_id, code)
);

-- ── Materials / Items ─────────────────────────────────────────
CREATE TABLE items (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id     UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code           TEXT NOT NULL,
  name           TEXT NOT NULL,
  plastic_type   TEXT DEFAULT 'PP',
  colour         TEXT,
  form           TEXT DEFAULT 'Loose',
  quality_grade  TEXT DEFAULT 'A Grade',
  unit           TEXT DEFAULT 'KG',
  rate           NUMERIC(10,2) DEFAULT 0,
  moisture_pct   NUMERIC(5,2) DEFAULT 2.5,
  hsn            TEXT DEFAULT '39151000',
  min_stock      NUMERIC(12,3) DEFAULT 0,
  max_stock      NUMERIC(12,3) DEFAULT 0,
  is_active      BOOLEAN DEFAULT TRUE,
  created_at     TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (company_id, code)
);

-- ── Bill Series ───────────────────────────────────────────────
CREATE TABLE bill_series (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id   UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  prefix       TEXT DEFAULT '',
  last_num     INT  DEFAULT 0,
  pad_len      INT  DEFAULT 4,
  suffix       TEXT DEFAULT '',
  voucher_type TEXT DEFAULT 'SALES',
  is_default   BOOLEAN DEFAULT FALSE
);

-- ── Sales Bills ───────────────────────────────────────────────
CREATE TABLE sales (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  bill_no         TEXT NOT NULL,
  bill_date       DATE NOT NULL,
  party_id        UUID REFERENCES parties(id),
  party_name      TEXT,
  series_id       UUID REFERENCES bill_series(id),
  transport_name  TEXT,
  vehicle_no      TEXT,
  lr_no           TEXT,
  wb_slip_no      TEXT,
  eway_bill_no    TEXT,
  remarks         TEXT,
  subtotal        NUMERIC(15,2) DEFAULT 0,
  gst_percent     NUMERIC(5,2) DEFAULT 0,
  gst_amount      NUMERIC(15,2) DEFAULT 0,
  charges         NUMERIC(15,2) DEFAULT 0,
  discount        NUMERIC(15,2) DEFAULT 0,
  grand_total     NUMERIC(15,2) DEFAULT 0,
  paid_amount     NUMERIC(15,2) DEFAULT 0,
  outstanding     NUMERIC(15,2) DEFAULT 0,
  total_qty       NUMERIC(12,3) DEFAULT 0,
  broker_id       UUID REFERENCES parties(id),
  brokerage_pct   NUMERIC(5,2) DEFAULT 0,
  brokerage_amt   NUMERIC(15,2) DEFAULT 0,
  is_cancelled    BOOLEAN DEFAULT FALSE,
  fy_year         TEXT DEFAULT '2024-25',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (company_id, bill_no)
);

CREATE TABLE sale_items (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sale_id         UUID NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  item_id         UUID REFERENCES items(id),
  item_name       TEXT,
  gross_wt        NUMERIC(12,3) DEFAULT 0,
  tare_wt         NUMERIC(12,3) DEFAULT 0,
  net_wt          NUMERIC(12,3) DEFAULT 0,
  moisture_pct    NUMERIC(5,2) DEFAULT 0,
  moisture_deduct NUMERIC(12,3) DEFAULT 0,
  actual_wt       NUMERIC(12,3) DEFAULT 0,
  quantity        NUMERIC(12,3) DEFAULT 0,
  rate            NUMERIC(10,2) DEFAULT 0,
  amount          NUMERIC(15,2) DEFAULT 0,
  quality_grade   TEXT DEFAULT 'A Grade',
  godown_id       UUID,
  remarks         TEXT,
  sort_order      INT  DEFAULT 0
);

-- ── Purchases ─────────────────────────────────────────────────
CREATE TABLE purchases (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  bill_no         TEXT NOT NULL,
  bill_date       DATE NOT NULL,
  party_id        UUID REFERENCES parties(id),
  party_name      TEXT,
  transport_name  TEXT,
  vehicle_no      TEXT,
  lr_no           TEXT,
  wb_slip_no      TEXT,
  eway_bill_no    TEXT,
  remarks         TEXT,
  subtotal        NUMERIC(15,2) DEFAULT 0,
  gst_percent     NUMERIC(5,2) DEFAULT 0,
  gst_amount      NUMERIC(15,2) DEFAULT 0,
  charges         NUMERIC(15,2) DEFAULT 0,
  discount        NUMERIC(15,2) DEFAULT 0,
  grand_total     NUMERIC(15,2) DEFAULT 0,
  outstanding     NUMERIC(15,2) DEFAULT 0,
  total_qty       NUMERIC(12,3) DEFAULT 0,
  broker_id       UUID REFERENCES parties(id),
  brokerage_pct   NUMERIC(5,2) DEFAULT 0,
  brokerage_amt   NUMERIC(15,2) DEFAULT 0,
  is_cancelled    BOOLEAN DEFAULT FALSE,
  fy_year         TEXT DEFAULT '2024-25',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (company_id, bill_no)
);

CREATE TABLE purchase_items (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  purchase_id     UUID NOT NULL REFERENCES purchases(id) ON DELETE CASCADE,
  item_id         UUID REFERENCES items(id),
  item_name       TEXT,
  gross_wt        NUMERIC(12,3) DEFAULT 0,
  tare_wt         NUMERIC(12,3) DEFAULT 0,
  net_wt          NUMERIC(12,3) DEFAULT 0,
  moisture_pct    NUMERIC(5,2) DEFAULT 0,
  moisture_deduct NUMERIC(12,3) DEFAULT 0,
  actual_wt       NUMERIC(12,3) DEFAULT 0,
  quantity        NUMERIC(12,3) DEFAULT 0,
  rate            NUMERIC(10,2) DEFAULT 0,
  amount          NUMERIC(15,2) DEFAULT 0,
  quality_grade   TEXT DEFAULT 'A Grade',
  sort_order      INT  DEFAULT 0
);

-- ── Payment / Receipt Vouchers ────────────────────────────────
CREATE TABLE payments (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id       UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  voucher_no       TEXT NOT NULL,
  voucher_date     DATE NOT NULL,
  voucher_type     TEXT DEFAULT 'RECEIPT' CHECK (voucher_type IN ('PAYMENT','RECEIPT')),
  party_id         UUID REFERENCES parties(id),
  party_name       TEXT,
  amount           NUMERIC(15,2) DEFAULT 0,
  narration        TEXT,
  cheque_no        TEXT,
  cheque_date      DATE,
  settlement_type  TEXT DEFAULT 'AGAINST_BILL',
  fy_year          TEXT DEFAULT '2024-25',
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (company_id, voucher_no)
);

-- ── Journal Vouchers ──────────────────────────────────────────
CREATE TABLE journals (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id   UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  voucher_no   TEXT NOT NULL,
  voucher_date DATE NOT NULL,
  narration    TEXT,
  fy_year      TEXT DEFAULT '2024-25',
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (company_id, voucher_no)
);

CREATE TABLE journal_entries (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  journal_id  UUID NOT NULL REFERENCES journals(id) ON DELETE CASCADE,
  party_id    UUID REFERENCES parties(id),
  party_name  TEXT,
  dr_amount   NUMERIC(15,2) DEFAULT 0,
  cr_amount   NUMERIC(15,2) DEFAULT 0,
  narration   TEXT
);

-- ── Sales Orders (Sauda) ──────────────────────────────────────
CREATE TABLE sauda_orders (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id   UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  order_no     TEXT NOT NULL,
  order_date   DATE NOT NULL,
  party_id     UUID REFERENCES parties(id),
  party_name   TEXT,
  status       TEXT DEFAULT 'PENDING' CHECK (status IN ('PENDING','PARTIAL','COMPLETE','CANCELLED')),
  remarks      TEXT,
  fy_year      TEXT DEFAULT '2024-25',
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (company_id, order_no)
);

CREATE TABLE sauda_items (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sauda_id      UUID NOT NULL REFERENCES sauda_orders(id) ON DELETE CASCADE,
  item_id       UUID REFERENCES items(id),
  item_name     TEXT,
  order_qty     NUMERIC(12,3) DEFAULT 0,
  rate          NUMERIC(10,2) DEFAULT 0,
  delivered_qty NUMERIC(12,3) DEFAULT 0,
  balance_qty   NUMERIC(12,3) DEFAULT 0,
  remarks       TEXT
);

-- ── Purchase Orders ───────────────────────────────────────────
CREATE TABLE po_orders (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id   UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  order_no     TEXT NOT NULL,
  order_date   DATE NOT NULL,
  party_id     UUID REFERENCES parties(id),
  party_name   TEXT,
  status       TEXT DEFAULT 'PENDING',
  remarks      TEXT,
  fy_year      TEXT DEFAULT '2024-25',
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (company_id, order_no)
);

CREATE TABLE po_items (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  po_id        UUID NOT NULL REFERENCES po_orders(id) ON DELETE CASCADE,
  item_id      UUID REFERENCES items(id),
  item_name    TEXT,
  order_qty    NUMERIC(12,3) DEFAULT 0,
  rate         NUMERIC(10,2) DEFAULT 0,
  received_qty NUMERIC(12,3) DEFAULT 0,
  balance_qty  NUMERIC(12,3) DEFAULT 0,
  remarks      TEXT
);

-- ── Quotations ────────────────────────────────────────────────
CREATE TABLE quotations (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id   UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  quot_no      TEXT NOT NULL,
  quot_date    DATE NOT NULL,
  valid_upto   DATE,
  party_id     UUID REFERENCES parties(id),
  party_name   TEXT,
  grand_total  NUMERIC(15,2) DEFAULT 0,
  remarks      TEXT,
  status       TEXT DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','SENT','ACCEPTED','REJECTED','EXPIRED')),
  fy_year      TEXT DEFAULT '2024-25',
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (company_id, quot_no)
);

CREATE TABLE quotation_items (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  quotation_id  UUID NOT NULL REFERENCES quotations(id) ON DELETE CASCADE,
  item_id       UUID REFERENCES items(id),
  item_name     TEXT,
  quantity      NUMERIC(12,3) DEFAULT 0,
  rate          NUMERIC(10,2) DEFAULT 0,
  amount        NUMERIC(15,2) DEFAULT 0,
  quality_grade TEXT DEFAULT 'A Grade'
);

-- ── Weighbridge Slips ─────────────────────────────────────────
CREATE TABLE weighbridge_slips (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  slip_no         TEXT NOT NULL,
  slip_date       DATE NOT NULL,
  slip_type       TEXT DEFAULT 'INWARD' CHECK (slip_type IN ('INWARD','OUTWARD')),
  party_id        UUID REFERENCES parties(id),
  party_name      TEXT,
  item_id         UUID REFERENCES items(id),
  item_name       TEXT,
  vehicle_no      TEXT,
  gross_wt        NUMERIC(12,3) DEFAULT 0,
  tare_wt         NUMERIC(12,3) DEFAULT 0,
  net_wt          NUMERIC(12,3) DEFAULT 0,
  moisture_pct    NUMERIC(5,2) DEFAULT 0,
  moisture_deduct NUMERIC(12,3) DEFAULT 0,
  actual_wt       NUMERIC(12,3) DEFAULT 0,
  bill_ref        TEXT,
  remarks         TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (company_id, slip_no)
);

-- ── Rate Card ─────────────────────────────────────────────────
CREATE TABLE rate_card (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id   UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  rate_date    DATE NOT NULL,
  item_id      UUID REFERENCES items(id),
  item_name    TEXT,
  buy_rate     NUMERIC(10,2) DEFAULT 0,
  sell_rate    NUMERIC(10,2) DEFAULT 0,
  market_rate  NUMERIC(10,2) DEFAULT 0,
  remarks      TEXT,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ── Vehicles ──────────────────────────────────────────────────
CREATE TABLE vehicles (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id   UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  vehicle_no   TEXT NOT NULL,
  owner_name   TEXT,
  driver_name  TEXT,
  driver_phone TEXT,
  capacity_ton NUMERIC(8,2) DEFAULT 0,
  is_active    BOOLEAN DEFAULT TRUE,
  UNIQUE (company_id, vehicle_no)
);

-- ── Godowns ───────────────────────────────────────────────────
CREATE TABLE godowns (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id   UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code         TEXT NOT NULL,
  name         TEXT NOT NULL,
  address      TEXT,
  city         TEXT,
  is_active    BOOLEAN DEFAULT TRUE,
  UNIQUE (company_id, code)
);

-- ── Master Lists (dropdown values) ───────────────────────────
CREATE TABLE master_lists (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id   UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  list_name    TEXT NOT NULL,
  value        TEXT NOT NULL,
  sort_order   INT  DEFAULT 0,
  is_active    BOOLEAN DEFAULT TRUE,
  UNIQUE (company_id, list_name, value)
);

-- ════════════════════════════════════════════════════════════════
--  SEQUENCE HELPER FUNCTION
-- ════════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION next_sequence(p_company UUID, p_name TEXT)
RETURNS TEXT LANGUAGE plpgsql AS $$
DECLARE
  v_prefix TEXT; v_num INT; v_pad INT; v_suffix TEXT; v_new INT;
BEGIN
  SELECT prefix, last_num, pad_len, suffix
  INTO   v_prefix, v_num, v_pad, v_suffix
  FROM   sequences
  WHERE  company_id = p_company AND seq_name = p_name
  FOR UPDATE;

  IF NOT FOUND THEN
    INSERT INTO sequences(company_id, seq_name, prefix, last_num, pad_len, suffix)
    VALUES (p_company, p_name, '', 0, 4, '')
    ON CONFLICT DO NOTHING;
    v_prefix:=''; v_num:=0; v_pad:=4; v_suffix:='';
  END IF;

  v_new := v_num + 1;
  UPDATE sequences SET last_num = v_new
  WHERE  company_id = p_company AND seq_name = p_name;

  RETURN v_prefix || LPAD(v_new::TEXT, v_pad, '0') || v_suffix;
END; $$;

CREATE OR REPLACE FUNCTION peek_sequence(p_company UUID, p_name TEXT)
RETURNS TEXT LANGUAGE plpgsql AS $$
DECLARE v_prefix TEXT; v_num INT; v_pad INT; v_suffix TEXT;
BEGIN
  SELECT prefix, last_num, pad_len, suffix
  INTO   v_prefix, v_num, v_pad, v_suffix
  FROM   sequences WHERE company_id = p_company AND seq_name = p_name;
  IF NOT FOUND THEN RETURN p_name || '-0001'; END IF;
  RETURN v_prefix || LPAD((v_num+1)::TEXT, v_pad, '0') || v_suffix;
END; $$;

-- ════════════════════════════════════════════════════════════════
--  ROW LEVEL SECURITY
-- ════════════════════════════════════════════════════════════════
ALTER TABLE companies         ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles          ENABLE ROW LEVEL SECURITY;
ALTER TABLE sequences         ENABLE ROW LEVEL SECURITY;
ALTER TABLE parties           ENABLE ROW LEVEL SECURITY;
ALTER TABLE items             ENABLE ROW LEVEL SECURITY;
ALTER TABLE bill_series       ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales             ENABLE ROW LEVEL SECURITY;
ALTER TABLE sale_items        ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchases         ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_items    ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments          ENABLE ROW LEVEL SECURITY;
ALTER TABLE journals          ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_entries   ENABLE ROW LEVEL SECURITY;
ALTER TABLE sauda_orders      ENABLE ROW LEVEL SECURITY;
ALTER TABLE sauda_items       ENABLE ROW LEVEL SECURITY;
ALTER TABLE po_orders         ENABLE ROW LEVEL SECURITY;
ALTER TABLE po_items          ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotations        ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotation_items   ENABLE ROW LEVEL SECURITY;
ALTER TABLE weighbridge_slips ENABLE ROW LEVEL SECURITY;
ALTER TABLE rate_card         ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicles          ENABLE ROW LEVEL SECURITY;
ALTER TABLE godowns           ENABLE ROW LEVEL SECURITY;
ALTER TABLE master_lists      ENABLE ROW LEVEL SECURITY;

-- Helper: get user's company_id
CREATE OR REPLACE FUNCTION my_company_id()
RETURNS UUID LANGUAGE sql STABLE AS $$
  SELECT company_id FROM profiles WHERE id = auth.uid();
$$;

-- Profile: own row only
CREATE POLICY "profile_own" ON profiles
  USING (id = auth.uid()) WITH CHECK (id = auth.uid());

-- Company: own company only
CREATE POLICY "company_own" ON companies
  USING (id = my_company_id());

-- Generic company_id-based policy for all other tables
DO $$ DECLARE t TEXT;
BEGIN
  FOR t IN SELECT unnest(ARRAY['sequences','parties','items','bill_series',
    'sales','sale_items','purchases','purchase_items','payments',
    'journals','journal_entries','sauda_orders','sauda_items',
    'po_orders','po_items','quotations','quotation_items',
    'weighbridge_slips','rate_card','vehicles','godowns','master_lists'])
  LOOP
    EXECUTE format('CREATE POLICY "rls_%s" ON %I USING (company_id = my_company_id())', t, t);
  END LOOP;
END $$;

-- sale_items / purchase_items / journal_entries / sauda_items / po_items / quotation_items
-- link through parent — allow via parent's company check above ✓

-- ════════════════════════════════════════════════════════════════
--  INDEXES FOR PERFORMANCE
-- ════════════════════════════════════════════════════════════════
CREATE INDEX idx_sales_company_date    ON sales(company_id, bill_date DESC);
CREATE INDEX idx_purchases_company_date ON purchases(company_id, bill_date DESC);
CREATE INDEX idx_payments_company_date  ON payments(company_id, voucher_date DESC);
CREATE INDEX idx_parties_company_name   ON parties(company_id, name);
CREATE INDEX idx_items_company_name     ON items(company_id, name);
CREATE INDEX idx_sauda_company_status   ON sauda_orders(company_id, status);

-- ════════════════════════════════════════════════════════════════
--  SEED DEFAULT SEQUENCES
-- ════════════════════════════════════════════════════════════════
-- Called by the app on first company setup (see initCompany() in db.js)
