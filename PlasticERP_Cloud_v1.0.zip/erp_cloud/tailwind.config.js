export default {
  content: ['./index.html','./src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        primary: { DEFAULT:'#2563EB', dark:'#1D4ED8', darker:'#1E40AF', light:'#DBEAFE', lighter:'#EFF6FF' },
        sidebar: { DEFAULT:'#0F172A', card:'#1E293B', border:'#334155', text:'#94A3B8', textHover:'#E2E8F0' },
        slate: { 50:'#F8FAFC', 100:'#F1F5F9', 200:'#E2E8F0', 300:'#CBD5E1', 400:'#94A3B8', 500:'#64748B', 600:'#475569', 700:'#334155', 800:'#1E293B', 900:'#0F172A' },
      },
      fontFamily: { sans:['Segoe UI','Inter','system-ui','sans-serif'] }
    }
  },
  plugins: []
}
