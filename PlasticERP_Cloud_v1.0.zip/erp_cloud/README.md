# Plastic Scrap ERP — Cloud Version

## 🌐 Live Demo
Deploy this to any static host + Supabase backend.

---

## ⚡ Quick Start (5 minutes)

### Step 1 — Create Supabase Project
1. Go to **https://app.supabase.com**
2. Click **New Project** → choose a region (preferably India/Singapore)
3. Note your **Project URL** and **anon/public key** (in Project Settings → API)

### Step 2 — Run the Database Schema
1. In Supabase dashboard → **SQL Editor**
2. Open the file `supabase/schema.sql` from this project
3. Paste the entire contents → click **Run**
4. You should see "Success" for all statements

### Step 3 — Configure the App
Create a file called `.env` in the root folder:
```
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGc...your-anon-key
```

### Step 4 — Run Locally
```bash
npm install
npm run dev
```
Open http://localhost:5173

---

## 🚀 Deploy to Production (FREE hosting)

### Option A — Vercel (Recommended)
1. Push this folder to GitHub
2. Go to **vercel.com** → Import repository
3. Add environment variables: `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`
4. Click Deploy → you get a free `https://your-app.vercel.app` URL

### Option B — Netlify
1. `npm run build` → creates `dist/` folder
2. Drag-drop the `dist/` folder to **netlify.com/drop**
3. Add environment variables in Netlify dashboard

### Option C — Firebase Hosting
```bash
npm install -g firebase-tools
firebase login
firebase init hosting  # choose dist/ as public folder
npm run build
firebase deploy
```

---

## 📱 First Run
1. Open the app URL
2. Click **Sign Up** → enter your email + password
3. Enter company details (name, GSTIN, FY dates)
4. Start adding parties and materials

---

## 🔧 Architecture

```
┌─────────────────┐    HTTPS    ┌───────────────────┐
│   Browser App   │ ─────────► │  Supabase Cloud   │
│  React 18 +     │            │  • PostgreSQL DB   │
│  Tailwind CSS   │ ◄───────── │  • Row Level Sec  │
│  Vite / Vercel  │   REST/WS  │  • Auth (JWT)     │
└─────────────────┘            └───────────────────┘
```

- **Frontend**: React 18 + Vite + Tailwind CSS
- **Backend**: Supabase (PostgreSQL + Auth + Real-time)
- **PDF Export**: jsPDF + autoTable
- **Charts**: Recharts
- **Auth**: Email/password (can add Google OAuth in Supabase dashboard)

---

## 📦 Modules Included

| Module | Features |
|---|---|
| **Dashboard** | Live KPIs, monthly chart, recent transactions |
| **Parties / Ledger** | Buyers, Sellers, Brokers, RCM suppliers with opening balance |
| **Materials** | Items with plastic type, colour, form, moisture% |
| **Sales Bills** | Full bill with weighbridge data, GST, multiple items |
| **Purchase Bills** | Same as sales with supplier tracking |
| **Sales Orders (Sauda)** | Order tracking with delivery status |
| **Quotations** | Draft → Sent → Won/Lost pipeline |
| **Payment / Receipt** | Vouchers with party linking |
| **Journal Voucher** | Double-entry journals with Dr/Cr validation |
| **Party Ledger** | Statement of account with opening/closing balance |
| **Weighbridge** | Inward/Outward slips with moisture deduction |
| **Reports** | Sales summary, Purchase summary, Monthly trend, CSV export |
| **Settings** | Company profile, FY configuration |

---

## 🔐 Security
- Row Level Security (RLS) on all tables — users only see their own company's data
- JWT authentication via Supabase Auth
- No API keys exposed in frontend (anon key has restricted permissions)
- HTTPS enforced by Vercel/Netlify/Supabase

---

## 💾 Data
Your data is stored in **Supabase PostgreSQL** on their servers (AWS/GCP depending on region).
- Free tier: 500MB storage, unlimited API calls
- All your data belongs to you — you can export anytime from Supabase dashboard
- Automatic backups on Supabase Pro plan

