// src/App.jsx
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster, toast } from '@/components/ui'
import { AuthProvider, useAuth } from '@/contexts/AuthContext'
import Layout      from '@/components/layout/Layout'
import Login       from '@/components/layout/Login'
import Setup       from '@/components/layout/Setup'
import Dashboard   from '@/components/modules/Dashboard'
import Parties     from '@/components/modules/Parties'
import Items       from '@/components/modules/Items'
import Sales       from '@/components/modules/Sales'
import Purchases   from '@/components/modules/Purchases'
import Payments    from '@/components/modules/Payments'
import Journals    from '@/components/modules/Journals'
import Ledger      from '@/components/modules/Ledger'
import SaudaOrders from '@/components/modules/SaudaOrders'
import Quotations  from '@/components/modules/Quotations'
import Weighbridge from '@/components/modules/Weighbridge'
import Reports     from '@/components/modules/Reports'
import Settings    from '@/components/modules/Settings'
import ComingSoon    from '@/components/modules/ComingSoon'
import GSTCompliance from '@/components/modules/GSTCompliance'

function Guard({ children }) {
  const { user, company, loading } = useAuth()
  if (loading) return (
    <div className="flex h-screen items-center justify-center bg-slate-900">
      <div className="text-center">
        <div className="w-10 h-10 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-3"/>
        <p className="text-slate-400 text-sm">Loading Plastic Scrap ERP…</p>
      </div>
    </div>
  )
  if (!user)    return <Navigate to="/login" replace />
  if (!company) return <Setup />
  return children
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Guard><Layout /></Guard>}>
        <Route index            element={<Dashboard />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="parties"   element={<Parties />} />
        <Route path="items"     element={<Items />} />
        <Route path="sales"     element={<Sales />} />
        <Route path="purchases" element={<Purchases />} />
        <Route path="sauda"     element={<SaudaOrders />} />
        <Route path="quotations" element={<Quotations />} />
        <Route path="payment"   element={<Payments />} />
        <Route path="journal"   element={<Journals />} />
        <Route path="ledger"    element={<Ledger />} />
        <Route path="weighbridge" element={<Weighbridge />} />
        <Route path="reports"   element={<Reports />} />
        <Route path="settings"  element={<Settings />} />
        <Route path="gst"       element={<GSTCompliance />} />
        <Route path="*"         element={<ComingSoon />} />
      </Route>
    </Routes>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
        <Toaster/>
      </AuthProvider>
    </BrowserRouter>
  )
}
