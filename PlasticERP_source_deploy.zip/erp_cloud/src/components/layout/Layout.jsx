// src/components/layout/Layout.jsx
import { Outlet, NavLink, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '@/contexts/AuthContext'
import { signOut } from '@/lib/db'
import {
  LayoutDashboard, Users, Package, ShoppingCart, Truck, FileText,
  CreditCard, BookOpen, Scale, BarChart3, ClipboardList, Settings,
  LogOut, ChevronDown, ChevronRight, Building2, FileCheck
} from 'lucide-react'
import { useState, useEffect } from 'react'
import { toast } from '@/components/ui'

const NAV = [
  { section:'OVERVIEW', items:[
    { icon:LayoutDashboard, label:'Dashboard',       path:'/dashboard' },
    { icon:Building2,       label:'Company Settings', path:'/settings' },
  ]},
  { section:'MASTERS', items:[
    { icon:Users,    label:'Parties / Ledger', path:'/parties' },
    { icon:Package,  label:'Materials',        path:'/items' },
  ]},
  { section:'TRANSACTIONS', items:[
    { icon:ClipboardList, label:'Sales Orders',   path:'/sauda' },
    { icon:FileCheck,     label:'Quotations',     path:'/quotations' },
    { icon:ShoppingCart,  label:'Sales Bills',    path:'/sales' },
    { icon:Truck,         label:'Purchase Bills', path:'/purchases' },
  ]},
  { section:'WEIGHBRIDGE', items:[
    { icon:Scale,   label:'WB Slips',    path:'/weighbridge' },
  ]},
  { section:'FINANCE', items:[
    { icon:CreditCard, label:'Payment / Receipt', path:'/payment' },
    { icon:BookOpen,   label:'Journal Voucher',   path:'/journal' },
    { icon:Users,      label:'Party Ledger',      path:'/ledger' },
  ]},
  { section:'GST COMPLIANCE', items:[
    { icon:FileText,   label:'GST Returns',     path:'/gst' },
  ]},
  { section:'REPORTS', items:[
    { icon:BarChart3,  label:'Reports',          path:'/reports' },
  ]},
]

function NavGroup({ group }) {
  const [open, setOpen] = useState(true)
  const location = useLocation()
  const isActive = group.items.some(i => location.pathname === i.path || location.pathname.startsWith(i.path+'/'))
  return (
    <div>
      <button onClick={() => setOpen(o=>!o)}
        className="nav-section flex items-center gap-1 w-full text-left hover:text-slate-400 transition-colors">
        {open ? <ChevronDown size={9}/> : <ChevronRight size={9}/>}
        {group.section}
      </button>
      {open && group.items.map(item => (
        <NavLink key={item.path} to={item.path}
          className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}>
          <item.icon size={14} className="shrink-0"/>
          <span className="truncate text-[11px]">{item.label}</span>
        </NavLink>
      ))}
    </div>
  )
}

// Breadcrumb labels
const LABELS = {
  '/dashboard':'Dashboard', '/parties':'Parties / Ledger', '/items':'Materials',
  '/sales':'Sales Bills', '/purchases':'Purchase Bills', '/sauda':'Sales Orders',
  '/quotations':'Quotations', '/payment':'Payment / Receipt', '/journal':'Journal Voucher',
  '/ledger':'Party Ledger', '/weighbridge':'Weighbridge', '/reports':'Reports', '/settings':'Settings', '/gst':'GST Compliance',
}

export default function Layout() {
  const { company, profile } = useAuth()
  const navigate   = useNavigate()
  const location   = useLocation()
  const pageLabel  = LABELS[location.pathname] || 'Module'
  const section    = NAV.find(g => g.items.some(i => i.path === location.pathname))?.section || 'Overview'

  const handleLogout = async () => {
    await signOut()
    navigate('/login')
    toast.success('Signed out')
  }

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">

      {/* ── Sidebar ────────────────────────────────────────────── */}
      <aside className="w-[220px] flex flex-col bg-slate-900 border-r border-slate-800 shrink-0">

        {/* Logo */}
        <div className="flex items-center gap-3 px-4 h-[56px] border-b border-slate-800 shrink-0">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-black text-sm shrink-0">P</div>
          <div className="min-w-0">
            <div className="text-slate-100 font-extrabold text-[13px] leading-tight">Plastic ERP</div>
            <div className="text-slate-600 text-[9px] font-semibold tracking-wider">v1.7 · CLOUD</div>
          </div>
        </div>

        {/* Company badge */}
        <div className="mx-2 mt-2 mb-1 px-3 py-2 bg-slate-800 rounded-lg border border-slate-700 shrink-0">
          <div className="text-slate-200 text-[11px] font-bold truncate">{company?.name || '—'}</div>
          <div className="text-slate-500 text-[10px] mt-0.5">
            👤 {profile?.display_name || 'Admin'}
            {company?.fy_start && (
              <span className="ml-1 text-slate-600">· FY {new Date(company.fy_start).getFullYear()}-{String(new Date(company.fy_end).getFullYear()).slice(2)}</span>
            )}
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-1">
          {NAV.map(g => <NavGroup key={g.section} group={g}/>)}
        </nav>

        {/* Sign out */}
        <div className="border-t border-slate-800 shrink-0">
          <button onClick={handleLogout}
            className="nav-btn w-full border-l-0 hover:bg-red-900/20 hover:text-red-400 hover:border-0 text-slate-500">
            <LogOut size={13}/> Sign Out
          </button>
        </div>
      </aside>

      {/* ── Right ──────────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col overflow-hidden">

        {/* Top header */}
        <header className="flex items-center bg-primary px-5 h-[48px] shrink-0 border-b border-primary-dark">
          <div className="flex-1">
            <div className="text-blue-200 text-[9px] tracking-wide">
              {section} › {pageLabel}
            </div>
            <div className="text-white text-[14px] font-bold leading-tight">{pageLabel}</div>
          </div>
          <div className="flex items-center gap-2">
            {company?.name && (
              <span className="text-[10px] text-blue-100 bg-white/10 border border-white/15 rounded px-2.5 py-1 font-medium">
                🏢 {company.name}
              </span>
            )}
            <span className="text-[11px] text-white font-semibold bg-white/10 border border-white/15 rounded px-3 py-1">
              👤 {profile?.display_name || 'Admin'}
            </span>
          </div>
        </header>

        {/* Module content */}
        <main className="flex-1 overflow-auto bg-slate-50">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
