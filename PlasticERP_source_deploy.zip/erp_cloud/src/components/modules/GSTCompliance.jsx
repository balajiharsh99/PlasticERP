// src/components/modules/GSTCompliance.jsx
// Full GST Compliance: GSTR-1, GSTR-3B, E-Way Bill, E-Invoice
import { useState, useEffect, useCallback } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { getSales, getPurchases } from '@/lib/db'
import { supabase } from '@/lib/supabase'
import { Toolbar, SearchBar, StatusBar, KPIStrip, Field, Select,
         FilterTabs, Table, Dialog, toast, fmtAmt, fmtAmtK, fmt3 } from '@/components/ui'
import { FileText, Download, RefreshCw, CheckCircle, AlertTriangle, Eye, Send } from 'lucide-react'

// ── GST Helpers ────────────────────────────────────────────────
const STATE_CODES = {
  '01':'Jammu & Kashmir','02':'Himachal Pradesh','03':'Punjab','04':'Chandigarh',
  '05':'Uttarakhand','06':'Haryana','07':'Delhi','08':'Rajasthan',
  '09':'Uttar Pradesh','10':'Bihar','11':'Sikkim','12':'Arunachal Pradesh',
  '13':'Nagaland','14':'Manipur','15':'Mizoram','16':'Tripura',
  '17':'Meghalaya','18':'Assam','19':'West Bengal','20':'Jharkhand',
  '21':'Odisha','22':'Chhattisgarh','23':'Madhya Pradesh','24':'Gujarat',
  '26':'Dadra & Nagar Haveli','27':'Maharashtra','28':'Andhra Pradesh',
  '29':'Karnataka','30':'Goa','31':'Lakshadweep','32':'Kerala',
  '33':'Tamil Nadu','34':'Puducherry','35':'Andaman & Nicobar',
  '36':'Telangana','37':'Andhra Pradesh (new)','38':'Ladakh','99':'Other',
}

const TABS = [
  { value:'gstr1',      label:'GSTR-1' },
  { value:'gstr3b',     label:'GSTR-3B' },
  { value:'eway',       label:'E-Way Bills' },
  { value:'einvoice',   label:'E-Invoice' },
]

const gstinState = g => (g||'24').slice(0,2)
const isInterstate = (supCode, recCode) => supCode !== recCode

function splitGST(amount, rate, supState, recState) {
  const taxable = amount
  const total = +(taxable * rate / 100).toFixed(2)
  if (isInterstate(supState, recState)) {
    return { taxable, igst:total, cgst:0, sgst:0 }
  }
  const half = +(total/2).toFixed(2)
  return { taxable, igst:0, cgst:half, sgst:half }
}

// ── GSTR-1 Component ──────────────────────────────────────────
function GSTR1Tab({ company, from, to }) {
  const [sales, setSales] = useState([])
  const [loading, setLoading] = useState(false)
  const supState = gstinState(company?.gstin)

  const load = useCallback(async () => {
    setLoading(true)
    try { setSales(await getSales(company.id, { from, to })) }
    catch(e) { toast.error(e.message) }
    finally { setLoading(false) }
  }, [company?.id, from, to])

  useEffect(() => { load() }, [load])

  // Categorise into B2B / B2C / CDNR
  const b2b = sales.filter(s => s.party_gstin?.length === 15)
  const b2c  = sales.filter(s => !s.party_gstin || s.party_gstin.length !== 15)

  const totTax = sales.reduce((s,r) => s+(+r.gst_amount||0), 0)
  const totVal = sales.reduce((s,r) => s+(+r.grand_total||0), 0)

  const exportGSTR1JSON = () => {
    const gstnPrefix = company?.gstin?.slice(0,2) || '24'
    const b2bData = {}
    b2b.forEach(s => {
      const gstin = s.party_gstin
      if (!b2bData[gstin]) b2bData[gstin] = { ctin:gstin, inv:[] }
      const recState = gstinState(gstin)
      const { taxable, igst, cgst, sgst } = splitGST(s.subtotal||s.grand_total, s.gst_percent||0, supState, recState)
      b2bData[gstin].inv.push({
        inum: s.bill_no, idt: s.bill_date?.split('-').reverse().join('-'),
        val: +(s.grand_total||0).toFixed(2), pos: recState,
        rchrg: 'N', inv_typ: 'R',
        itms: [{ num:1, itm_det:{
          rt: s.gst_percent||0, txval:+taxable.toFixed(2),
          iamt:+igst.toFixed(2), camt:+cgst.toFixed(2), samt:+sgst.toFixed(2), csamt:0
        }}]
      })
    })

    const json = {
      gstin: company?.gstin||'',
      fp: from?.slice(0,7).replace('-',''),
      b2b: Object.values(b2bData),
      b2cs: [], cdnr:[], cdnur:[], exp:[], nil:[], hsnsum:[]
    }
    download(JSON.stringify(json, null, 2), `GSTR1_${from?.slice(0,7)}.json`, 'application/json')
    toast.success('GSTR-1 JSON downloaded — upload to GST portal')
  }

  const exportCSV = () => {
    const rows = [
      ['GSTIN/UIN','Receiver Name','Invoice No','Invoice Date','Invoice Value','Place of Supply','Reverse Charge','Invoice Type','Rate','Taxable Value','IGST','CGST','SGST'],
      ...b2b.map(s => {
        const rec = gstinState(s.party_gstin||'24')
        const { taxable, igst, cgst, sgst } = splitGST(s.subtotal||s.grand_total, s.gst_percent||0, supState, rec)
        return [s.party_gstin||'URP', s.party_name, s.bill_no, s.bill_date,
          s.grand_total, STATE_CODES[rec]||rec, 'N', 'Regular',
          s.gst_percent||0, taxable.toFixed(2), igst.toFixed(2), cgst.toFixed(2), sgst.toFixed(2)]
      }),
      ...b2c.map(s => {
        const { taxable, igst, cgst, sgst } = splitGST(s.subtotal||s.grand_total, s.gst_percent||0, supState, supState)
        return ['', s.party_name, s.bill_no, s.bill_date, s.grand_total,
          STATE_CODES[supState]||supState, 'N', 'B2C',
          s.gst_percent||0, taxable.toFixed(2), igst.toFixed(2), cgst.toFixed(2), sgst.toFixed(2)]
      }),
    ]
    download(rows.map(r=>r.join(',')).join('\n'), `GSTR1_${from?.slice(0,7)}.csv`, 'text/csv')
    toast.success('GSTR-1 CSV downloaded')
  }

  const COLS = [
    {key:'bill_no',label:'Invoice No',width:110},
    {key:'bill_date',label:'Date',width:90},
    {key:'party_name',label:'Receiver',width:180},
    {key:'party_gstin',label:'GSTIN',width:150,render:r=>r.party_gstin||<span className="badge-amber">B2C (No GSTIN)</span>},
    {key:'grand_total',label:'Invoice Value',width:120,right:true,render:r=><span className="font-mono">{fmtAmt(r.grand_total)}</span>},
    {key:'gst_percent',label:'Rate%',width:65,right:true},
    {key:'gst_amount',label:'Tax ₹',width:110,right:true,render:r=><span className="font-mono text-primary">{fmtAmt(r.gst_amount)}</span>},
    {key:'type',label:'Type',width:70,render:r=>r.party_gstin?.length===15?<span className="badge-blue">B2B</span>:<span className="badge-amber">B2C</span>},
  ]

  return (
    <div className="flex flex-col h-full">
      <KPIStrip cards={[
        {label:'Total Invoices',value:sales.length,sub:'in period'},
        {label:'B2B',value:b2b.length,sub:'registered buyers',accent:'blue',color:'text-primary'},
        {label:'B2C',value:b2c.length,sub:'unregistered',accent:'amber',color:'text-amber-700'},
        {label:'Total Tax',value:fmtAmtK(totTax),sub:'GST collected',accent:'green',color:'text-green-700'},
        {label:'Taxable Value',value:fmtAmtK(totVal-totTax),sub:'net of tax',accent:'slate'},
      ]}/>
      <div className="toolbar">
        <button className="btn-primary" onClick={exportGSTR1JSON}><Download size={13}/> JSON for Portal</button>
        <button className="btn-secondary" onClick={exportCSV}><Download size={13}/> Download CSV</button>
        <button className="btn-secondary" onClick={load}><RefreshCw size={13}/> Refresh</button>
        <div className="ml-auto flex items-center gap-2 text-xs text-slate-500">
          <AlertTriangle size={12} className="text-amber-500"/>
          Upload JSON to <a href="https://www.gst.gov.in" target="_blank" className="text-primary underline">gst.gov.in</a> → Returns → GSTR-1
        </div>
      </div>
      <Table columns={COLS} rows={sales} loading={loading} emptyMsg="No sales in this period."/>
      <StatusBar left={`  B2B: ${b2b.length}  ·  B2C: ${b2c.length}`}
        right={`Taxable: ${fmtAmt(totVal-totTax)}  ·  Tax: ${fmtAmt(totTax)}`}/>
    </div>
  )
}

// ── GSTR-3B Component ──────────────────────────────────────────
function GSTR3BTab({ company, from, to }) {
  const [sales, setSales]   = useState([])
  const [purch, setPurch]   = useState([])
  const [loading, setLoading] = useState(false)
  const supState = gstinState(company?.gstin)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [s,p] = await Promise.all([getSales(company.id,{from,to}), getPurchases(company.id,{from,to})])
      setSales(s); setPurch(p)
    } catch(e) { toast.error(e.message) }
    finally { setLoading(false) }
  }, [company?.id, from, to])
  useEffect(() => { load() }, [load])

  // Outward supplies
  let outB2B=0,outB2C=0,igstOut=0,cgstOut=0,sgstOut=0
  sales.forEach(s => {
    const recState = gstinState(s.party_gstin||supState)
    const { taxable, igst, cgst, sgst } = splitGST(s.subtotal||s.grand_total, s.gst_percent||0, supState, recState)
    if (s.party_gstin?.length===15) outB2B+=taxable; else outB2C+=taxable
    igstOut+=igst; cgstOut+=cgst; sgstOut+=sgst
  })
  // Input tax credit
  let igstIn=0, cgstIn=0, sgstIn=0
  purch.forEach(p => {
    const supStateP = gstinState(p.party_gstin||supState)
    const { igst, cgst, sgst } = splitGST(p.subtotal||p.grand_total, p.gst_percent||0, supStateP, supState)
    igstIn+=igst; cgstIn+=cgst; sgstIn+=sgst
  })
  const netIGST = igstOut - igstIn
  const netCGST = cgstOut - cgstIn
  const netSGST = sgstOut - sgstIn
  const netPayable = Math.max(0, netIGST) + Math.max(0, netCGST) + Math.max(0, netSGST)

  const exportJSON = () => {
    const json = {
      gstin: company?.gstin||''  ,
      ret_period: from?.slice(0,7).replace('-',''),
      sup_details: {
        osup_det: { txval:+(outB2B+outB2C).toFixed(2), iamt:+igstOut.toFixed(2), camt:+cgstOut.toFixed(2), samt:+sgstOut.toFixed(2), csamt:0 },
        osup_zero: { txval:0, iamt:0, camt:0, samt:0, csamt:0 },
        osup_nil_exmp: { txval:0 },
        isup_rev: { txval:0, iamt:0, camt:0, samt:0, csamt:0 },
        osup_nongst: { txval:0 }
      },
      itc_elg: {
        itc_avl: [
          { ty:'IMPG', iamt:0, camt:0, samt:0, csamt:0 },
          { ty:'IMPS', iamt:0, camt:0, samt:0, csamt:0 },
          { ty:'ISRC', iamt:+igstIn.toFixed(2), camt:+cgstIn.toFixed(2), samt:+sgstIn.toFixed(2), csamt:0 },
          { ty:'ISD', iamt:0, camt:0, samt:0, csamt:0 },
          { ty:'OTH', iamt:0, camt:0, samt:0, csamt:0 },
        ],
        itc_rev: [{ ty:'RUL42',iamt:0,camt:0,samt:0,csamt:0},{ty:'RUL43',iamt:0,camt:0,samt:0,csamt:0}],
        itc_net: { iamt:+igstIn.toFixed(2), camt:+cgstIn.toFixed(2), samt:+sgstIn.toFixed(2), csamt:0 },
        itc_inelg: [{ ty:'RUL42',iamt:0,camt:0,samt:0,csamt:0},{ty:'OTH',iamt:0,camt:0,samt:0,csamt:0}]
      },
      inward_sup: { isup_details:[], isup_unreg:[] },
      intr_ltfee: { intr_details:[{ty:'INTRST',iamt:0,camt:0,samt:0,csamt:0}] }
    }
    download(JSON.stringify(json,null,2), `GSTR3B_${from?.slice(0,7)}.json`, 'application/json')
    toast.success('GSTR-3B JSON downloaded')
  }

  const Row = ({label, igst, cgst, sgst, bold, highlight}) => (
    <tr className={highlight?'bg-blue-50 font-semibold':bold?'bg-slate-50 font-semibold':''}>
      <td className="px-3 py-2 text-slate-700">{label}</td>
      {[igst,cgst,sgst].map((v,i)=>(
        <td key={i} className={`px-3 py-2 text-right font-mono ${v<0?'text-green-700':v>0?'text-slate-900':'text-slate-400'}`}>
          {v===0?'—':fmtAmt(Math.abs(v))}{v<0?' (ITC)':''
          }</td>
      ))}
      <td className={`px-3 py-2 text-right font-mono font-bold ${(igst+cgst+sgst)<0?'text-green-700':'text-primary'}`}>
        {fmtAmt(Math.abs(igst+cgst+sgst))}
      </td>
    </tr>
  )

  return (
    <div className="flex flex-col h-full overflow-auto">
      <div className="toolbar">
        <button className="btn-primary" onClick={exportJSON}><Download size={13}/> JSON for Portal</button>
        <button className="btn-secondary" onClick={load}><RefreshCw size={13}/> Refresh</button>
        <div className="ml-auto text-xs text-slate-500 flex items-center gap-1">
          <AlertTriangle size={12} className="text-amber-500"/>
          Upload at <a href="https://www.gst.gov.in" target="_blank" className="text-primary underline">gst.gov.in</a> → Returns → GSTR-3B
        </div>
      </div>
      <div className="p-4 max-w-3xl space-y-4">
        <div className="card p-4">
          <div className="text-sm font-bold text-primary mb-3">3.1 — Outward Supplies (Sales)</div>
          <table className="erp-table">
            <thead><tr>
              <th className="w-64">Description</th>
              <th className="text-right">IGST ₹</th><th className="text-right">CGST ₹</th>
              <th className="text-right">SGST ₹</th><th className="text-right">Total ₹</th>
            </tr></thead>
            <tbody>
              <Row label="Taxable supplies (B2B)" igst={igstOut} cgst={cgstOut} sgst={sgstOut}/>
              <Row label="Zero-rated supplies" igst={0} cgst={0} sgst={0}/>
              <Row label="Nil / Exempt" igst={0} cgst={0} sgst={0}/>
            </tbody>
          </table>
        </div>
        <div className="card p-4">
          <div className="text-sm font-bold text-primary mb-3">4 — Eligible Input Tax Credit (Purchases)</div>
          <table className="erp-table">
            <thead><tr>
              <th className="w-64">Description</th>
              <th className="text-right">IGST ₹</th><th className="text-right">CGST ₹</th>
              <th className="text-right">SGST ₹</th><th className="text-right">Total ₹</th>
            </tr></thead>
            <tbody>
              <Row label="ITC Available (Input Goods)" igst={igstIn} cgst={cgstIn} sgst={sgstIn}/>
            </tbody>
          </table>
        </div>
        <div className="card p-4 border-primary">
          <div className="text-sm font-bold text-primary mb-3">Net Tax Payable</div>
          <table className="erp-table">
            <thead><tr>
              <th className="w-64">Description</th>
              <th className="text-right">IGST ₹</th><th className="text-right">CGST ₹</th>
              <th className="text-right">SGST ₹</th><th className="text-right">Total ₹</th>
            </tr></thead>
            <tbody>
              <Row label="Output Tax" igst={igstOut} cgst={cgstOut} sgst={sgstOut}/>
              <Row label="Less: ITC" igst={-igstIn} cgst={-cgstIn} sgst={-sgstIn}/>
              <Row label="Net Payable" igst={netIGST} cgst={netCGST} sgst={netSGST} highlight/>
            </tbody>
          </table>
          {netPayable>0&&<div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm">
            <span className="font-bold text-amber-800">⚠️  Total Tax Payable: {fmtAmt(netPayable)}</span>
            <span className="text-amber-700 ml-2">— Pay via GST portal before filing</span>
          </div>}
        </div>
      </div>
    </div>
  )
}

// ── E-Way Bill Component ───────────────────────────────────────
const UNIT_MAP = { KG:'KGS', MT:'TON', PCS:'NOS', BAG:'BAG', LOT:'OTH' }
const TRANS_MODES = { '1':'Road', '2':'Rail', '3':'Air', '4':'Ship' }
const VEHICLE_TYPES = { R:'Regular', O:'Over Dimensional Cargo' }
const SUB_SUPPLY = { '1':'Supply','2':'Import','3':'Export','4':'Job Work','5':'For Own Use','6':'Job Work Returns','7':'Sales Return','8':'Others','9':'SKD/CKD','10':'Line Sales','11':'Recipient Not Known','12':'Exhibition' }

function EWayBillTab({ company }) {
  const { company: co } = useAuth()
  const [sales, setSales] = useState([])
  const [loading, setLoading] = useState(false)
  const [selSale, setSelSale] = useState(null)
  const [form, setForm] = useState({
    sub_supply_type:'1', transaction_type:'1',
    rec_gstin:'', rec_name:'', rec_addr1:'', rec_place:'', rec_pincode:'', rec_state_code:'24',
    hsn_code:'39151000', quantity:0, unit:'KGS', vehicle_no:'', vehicle_type:'R',
    distance_km:0, transport_name:'', transport_id:'', trans_doc_no:'', trans_doc_date:'',
    supply_type:'O'
  })
  const [dlg, setDlg] = useState(false)

  useEffect(() => {
    if (!company?.id) return
    const today = new Date(); const m1 = new Date(today); m1.setMonth(m1.getMonth()-1)
    getSales(company.id, { from:m1.toISOString().slice(0,10), to:today.toISOString().slice(0,10) })
      .then(setSales).catch(e=>toast.error(e.message))
  }, [company?.id])

  const openEWB = (sale) => {
    setSelSale(sale)
    setForm(p => ({
      ...p, rec_name: sale.party_name||''  ,
      vehicle_no: sale.vehicle_no||'', transport_name: sale.transport_name||'',
      quantity: sale.total_qty||0
    }))
    setDlg(true)
  }

  const buildEWBJson = () => {
    if (!selSale) return null
    const sup = company || co
    const taxable = +(selSale.subtotal||selSale.grand_total||0).toFixed(2)
    const rate = +(selSale.gst_percent||0)
    const supState = gstinState(sup?.gstin||'24')
    const recState = form.rec_state_code||'24'
    const { igst, cgst, sgst } = splitGST(taxable, rate, supState, recState)
    return {
      supplyType: form.supply_type||'O',
      subSupplyType: +form.sub_supply_type||1,
      docType: 'INV',
      docNo: selSale.bill_no,
      docDate: selSale.bill_date?.split('-').reverse().join('/')||new Date().toLocaleDateString('en-IN'),
      fromGstin: sup?.gstin||'24AAAAA0000A1Z5',
      fromTrdName: sup?.name||'Supplier',
      fromAddr1: sup?.address||'Address',
      fromPlace: sup?.city||'City',
      fromPincode: +(sup?.pincode||'395001'),
      fromStateCode: +supState||24,
      toGstin: form.rec_gstin||'URP',
      toTrdName: form.rec_name||selSale.party_name,
      toAddr1: form.rec_addr1||'',
      toPlace: form.rec_place||'',
      toPincode: +(form.rec_pincode||'395001'),
      toStateCode: +recState||24,
      totalValue: +(selSale.grand_total||0).toFixed(2),
      cgstValue: +cgst.toFixed(2),
      sgstValue: +sgst.toFixed(2),
      igstValue: +igst.toFixed(2),
      cessValue: 0,
      transporterName: form.transport_name||selSale.transport_name||'',
      transporterId: form.transport_id||'',
      transDocNo: form.trans_doc_no||selSale.lr_no||'',
      transMode: '1',
      transDistance: +form.distance_km||1,
      vehicleNo: form.vehicle_no||selSale.vehicle_no||'',
      vehicleType: form.vehicle_type||'R',
      itemList: [{
        productName: 'Plastic Scrap',
        productDesc: 'Plastic Scrap / Waste',
        hsnCode: +(form.hsn_code||'39151000'),
        quantity: +(form.quantity||selSale.total_qty||0).toFixed(3),
        qtyUnit: UNIT_MAP[selSale.unit]||'KGS',
        taxableAmount: taxable,
        sgstRate: isInterstate(supState,recState)?0:+(rate/2).toFixed(2),
        cgstRate: isInterstate(supState,recState)?0:+(rate/2).toFixed(2),
        igstRate: isInterstate(supState,recState)?+rate.toFixed(2):0,
        cessRate: 0,
      }]
    }
  }

  const downloadEWB = () => {
    const j = buildEWBJson()
    if (!j) { toast.error('Select a sale bill'); return }
    download(JSON.stringify(j,null,2), `EWB_${selSale.bill_no}.json`, 'application/json')
    toast.success('E-Way Bill JSON downloaded — upload to ewaybillgst.gov.in')
  }

  const COLS = [
    {key:'bill_no',label:'Bill No',width:100},
    {key:'bill_date',label:'Date',width:90},
    {key:'party_name',label:'Buyer',width:200},
    {key:'total_qty',label:'Qty KG',width:80,right:true,render:r=>fmt3(r.total_qty)},
    {key:'grand_total',label:'Value ₹',width:120,right:true,render:r=><span className="font-mono">{fmtAmt(r.grand_total)}</span>},
    {key:'vehicle_no',label:'Vehicle',width:110},
    {key:'ewb_no',label:'EWB No',width:130,render:r=>r.ewb_no||<span className="text-amber-600 text-xs">Not generated</span>},
  ]
  const f = k => e => setForm(p=>({...p,[k]:e.target?.value??e}))

  return (
    <div className="flex flex-col h-full">
      <div className="toolbar flex-wrap gap-2">
        <div className="text-xs text-slate-500 flex items-center gap-1 w-full">
          <AlertTriangle size={12} className="text-amber-500 shrink-0"/>
          E-Way Bill required for goods value &gt; ₹50,000. Generate JSON here, upload at{'  '}
          <a href="https://ewaybillgst.gov.in" target="_blank" className="text-primary underline">ewaybillgst.gov.in</a>
          {'  '} or use GSP integration.
        </div>
      </div>
      <Table columns={COLS} rows={sales} loading={loading} onRowDblClick={openEWB}
        emptyMsg="No recent sales. Use last 30 days filter."/>
      <StatusBar left="Double-click a bill to generate E-Way Bill JSON"/>

      <Dialog open={dlg} onClose={()=>setDlg(false)}
        title={`🚚  E-Way Bill — ${selSale?.bill_no}`} size="lg">
        <div className="dialog-body space-y-4">
          {/* Bill summary */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 grid grid-cols-4 gap-2 text-xs">
            <div><div className="form-label">Bill No</div><div className="font-mono font-bold">{selSale?.bill_no}</div></div>
            <div><div className="form-label">Date</div><div className="font-mono">{selSale?.bill_date}</div></div>
            <div><div className="form-label">Value ₹</div><div className="font-mono font-bold text-primary">{fmtAmt(selSale?.grand_total)}</div></div>
            <div><div className="form-label">Qty KG</div><div className="font-mono">{fmt3(selSale?.total_qty)}</div></div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="form-section col-span-3">Recipient Details</div>
            <Field label="Recipient GSTIN"><input className="erp-input" value={form.rec_gstin} onChange={f('rec_gstin')} placeholder="24AAAAA0000A1Z5 or URP"/></Field>
            <Field label="Trade Name"><input className="erp-input" value={form.rec_name} onChange={f('rec_name')}/></Field>
            <Field label="State"><select className="erp-select" value={form.rec_state_code} onChange={f('rec_state_code')}>{Object.entries(STATE_CODES).map(([k,v])=><option key={k} value={k}>{k} — {v}</option>)}</select></Field>
            <Field label="Address"><input className="erp-input" value={form.rec_addr1} onChange={f('rec_addr1')}/></Field>
            <Field label="City / Place"><input className="erp-input" value={form.rec_place} onChange={f('rec_place')}/></Field>
            <Field label="Pincode"><input className="erp-input" value={form.rec_pincode} onChange={f('rec_pincode')}/></Field>
            <div className="form-section col-span-3">Transport Details</div>
            <Field label="Vehicle No"><input className="erp-input" value={form.vehicle_no} onChange={f('vehicle_no')} placeholder="GJ05AB1234"/></Field>
            <Field label="Vehicle Type"><select className="erp-select" value={form.vehicle_type} onChange={f('vehicle_type')}>{Object.entries(VEHICLE_TYPES).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></Field>
            <Field label="Distance (km)"><input type="number" className="erp-input font-mono" value={form.distance_km} onChange={f('distance_km')}/></Field>
            <Field label="Transporter Name"><input className="erp-input" value={form.transport_name} onChange={f('transport_name')}/></Field>
            <Field label="LR / GR No"><input className="erp-input" value={form.trans_doc_no} onChange={f('trans_doc_no')}/></Field>
            <Field label="LR Date"><input type="date" className="erp-input" value={form.trans_doc_date} onChange={f('trans_doc_date')}/></Field>
            <div className="form-section col-span-3">Item Details</div>
            <Field label="HSN Code"><input className="erp-input font-mono" value={form.hsn_code} onChange={f('hsn_code')}/></Field>
            <Field label="Quantity KG"><input type="number" className="erp-input font-mono" value={form.quantity} onChange={f('quantity')}/></Field>
            <Field label="Sub-Supply Type"><select className="erp-select" value={form.sub_supply_type} onChange={f('sub_supply_type')}>{Object.entries(SUB_SUPPLY).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></Field>
          </div>
          <div className="bg-slate-50 rounded-lg p-3 text-xs text-slate-600 space-y-1">
            <div className="font-semibold text-slate-700">Steps to activate E-Way Bill:</div>
            <div>1. Download JSON → upload to <a href="https://ewaybillgst.gov.in" className="text-primary underline" target="_blank">ewaybillgst.gov.in</a> → API → Generate EWB</div>
            <div>2. Or use a GSP (GST Suvidha Provider) like Masters India / HDFC / Axis — they have direct API</div>
            <div>3. Enter the EWB number received into the Sales Bill for tracking</div>
          </div>
        </div>
        <div className="dialog-footer">
          <button className="btn-cancel" onClick={()=>setDlg(false)}>Close</button>
          <button className="btn-secondary" onClick={()=>{const j=buildEWBJson();if(j){navigator.clipboard.writeText(JSON.stringify(j,null,2));toast.success('JSON copied to clipboard')}}}>📋 Copy JSON</button>
          <button className="btn-save" onClick={downloadEWB}><Download size={14}/> Download JSON</button>
        </div>
      </Dialog>
    </div>
  )
}

// ── E-Invoice Component ────────────────────────────────────────
function EInvoiceTab({ company }) {
  const [sales, setSales] = useState([])
  const [selSale, setSelSale] = useState(null)
  const [dlg, setDlg] = useState(false)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!company?.id) return
    const today = new Date(); const m1 = new Date(today); m1.setMonth(m1.getMonth()-1)
    getSales(company.id, { from:m1.toISOString().slice(0,10), to:today.toISOString().slice(0,10) })
      .then(setSales).catch(e=>toast.error(e.message))
  }, [company?.id])

  const buildEInvoiceJson = (sale) => {
    if (!sale) return null
    const sup = company
    const supState = gstinState(sup?.gstin||'24')
    const recState = gstinState(sale.party_gstin||supState)
    const taxable = +(sale.subtotal||sale.grand_total||0).toFixed(2)
    const rate = +(sale.gst_percent||0)
    const { igst, cgst, sgst } = splitGST(taxable, rate, supState, recState)
    const items = (sale.items||[]).map((it,i) => {
      const itTaxable = +(it.amount||0).toFixed(2)
      const { igst:ii, cgst:ci, sgst:si } = splitGST(itTaxable, rate, supState, recState)
      return {
        SlNo: String(i+1),
        PrdDesc: it.item_name||'Plastic Scrap',
        IsServc: 'N',
        HsnCd: it.hsn_code||'39151000',
        Qty: +(it.actual_wt||it.quantity||0).toFixed(3),
        Unit: 'KGS',
        UnitPrice: +(it.rate||0).toFixed(2),
        TotAmt: itTaxable,
        Discount: 0,
        AssAmt: itTaxable,
        GstRt: rate,
        IgstAmt: +ii.toFixed(2),
        CgstAmt: +ci.toFixed(2),
        SgstAmt: +si.toFixed(2),
        CesRt: 0, CesAmt: 0, CesNonAdvlAmt: 0,
        StateCesRt: 0, StateCesAmt: 0, StateCesNonAdvlAmt: 0,
        OthChrg: 0,
        TotItemVal: +(itTaxable + ii + ci + si).toFixed(2),
      }
    })
    if (!items.length) items.push({
      SlNo:'1', PrdDesc:'Plastic Scrap / Waste', IsServc:'N',
      HsnCd:'39151000', Qty:+(sale.total_qty||0).toFixed(3), Unit:'KGS',
      UnitPrice:+(taxable/(sale.total_qty||1)).toFixed(2), TotAmt:taxable,
      Discount:0, AssAmt:taxable, GstRt:rate,
      IgstAmt:+igst.toFixed(2), CgstAmt:+cgst.toFixed(2), SgstAmt:+sgst.toFixed(2),
      CesRt:0, CesAmt:0, CesNonAdvlAmt:0, StateCesRt:0, StateCesAmt:0, StateCesNonAdvlAmt:0,
      OthChrg:0, TotItemVal:+(taxable+igst+cgst+sgst).toFixed(2),
    })

    return {
      Version: '1.1',
      TranDtls: {
        TaxSch: 'GST', SupTyp: 'B2B',
        RegRev: 'N', EcmGstn: null, IgstOnIntra: 'N'
      },
      DocDtls: {
        Typ: 'INV',
        No: sale.bill_no,
        Dt: sale.bill_date?.split('-').reverse().join('/')||''
      },
      SellerDtls: {
        Gstin: sup?.gstin||'24AAAAA0000A1Z5',
        LglNm: sup?.name||'Seller',
        TrdNm: sup?.name||'Seller',
        Addr1: sup?.address||'Address',
        Loc: sup?.city||'City',
        Pin: +(sup?.pincode||'395001'),
        Stcd: supState,
        Ph: sup?.phone||'',
        Em: sup?.email||''
      },
      BuyerDtls: {
        Gstin: sale.party_gstin||'URP',
        LglNm: sale.party_name||'Buyer',
        TrdNm: sale.party_name||'Buyer',
        Pos: recState,
        Addr1: '',
        Loc: '',
        Pin: 395001,
        Stcd: recState,
        Ph: '', Em: ''
      },
      ValDtls: {
        AssVal: taxable,
        CgstVal: +cgst.toFixed(2),
        SgstVal: +sgst.toFixed(2),
        IgstVal: +igst.toFixed(2),
        CesVal: 0, StCesVal: 0, Discount: 0,
        OthChrg: +(sale.charges||0).toFixed(2),
        RndOffAmt: 0,
        TotInvVal: +(sale.grand_total||0).toFixed(2),
        TotInvValFc: 0
      },
      PayDtls: { Nm:'', Accdet:'', Mode:'', Finins:'', Payterm:'', Paytime:'', Payloc:'', CrDay:0, DirDr:'', CrTransDt:'' },
      RefDtls: { InvRm:'', DocPerdDtls:{ InvStDt:'', InvEndDt:'' }, PrecDocDtls:[{InvNo:'',InvDt:'',OthRefNo:''}], ContrDtls:[{RecAdvRefr:'',RecAdvDt:'',TendRefr:'',ContrRefr:'',ExtRefr:'',ProjRefr:'',PORefr:'',PORefDt:''}] },
      AddlDocDtls: { Url:'', Docs:'', Info:'' },
      ExpDtls: { ShipBNo:'', ShipBDt:'', Port:'', RefClm:'', ForCur:'', CntCode:'', ExpDuty:null },
      EwbDtls: { TransId:'', TransName: sale.transport_name||'', Distance:0, TransDocNo: sale.lr_no||'', TransDocDt:'', VehNo: sale.vehicle_no||'', VehType:'R', TransMode:'1' },
      ItemList: items
    }
  }

  const openDlg = (sale) => { setSelSale(sale); setDlg(true) }

  const downloadJSON = () => {
    const j = buildEInvoiceJson(selSale)
    if (!j) return
    download(JSON.stringify(j,null,2), `EInvoice_${selSale.bill_no}.json`, 'application/json')
    toast.success('E-Invoice JSON downloaded — upload to IRP portal')
  }

  const COLS = [
    {key:'bill_no',label:'Invoice No',width:110},
    {key:'bill_date',label:'Date',width:90},
    {key:'party_name',label:'Buyer',width:190},
    {key:'party_gstin',label:'Buyer GSTIN',width:150,
      render:r=>r.party_gstin||<span className="badge-red">No GSTIN</span>},
    {key:'grand_total',label:'Value ₹',width:120,right:true,render:r=><span className="font-mono">{fmtAmt(r.grand_total)}</span>},
    {key:'irn',label:'IRN Status',width:130,
      render:r=>r.irn?<span className="badge-green">IRN Generated</span>:<span className="badge-amber">Pending</span>},
  ]

  return (
    <div className="flex flex-col h-full">
      <div className="toolbar flex-wrap">
        <div className="text-xs text-slate-600 bg-amber-50 border border-amber-200 rounded px-3 py-2 w-full">
          <span className="font-bold text-amber-800">📋  E-Invoice (IRP) Info: </span>
          Mandatory for turnover &gt; ₹5 Crore. Generate JSON here → upload to{'  '}
          <a href="https://einvoice1.gst.gov.in" target="_blank" className="text-primary underline">einvoice1.gst.gov.in</a>
          {'  '} or use GSP API (Masters India / Cleartax / GSTN sandbox).
        </div>
      </div>
      <Table columns={COLS} rows={sales} loading={loading} onRowDblClick={openDlg}
        emptyMsg="No recent sales. Double-click a bill to generate E-Invoice JSON."/>
      <StatusBar left="Double-click any bill to generate IRP-compatible E-Invoice JSON"/>

      <Dialog open={dlg} onClose={()=>setDlg(false)}
        title={`📄  E-Invoice — ${selSale?.bill_no}`} size="lg">
        <div className="dialog-body space-y-3">
          <div className="bg-blue-50 border border-blue-200 rounded p-3 grid grid-cols-4 gap-2 text-xs">
            <div><div className="form-label">Invoice No</div><div className="font-mono font-bold">{selSale?.bill_no}</div></div>
            <div><div className="form-label">Date</div><div className="font-mono">{selSale?.bill_date}</div></div>
            <div><div className="form-label">Buyer</div><div className="font-semibold">{selSale?.party_name}</div></div>
            <div><div className="form-label">Value ₹</div><div className="font-mono font-bold text-primary">{fmtAmt(selSale?.grand_total)}</div></div>
          </div>
          {!selSale?.party_gstin&&(
            <div className="bg-red-50 border border-red-200 rounded p-3 text-sm text-red-700">
              ⚠️  This buyer has no GSTIN. E-Invoice (B2B) requires buyer GSTIN.
              Add GSTIN in <strong>Parties</strong> module first.
            </div>
          )}
          <div className="bg-slate-800 text-green-300 rounded-lg p-3 font-mono text-xs overflow-auto max-h-64">
            <pre>{JSON.stringify(buildEInvoiceJson(selSale),null,2)?.slice(0,1500)}...</pre>
          </div>
          <div className="bg-slate-50 rounded p-3 text-xs text-slate-600 space-y-1">
            <div className="font-semibold">After generating IRN from IRP portal:</div>
            <div>1. Download the signed invoice + QR code from IRP</div>
            <div>2. Store the IRN in your bill (update party in Sales Bills)</div>
            <div>3. Print QR code on invoice (mandatory)</div>
          </div>
        </div>
        <div className="dialog-footer">
          <button className="btn-cancel" onClick={()=>setDlg(false)}>Close</button>
          <button className="btn-secondary" onClick={()=>{const j=buildEInvoiceJson(selSale);if(j){navigator.clipboard.writeText(JSON.stringify(j,null,2));toast.success('JSON copied')}}}>📋  Copy JSON</button>
          <button className="btn-save" onClick={downloadJSON}><Download size={14}/> Download JSON</button>
        </div>
      </Dialog>
    </div>
  )
}

// ── Download helper ────────────────────────────────────────────
function download(content, filename, type) {
  const a = document.createElement('a')
  a.href = URL.createObjectURL(new Blob([content], { type }))
  a.download = filename; a.click()
}

// ── Main GST Compliance Module ─────────────────────────────────
export default function GSTCompliance() {
  const { company } = useAuth()
  const fyStart = company?.fy_start||'2024-04-01'
  const fyEnd   = company?.fy_end  ||'2025-03-31'
  const [tab,   setTab]  = useState('gstr1')
  const [from,  setFrom] = useState(new Date().toISOString().slice(0,7)+'-01')
  const [to,    setTo]   = useState(new Date().toISOString().slice(0,10))

  return (
    <div className="flex flex-col h-full">
      {/* Header + period selector */}
      <div className="px-4 py-2 bg-white border-b border-slate-200 flex items-center gap-4 flex-wrap flex-shrink-0">
        <div className="text-xs font-bold text-slate-500 uppercase tracking-wide">Period:</div>
        <div className="flex items-center gap-2">
          <input type="date" className="erp-input !w-36 !py-1" value={from} onChange={e=>setFrom(e.target.value)}/>
          <span className="text-slate-400">to</span>
          <input type="date" className="erp-input !w-36 !py-1" value={to}   onChange={e=>setTo(e.target.value)}/>
        </div>
        <div className="flex gap-1">
          {['Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar'].map((m,i)=>{
            const fy = new Date().getFullYear()
            const yr = i<9 ? fy : fy-1
            const mm = String(i+4>12?i+4-12:i+4).padStart(2,'0')
            const y  = i+4>12?fy+1:fy
            return (
              <button key={m} onClick={()=>{
                setFrom(`${yr}-${mm}-01`)
                const last = new Date(y, i+4>12?i+4-12:i+4, 0).getDate()
                setTo(`${y}-${mm}-${last}`)
              }} className="btn-secondary !py-0.5 !px-2 !text-[10px]">{m}</button>
            )
          })}
        </div>
      </div>
      {/* Tab selector */}
      <div className="px-4 pt-2 bg-white border-b border-slate-200 flex gap-1 flex-shrink-0">
        {TABS.map(t=>(
          <button key={t.value} onClick={()=>setTab(t.value)}
            className={`px-4 py-2 text-[11px] font-semibold rounded-t-md border border-b-0 transition-colors
              ${tab===t.value?'bg-white text-primary border-slate-200':'bg-slate-50 text-slate-500 border-transparent hover:bg-slate-100'}`}>
            {t.label}
          </button>
        ))}
      </div>
      {/* Tab content */}
      <div className="flex-1 overflow-hidden flex flex-col">
        {tab==='gstr1'   && <GSTR1Tab   company={company} from={from} to={to}/>}
        {tab==='gstr3b'  && <GSTR3BTab  company={company} from={from} to={to}/>}
        {tab==='eway'    && <EWayBillTab company={company}/>}
        {tab==='einvoice'&& <EInvoiceTab company={company}/>}
      </div>
    </div>
  )
}
