// src/components/modules/Sales.jsx
import { useState, useEffect, useCallback } from 'react'
import { getSales, addSale, updateSale, deleteSale, getParties, getItems } from '@/lib/db'
import { useAuth } from '@/contexts/AuthContext'
import { Dialog, Table, Toolbar, SearchBar, StatusBar, KPIStrip,
         Field, Select, Confirm, Badge, Loading, FilterTabs, fmtAmt, fmtAmtK } from '@/components/ui'
import { Plus, Edit2, Trash2, RefreshCw, Printer } from 'lucide-react'
import { toast } from '@/components/ui'
import { exportBillPDF } from '@/lib/pdf'

const COLS = [
  { key:'bill_no',     label:'BILL NO',    width:90 },
  { key:'bill_date',   label:'DATE',       width:95 },
  { key:'party_name',  label:'PARTY',      width:200 },
  { key:'total_qty',   label:'QTY KG',     width:90,  right:true, render:r=><span className="font-mono">{(+r.total_qty||0).toFixed(1)}</span> },
  { key:'grand_total', label:'AMOUNT ₹',   width:120, right:true, render:r=><span className="font-mono">{fmtAmt(r.grand_total)}</span> },
  { key:'outstanding', label:'OUTSTANDING', width:120, right:true,
    render:r=><span className={`font-mono font-bold ${(+r.outstanding||0)>0.01?'text-red-600':'text-green-700'}`}>{fmtAmt(r.outstanding)}</span> },
  { key:'transport_name', label:'TRANSPORT', width:120 },
]

function BillDialog({ open, onClose, onSaved, editing, parties, items }) {
  const { company } = useAuth()
  const today = new Date().toISOString().slice(0,10)
  const EMPTY_HDR  = { party_id:'', party_name:'', party_gstin:'', bill_date:today, transport_name:'', vehicle_no:'', lr_no:'', remarks:'', gst_percent:0, discount:0, supply_type:'B2B', place_of_supply:'24' }
  const EMPTY_ITEM = { item_id:'', item_name:'', gross_wt:0, tare_wt:0, net_wt:0, moisture_pct:0, moisture_deduct:0, actual_wt:0, quantity:0, rate:0, amount:0, quality_grade:'A Grade' }

  const [hdr,  setHdr]  = useState(EMPTY_HDR)
  const [rows, setRows] = useState([{ ...EMPTY_ITEM }])
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!open) return
    if (editing) {
      setHdr({ party_id:editing.party_id||'', party_name:editing.party_name||'', party_gstin:editing.party_gstin||'',
               bill_date:editing.bill_date||today, transport_name:editing.transport_name||'',
               vehicle_no:editing.vehicle_no||'', lr_no:editing.lr_no||'',
               remarks:editing.remarks||'', gst_percent:editing.gst_percent||0, discount:editing.discount||0,
               supply_type:editing.supply_type||'B2B', place_of_supply:editing.place_of_supply||'24' })
      setRows((editing.items||[]).length>0 ? editing.items.map(it=>({...EMPTY_ITEM,...it})) : [{ ...EMPTY_ITEM }])
    } else { setHdr(EMPTY_HDR); setRows([{ ...EMPTY_ITEM }]) }
  }, [open, editing?.id])

  const h = k => e => setHdr(p=>({ ...p, [k]: e.target?.value??e }))

  const onParty = id => {
    const p = parties.find(x=>x.id===id)
    setHdr(prev=>({ ...prev, party_id:id, party_name:p?.name||'', party_gstin:p?.gstin||'', place_of_supply:(p?.state_code||'24') }))
  }

  const setRow = (i, k, v) => {
    setRows(prev => {
      const next=[...prev]; next[i]={...next[i],[k]:v}
      const r=next[i]
      const gross=+r.gross_wt||0, tare=+r.tare_wt||0, net=gross-tare
      const mDeduct=net*((+r.moisture_pct||0)/100), actual=net-mDeduct
      next[i]={ ...next[i], net_wt:+net.toFixed(3), moisture_deduct:+mDeduct.toFixed(3),
                actual_wt:+actual.toFixed(3), quantity:+actual.toFixed(3), amount:+(actual*(+r.rate||0)).toFixed(2) }
      return next
    })
  }

  const onItem = (i, id) => {
    const it = items.find(x=>x.id===id)
    setRows(prev=>{ const next=[...prev]; next[i]={...next[i],item_id:id,item_name:it?.name||'',moisture_pct:it?.moisture_pct||0,rate:it?.rate||0}; return next })
  }

  const subtotal   = rows.reduce((s,r)=>s+(+r.amount||0),0)
  const gstAmt     = subtotal*((+hdr.gst_percent||0)/100)
  const grandTotal = subtotal+gstAmt-(+hdr.discount||0)
  const totalQty   = rows.reduce((s,r)=>s+(+r.actual_wt||0),0)

  const save = async () => {
    if (!hdr.party_id) { toast.error('Select a party'); return }
    if (rows.every(r=>!r.item_id)) { toast.error('Add at least one item'); return }
    setSaving(true)
    try {
      const billData = { ...hdr, gst_percent:+hdr.gst_percent||0, discount:+hdr.discount||0,
                         subtotal, gst_amount:gstAmt, grand_total:grandTotal,
                         total_qty:totalQty, outstanding:grandTotal, paid_amount:0 }
      const validRows = rows.filter(r=>r.item_id)
      if (editing) { await updateSale(editing.id, billData, validRows); toast.success('Bill updated') }
      else         { const r=await addSale(company.id, billData, validRows); toast.success(`Bill saved: ${r.bill_no}`) }
      onSaved?.(); onClose()
    } catch(e) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const GRADES = ['A Grade','B Grade','C Grade','Mixed','Rejection']

  return (
    <Dialog open={open} onClose={onClose}
      title={editing ? `✏️  Edit Bill — ${editing.bill_no}` : '➕  New Sales Bill'}
      size="xl" hint="Esc · Cancel">
      <div className="dialog-body space-y-4">
        <div className="grid grid-cols-4 gap-3">
          <Field label="Party *" className="col-span-2">
            <Select value={hdr.party_id} onChange={onParty} placeholder="Select Party…"
              options={parties.map(p=>({value:p.id,label:p.name}))}/>
          </Field>
          <Field label="Date *">
            <input type="date" className="erp-input" value={hdr.bill_date} onChange={h('bill_date')}/>
          </Field>
          <Field label="Vehicle No">
            <input className="erp-input" value={hdr.vehicle_no} onChange={h('vehicle_no')} placeholder="GJ05AB1234"/>
          </Field>
          <Field label="Transport Name" className="col-span-2">
            <input className="erp-input" value={hdr.transport_name} onChange={h('transport_name')}/>
          </Field>
          <Field label="LR No">
            <input className="erp-input" value={hdr.lr_no} onChange={h('lr_no')}/>
          </Field>
          <Field label="Remarks">
            <input className="erp-input" value={hdr.remarks} onChange={h('remarks')}/>
          </Field>
        </div>

        <div className="form-section">Material Items</div>
        <div className="border border-slate-200 rounded-lg overflow-x-auto">
          <table className="w-full text-[11px]">
            <thead className="bg-slate-800 text-slate-400">
              <tr>{['Material','Gross KG','Tare KG','Net KG','Moist%','Actual KG','Rate ₹','Amount ₹','Grade',''].map(h=>(
                <th key={h} className="px-2 py-2 text-left font-bold text-[9px] uppercase tracking-wide">{h}</th>
              ))}</tr>
            </thead>
            <tbody>
              {rows.map((r,i)=>(
                <tr key={i} className="border-t border-slate-100">
                  <td className="px-1 py-1">
                    <Select value={r.item_id} onChange={v=>onItem(i,v)} placeholder="Select…"
                      options={items.map(it=>({value:it.id,label:it.name+(it.colour?` - ${it.colour}`:'')})) }
                      className="!w-40 !text-[11px] !py-1"/>
                  </td>
                  {['gross_wt','tare_wt','net_wt','moisture_pct','actual_wt','rate','amount'].map(k=>(
                    <td key={k} className="px-1 py-1">
                      <input type="number" step="0.001"
                        className="erp-input !text-[11px] !py-1 !w-20 text-right font-mono"
                        value={r[k]||0}
                        readOnly={['net_wt','moisture_deduct','actual_wt','amount'].includes(k)}
                        onChange={e=>setRow(i,k,e.target.value)}/>
                    </td>
                  ))}
                  <td className="px-1">
                    <Select value={r.quality_grade||'A Grade'} onChange={v=>setRow(i,'quality_grade',v)} options={GRADES} placeholder="" className="!w-24 !text-[11px] !py-1"/>
                  </td>
                  <td className="px-1">
                    <button onClick={()=>setRows(p=>p.filter((_,j)=>j!==i))} className="text-red-400 hover:text-red-600 px-1 text-lg leading-none">×</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button onClick={()=>setRows(p=>[...p,{...EMPTY_ITEM}])} className="btn-secondary m-2 text-[11px]">
            <Plus size={11}/> Add Item
          </button>
        </div>

        <div className="flex justify-end">
          <div className="w-72 space-y-1.5 text-[13px]">
            {[['Subtotal:',`₹${subtotal.toFixed(2)}`],['Total Qty:',`${totalQty.toFixed(3)} KG`]].map(([k,v])=>(
              <div key={k} className="flex justify-between text-slate-500">
                <span>{k}</span><span className="font-mono">{v}</span>
              </div>
            ))}
            <div className="flex justify-between items-center text-slate-500">
              <span>GST %:</span>
              <input type="number" className="erp-input !w-16 !py-0.5 !text-xs text-right font-mono"
                value={hdr.gst_percent} onChange={h('gst_percent')}/>
            </div>
            <div className="flex justify-between items-center text-slate-500">
              <span>Discount ₹:</span>
              <input type="number" className="erp-input !w-24 !py-0.5 !text-xs text-right font-mono"
                value={hdr.discount} onChange={h('discount')}/>
            </div>
            <div className="flex justify-between font-bold text-primary border-t border-blue-200 pt-2 text-base">
              <span>Grand Total:</span>
              <span className="font-mono">₹{grandTotal.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
      <div className="dialog-footer">
        <button className="btn-cancel" onClick={onClose}>Cancel</button>
        <button className="btn-save" onClick={save} disabled={saving}>
          {saving?'Saving…':'💾  Save Bill'}
        </button>
      </div>
    </Dialog>
  )
}

export default function Sales() {
  const { company } = useAuth()
  const fyStart = company?.fy_start||'2024-04-01', fyEnd = company?.fy_end||'2025-03-31'
  const [rows,    setRows]    = useState([])
  const [loading, setLoading] = useState(true)
  const [from,    setFrom]    = useState(fyStart)
  const [to,      setTo]      = useState(fyEnd)
  const [search,  setSearch]  = useState('')
  const [selId,   setSelId]   = useState(null)
  const [dialog,  setDialog]  = useState(false)
  const [editing, setEditing] = useState(null)
  const [delDlg,  setDelDlg]  = useState(false)
  const [parties, setParties] = useState([])
  const [items,   setItems]   = useState([])

  useEffect(() => {
    if (!company) return
    Promise.all([getParties(company.id), getItems(company.id)]).then(([p,i])=>{ setParties(p); setItems(i) })
  }, [company?.id])

  const load = useCallback(async () => {
    if (!company) return
    setLoading(true)
    try { setRows(await getSales(company.id, { from, to, search })) }
    catch(e) { toast.error(e.message) }
    finally { setLoading(false) }
  }, [company?.id, from, to, search])

  useEffect(() => { load() }, [load])

  const openEdit = () => {
    const row = rows.find(r=>r.id===selId)
    if (!row) { toast.error('Select a bill first'); return }
    setEditing(row); setDialog(true)
  }

  const doDelete = async () => {
    try { await deleteSale(selId); toast.success('Bill deleted'); setDelDlg(false); setSelId(null); load() }
    catch(e) { toast.error(e.message) }
  }

  const doPrint = () => {
    const row = rows.find(r=>r.id===selId)
    if (!row) { toast.error('Select a bill to print'); return }
    try { exportBillPDF(row, company) } catch(e) { toast.error(e.message) }
  }

  const tot = rows.reduce((s,r)=>s+(+r.grand_total||0),0)
  const out = rows.reduce((s,r)=>s+(+r.outstanding||0),0)
  const qty = rows.reduce((s,r)=>s+(+r.total_qty||0),0)

  return (
    <div className="flex flex-col h-full">
      <KPIStrip cards={[
        { icon:'🧾', label:'Total Bills',   value:rows.length,    sub:'in period',       accent:'blue' },
        { icon:'⚖️', label:'Total Qty KG',  value:`${qty.toFixed(0)}`, sub:'net weight', accent:'slate' },
        { icon:'💰', label:'Grand Total ₹', value:fmtAmtK(tot),   sub:'billed',         accent:'blue' },
        { icon:'⏳', label:'Outstanding ₹', value:fmtAmtK(out),   sub:'pending',        accent:'red' },
      ]}/>
      <Toolbar hint="Ctrl+N New  ·  Ctrl+P Print  ·  Del Delete">
        <button className="btn-primary"   onClick={()=>{setEditing(null);setDialog(true)}}><Plus size={13}/>  New Bill</button>
        <button className="btn-secondary" onClick={openEdit}><Edit2 size={13}/>  Edit</button>
        <button className="btn-secondary" onClick={doPrint}><Printer size={13}/>  Print/PDF</button>
        <button className="btn-danger"    onClick={()=>selId&&setDelDlg(true)}><Trash2 size={13}/>  Delete</button>
        <button className="btn-secondary" onClick={load}><RefreshCw size={12}/>  Refresh</button>
      </Toolbar>
      <SearchBar from={from} to={to} onFrom={setFrom} onTo={setTo} search={search} onSearch={setSearch}/>
      {loading ? <Loading/> : (
        <Table columns={COLS} rows={rows} selectedId={selId}
          onRowClick={r=>setSelId(r.id)}
          onRowDblClick={r=>{setSelId(r.id);setTimeout(openEdit,10)}}
          emptyMsg="No sales bills found. Click ➕ New Bill to create one."/>
      )}
      <StatusBar left={`  Bills: ${rows.length}  ·  Qty: ${qty.toFixed(1)} KG`}
                 right={`${fmtAmt(tot)} total  ·  ${fmtAmt(out)} outstanding`}/>
      <BillDialog open={dialog} onClose={()=>setDialog(false)} onSaved={load}
                  editing={editing} parties={parties} items={items}/>
      <Confirm open={delDlg} onCancel={()=>setDelDlg(false)} onConfirm={doDelete}
               message={`Delete bill "${rows.find(r=>r.id===selId)?.bill_no}"? Cannot be undone.`}/>
    </div>
  )
}
