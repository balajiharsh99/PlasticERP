-- ================================================================
-- GST Compliance Schema — Add-on to main schema
-- Run in Supabase SQL Editor AFTER the main schema
-- ================================================================

-- E-Way Bills
create table if not exists eway_bills (
  id              bigserial primary key,
  company_id      uuid          not null references companies(id) on delete cascade,
  ewb_no          text          not null default '',
  ewb_date        text          not null default '',
  bill_id         bigint,
  bill_type       text          not null default 'SALE',
  bill_no         text          not null default '',
  bill_date       date          not null,
  doc_type        text          not null default 'INV',
  transaction_type integer      not null default 1,
  sup_gstin       text          not null default '',
  sup_name        text          not null default '',
  sup_addr1       text          not null default '',
  sup_addr2       text          not null default '',
  sup_place       text          not null default '',
  sup_pincode     text          not null default '',
  sup_state_code  text          not null default '24',
  rec_gstin       text          not null default '',
  rec_name        text          not null default '',
  rec_addr1       text          not null default '',
  rec_place       text          not null default '',
  rec_pincode     text          not null default '',
  rec_state_code  text          not null default '24',
  item_name       text          not null default '',
  hsn_code        text          not null default '39151000',
  quantity        numeric(12,3) not null default 0,
  unit            text          not null default 'KGS',
  taxable_value   numeric(15,2) not null default 0,
  cgst_rate       numeric(5,2)  not null default 0,
  sgst_rate       numeric(5,2)  not null default 0,
  igst_rate       numeric(5,2)  not null default 0,
  cess_rate       numeric(5,2)  not null default 0,
  transport_id    text          not null default '',
  transport_name  text          not null default '',
  trans_doc_no    text          not null default '',
  trans_doc_date  text          not null default '',
  vehicle_no      text          not null default '',
  vehicle_type    text          not null default 'R',
  distance_km     integer       not null default 0,
  supply_type     text          not null default 'O',
  sub_supply_type text          not null default '1',
  status          text          not null default 'DRAFT',
  json_payload    text          not null default '',
  created_at      timestamptz default now()
);
alter table eway_bills enable row level security;
create policy "eway_bills_own" on eway_bills
  for all using (company_id = my_company_id() or auth.uid() is not null);

-- E-Invoices (IRN)
create table if not exists einvoices (
  id              bigserial primary key,
  company_id      uuid          not null references companies(id) on delete cascade,
  sale_id         bigint,
  bill_no         text          not null default '',
  bill_date       date          not null,
  irn             text          not null default '',
  ack_no          text          not null default '',
  ack_date        text          not null default '',
  signed_invoice  text          not null default '',
  signed_qr_code  text          not null default '',
  status          text          not null default 'PENDING',
  json_payload    text          not null default '',
  error_details   text          not null default '',
  created_at      timestamptz default now()
);
alter table einvoices enable row level security;
create policy "einvoices_own" on einvoices
  for all using (company_id = my_company_id() or auth.uid() is not null);

-- GST Returns tracking
create table if not exists gst_returns (
  id            bigserial primary key,
  company_id    uuid    not null references companies(id) on delete cascade,
  return_type   text    not null default 'GSTR1',
  period        text    not null default '',
  filing_date   date,
  status        text    not null default 'PENDING',
  json_payload  text    not null default '',
  arn           text    not null default '',
  created_at    timestamptz default now()
);
alter table gst_returns enable row level security;
create policy "gst_returns_own" on gst_returns
  for all using (company_id = my_company_id() or auth.uid() is not null);

-- Update sales table to add GST detail columns
alter table sales
  add column if not exists supply_type   text not null default 'B2B',
  add column if not exists place_of_supply text not null default '24',
  add column if not exists reverse_charge boolean not null default false,
  add column if not exists cgst_amount   numeric(15,2) not null default 0,
  add column if not exists sgst_amount   numeric(15,2) not null default 0,
  add column if not exists igst_amount   numeric(15,2) not null default 0,
  add column if not exists cess_amount   numeric(15,2) not null default 0,
  add column if not exists irn           text not null default '',
  add column if not exists ewb_no        text not null default '',
  add column if not exists ewb_date      text not null default '';

-- Update sale_items to add HSN
alter table sale_items
  add column if not exists hsn_code    text not null default '39151000',
  add column if not exists cgst_rate   numeric(5,2) not null default 0,
  add column if not exists sgst_rate   numeric(5,2) not null default 0,
  add column if not exists igst_rate   numeric(5,2) not null default 0,
  add column if not exists taxable_val numeric(15,2) not null default 0;

-- Update purchases similarly
alter table purchases
  add column if not exists supply_type    text not null default 'B2B',
  add column if not exists place_of_supply text not null default '24',
  add column if not exists reverse_charge  boolean not null default false,
  add column if not exists cgst_amount    numeric(15,2) not null default 0,
  add column if not exists sgst_amount    numeric(15,2) not null default 0,
  add column if not exists igst_amount    numeric(15,2) not null default 0;

-- Update parties to add GSTIN verification flag
alter table parties
  add column if not exists gstin_status  text not null default 'UNVERIFIED',
  add column if not exists gstin_type    text not null default 'REGULAR';

-- Update items with GST rate
alter table items
  add column if not exists gst_rate     numeric(5,2) not null default 5.0,
  add column if not exists cgst_rate    numeric(5,2) not null default 2.5,
  add column if not exists sgst_rate    numeric(5,2) not null default 2.5,
  add column if not exists igst_rate    numeric(5,2) not null default 5.0,
  add column if not exists cess_rate    numeric(5,2) not null default 0;

-- Indexes
create index if not exists idx_eway_company    on eway_bills(company_id, bill_date desc);
create index if not exists idx_einvoice_company on einvoices(company_id, bill_date desc);
