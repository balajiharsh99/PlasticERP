-- ================================================================
-- Plastic Scrap ERP  —  Supabase Schema  v2.0  (FIXED)
-- Run the ENTIRE script at once in Supabase SQL Editor
-- Tables first, RLS policies last — no circular dependency
-- ================================================================

-- Extensions
create extension if not exists "pgcrypto";

-- ── Drop old policies if re-running ────────────────────────────
do $$ declare
  r record;
begin
  for r in (select policyname, tablename from pg_policies where schemaname = 'public') loop
    execute format('drop policy if exists %I on %I', r.policyname, r.tablename);
  end loop;
end $$;

-- ════════════════════════════════════════════════════════════════
-- STEP 1: CREATE ALL TABLES (no RLS yet)
-- ════════════════════════════════════════════════════════════════

-- Profiles (references auth.users — built into Supabase)
create table if not exists profiles (
  id           uuid primary key references auth.users on delete cascade,
  company_id   uuid,
  display_name text    not null default 'Admin',
  role         text    not null default 'admin',
  created_at   timestamptz default now()
);

-- Companies
create table if not exists companies (
  id         uuid primary key default gen_random_uuid(),
  name       text not null,
  gstin      text not null default '',
  pan        text not null default '',
  address    text not null default '',
  city       text not null default '',
  state      text not null default 'Gujarat',
  phone      text not null default '',
  email      text not null default '',
  fy_start   date not null default '2024-04-01',
  fy_end     date not null default '2025-03-31',
  currency   text not null default 'INR',
  created_at timestamptz default now()
);

-- Add FK from profiles → companies (after companies exists)
alter table profiles
  drop constraint if exists profiles_company_id_fkey,
  add  constraint profiles_company_id_fkey
       foreign key (company_id) references companies(id) on delete set null;

-- Sequences
create table if not exists sequences (
  company_id  uuid    not null references companies(id) on delete cascade,
  seq_name    text    not null,
  prefix      text    not null default '',
  suffix      text    not null default '',
  last_num    integer not null default 0,
  pad_len     integer not null default 4,
  primary key (company_id, seq_name)
);

-- Master Lists
create table if not exists master_lists (
  id         bigserial primary key,
  company_id uuid    not null references companies(id) on delete cascade,
  list_name  text    not null,
  value      text    not null,
  sort_order integer not null default 0,
  is_active  boolean not null default true,
  unique (company_id, list_name, value)
);

-- Bill Series
create table if not exists bill_series (
  id           bigserial primary key,
  company_id   uuid    not null references companies(id) on delete cascade,
  name         text    not null,
  prefix       text    not null default '',
  suffix       text    not null default '',
  last_num     integer not null default 0,
  pad_len      integer not null default 4,
  voucher_type text    not null default 'SALES',
  is_default   boolean not null default false
);

-- Parties / Ledger accounts
create table if not exists parties (
  id              bigserial primary key,
  company_id      uuid           not null references companies(id) on delete cascade,
  code            text           not null,
  name            text           not null,
  party_type      text           not null default 'BUYER',
  address         text           not null default '',
  city            text           not null default '',
  phone           text           not null default '',
  gstin           text           not null default '',
  pan             text           not null default '',
  state_code      text           not null default '24',
  transport       text           not null default '',
  remarks         text           not null default '',
  opening_balance numeric(15,2)  not null default 0,
  opening_type    text           not null default 'Dr',
  opening_date    date,
  is_active       boolean        not null default true,
  created_at      timestamptz default now()
);

-- Materials / Items
create table if not exists items (
  id            bigserial primary key,
  company_id    uuid          not null references companies(id) on delete cascade,
  code          text          not null,
  name          text          not null,
  colour        text          not null default '',
  plastic_type  text          not null default 'PP',
  form          text          not null default 'Loose',
  quality_grade text          not null default 'A Grade',
  unit          text          not null default 'KG',
  rate          numeric(10,2) not null default 0,
  moisture_pct  numeric(5,2)  not null default 2.5,
  hsn           text          not null default '39151000',
  opening_stock numeric(12,3) not null default 0,
  min_stock     numeric(12,3) not null default 0,
  max_stock     numeric(12,3) not null default 0,
  remarks       text          not null default '',
  is_active     boolean       not null default true,
  created_at    timestamptz default now()
);

-- Vehicles
create table if not exists vehicles (
  id           bigserial primary key,
  company_id   uuid         not null references companies(id) on delete cascade,
  vehicle_no   text         not null,
  owner_name   text         not null default '',
  driver_name  text         not null default '',
  driver_phone text         not null default '',
  capacity_ton numeric(8,2) not null default 0,
  remarks      text         not null default '',
  is_active    boolean      not null default true
);

-- Sales bills
create table if not exists sales (
  id             bigserial primary key,
  company_id     uuid          not null references companies(id) on delete cascade,
  bill_no        text          not null,
  bill_date      date          not null,
  party_id       bigint        references parties(id) on delete set null,
  party_name     text          not null default '',
  transport_name text          not null default '',
  vehicle_no     text          not null default '',
  lr_no          text          not null default '',
  wb_slip_no     text          not null default '',
  eway_bill_no   text          not null default '',
  remarks        text          not null default '',
  subtotal       numeric(15,2) not null default 0,
  gst_percent    numeric(5,2)  not null default 0,
  gst_amount     numeric(15,2) not null default 0,
  charges        numeric(15,2) not null default 0,
  discount       numeric(15,2) not null default 0,
  grand_total    numeric(15,2) not null default 0,
  total_qty      numeric(12,3) not null default 0,
  outstanding    numeric(15,2) not null default 0,
  paid_amount    numeric(15,2) not null default 0,
  is_cancelled   boolean       not null default false,
  created_at     timestamptz default now()
);

create table if not exists sale_items (
  id              bigserial primary key,
  sale_id         bigint        not null references sales(id) on delete cascade,
  item_id         bigint        references items(id) on delete set null,
  item_name       text          not null default '',
  gross_wt        numeric(12,3) not null default 0,
  tare_wt         numeric(12,3) not null default 0,
  net_wt          numeric(12,3) not null default 0,
  moisture_pct    numeric(5,2)  not null default 0,
  moisture_deduct numeric(12,3) not null default 0,
  actual_wt       numeric(12,3) not null default 0,
  quantity        numeric(12,3) not null default 0,
  rate            numeric(10,2) not null default 0,
  amount          numeric(15,2) not null default 0,
  quality_grade   text          not null default 'A Grade',
  remarks         text          not null default '',
  sort_order      integer       not null default 0
);

-- Purchase bills
create table if not exists purchases (
  id             bigserial primary key,
  company_id     uuid          not null references companies(id) on delete cascade,
  bill_no        text          not null,
  bill_date      date          not null,
  party_id       bigint        references parties(id) on delete set null,
  party_name     text          not null default '',
  transport_name text          not null default '',
  vehicle_no     text          not null default '',
  lr_no          text          not null default '',
  remarks        text          not null default '',
  subtotal       numeric(15,2) not null default 0,
  gst_percent    numeric(5,2)  not null default 0,
  gst_amount     numeric(15,2) not null default 0,
  charges        numeric(15,2) not null default 0,
  discount       numeric(15,2) not null default 0,
  grand_total    numeric(15,2) not null default 0,
  total_qty      numeric(12,3) not null default 0,
  outstanding    numeric(15,2) not null default 0,
  paid_amount    numeric(15,2) not null default 0,
  is_cancelled   boolean       not null default false,
  created_at     timestamptz default now()
);

create table if not exists purchase_items (
  id              bigserial primary key,
  purchase_id     bigint        not null references purchases(id) on delete cascade,
  item_id         bigint        references items(id) on delete set null,
  item_name       text          not null default '',
  gross_wt        numeric(12,3) not null default 0,
  tare_wt         numeric(12,3) not null default 0,
  net_wt          numeric(12,3) not null default 0,
  moisture_pct    numeric(5,2)  not null default 0,
  moisture_deduct numeric(12,3) not null default 0,
  actual_wt       numeric(12,3) not null default 0,
  quantity        numeric(12,3) not null default 0,
  rate            numeric(10,2) not null default 0,
  amount          numeric(15,2) not null default 0,
  quality_grade   text          not null default 'A Grade',
  remarks         text          not null default '',
  sort_order      integer       not null default 0
);

-- Payment & Receipt vouchers
create table if not exists payments (
  id              bigserial primary key,
  company_id      uuid          not null references companies(id) on delete cascade,
  voucher_no      text          not null,
  voucher_date    date          not null,
  voucher_type    text          not null default 'RECEIPT',
  party_id        bigint        references parties(id) on delete set null,
  party_name      text          not null default '',
  amount          numeric(15,2) not null default 0,
  narration       text          not null default '',
  cheque_no       text          not null default '',
  cheque_date     date,
  settlement_type text          not null default 'AGAINST_BILL',
  created_at      timestamptz default now()
);

-- Journal vouchers
create table if not exists journals (
  id           bigserial primary key,
  company_id   uuid not null references companies(id) on delete cascade,
  voucher_no   text not null,
  voucher_date date not null,
  narration    text not null default '',
  created_at   timestamptz default now()
);

create table if not exists journal_entries (
  id         bigserial primary key,
  journal_id bigint        not null references journals(id) on delete cascade,
  party_id   bigint        references parties(id) on delete set null,
  party_name text          not null default '',
  dr_amount  numeric(15,2) not null default 0,
  cr_amount  numeric(15,2) not null default 0,
  narration  text          not null default ''
);

-- Sauda / Sales orders
create table if not exists sauda_orders (
  id         bigserial primary key,
  company_id uuid   not null references companies(id) on delete cascade,
  order_no   text   not null,
  order_date date   not null,
  party_id   bigint references parties(id) on delete set null,
  party_name text   not null default '',
  remarks    text   not null default '',
  status     text   not null default 'PENDING',
  created_at timestamptz default now()
);

create table if not exists sauda_items (
  id            bigserial primary key,
  sauda_id      bigint        not null references sauda_orders(id) on delete cascade,
  item_id       bigint        references items(id) on delete set null,
  item_name     text          not null default '',
  order_qty     numeric(12,3) not null default 0,
  delivered_qty numeric(12,3) not null default 0,
  balance_qty   numeric(12,3) not null default 0,
  rate          numeric(10,2) not null default 0,
  remarks       text          not null default ''
);

-- Quotations
create table if not exists quotations (
  id          bigserial primary key,
  company_id  uuid          not null references companies(id) on delete cascade,
  quot_no     text          not null,
  quot_date   date          not null,
  valid_upto  date,
  party_id    bigint        references parties(id) on delete set null,
  party_name  text          not null default '',
  grand_total numeric(15,2) not null default 0,
  remarks     text          not null default '',
  status      text          not null default 'DRAFT',
  created_at  timestamptz default now()
);

create table if not exists quotation_items (
  id            bigserial primary key,
  quotation_id  bigint        not null references quotations(id) on delete cascade,
  item_id       bigint        references items(id) on delete set null,
  item_name     text          not null default '',
  quantity      numeric(12,3) not null default 0,
  rate          numeric(10,2) not null default 0,
  amount        numeric(15,2) not null default 0,
  quality_grade text          not null default 'A Grade'
);

-- Weighbridge slips
create table if not exists weighbridge_slips (
  id              bigserial primary key,
  company_id      uuid          not null references companies(id) on delete cascade,
  slip_no         text          not null,
  slip_date       date          not null,
  slip_type       text          not null default 'INWARD',
  party_id        bigint        references parties(id) on delete set null,
  party_name      text          not null default '',
  item_id         bigint        references items(id) on delete set null,
  item_name       text          not null default '',
  vehicle_no      text          not null default '',
  gross_wt        numeric(12,3) not null default 0,
  tare_wt         numeric(12,3) not null default 0,
  net_wt          numeric(12,3) not null default 0,
  moisture_pct    numeric(5,2)  not null default 0,
  moisture_deduct numeric(12,3) not null default 0,
  actual_wt       numeric(12,3) not null default 0,
  remarks         text          not null default '',
  bill_ref        text          not null default '',
  created_at      timestamptz default now()
);

-- ════════════════════════════════════════════════════════════════
-- STEP 2: ENABLE ROW LEVEL SECURITY ON ALL TABLES
-- ════════════════════════════════════════════════════════════════

alter table profiles          enable row level security;
alter table companies         enable row level security;
alter table sequences         enable row level security;
alter table master_lists      enable row level security;
alter table bill_series       enable row level security;
alter table parties           enable row level security;
alter table items             enable row level security;
alter table vehicles          enable row level security;
alter table sales             enable row level security;
alter table sale_items        enable row level security;
alter table purchases         enable row level security;
alter table purchase_items    enable row level security;
alter table payments          enable row level security;
alter table journals          enable row level security;
alter table journal_entries   enable row level security;
alter table sauda_orders      enable row level security;
alter table sauda_items       enable row level security;
alter table quotations        enable row level security;
alter table quotation_items   enable row level security;
alter table weighbridge_slips enable row level security;

-- ════════════════════════════════════════════════════════════════
-- STEP 3: CREATE ALL POLICIES
-- (profiles exists now, so all cross-table references work)
-- ════════════════════════════════════════════════════════════════

-- Helper: current user's company_id
create or replace function my_company_id()
returns uuid language sql security definer stable as $$
  select company_id from profiles where id = auth.uid() limit 1
$$;

-- Profiles — own row only
create policy "profiles_own" on profiles
  for all using (id = auth.uid());

-- Profiles — allow insert on signup (before profile row exists)
create policy "profiles_insert" on profiles
  for insert with check (id = auth.uid());

-- Companies — user must be linked via profiles
create policy "companies_own" on companies
  for all using (id = my_company_id());

-- Allow company insert (for first-time setup)
create policy "companies_insert" on companies
  for insert with check (true);

-- All company-scoped tables: single reusable pattern
create policy "sequences_own"         on sequences         for all using (company_id = my_company_id());
create policy "master_lists_own"      on master_lists      for all using (company_id = my_company_id());
create policy "bill_series_own"       on bill_series       for all using (company_id = my_company_id());
create policy "parties_own"           on parties           for all using (company_id = my_company_id());
create policy "items_own"             on items             for all using (company_id = my_company_id());
create policy "vehicles_own"          on vehicles          for all using (company_id = my_company_id());
create policy "sales_own"             on sales             for all using (company_id = my_company_id());
create policy "purchases_own"         on purchases         for all using (company_id = my_company_id());
create policy "payments_own"          on payments          for all using (company_id = my_company_id());
create policy "journals_own"          on journals          for all using (company_id = my_company_id());
create policy "sauda_orders_own"      on sauda_orders      for all using (company_id = my_company_id());
create policy "quotations_own"        on quotations        for all using (company_id = my_company_id());
create policy "weighbridge_slips_own" on weighbridge_slips for all using (company_id = my_company_id());

-- Child tables (no company_id column — inherit via parent join)
create policy "sale_items_own" on sale_items for all
  using (sale_id in (select id from sales where company_id = my_company_id()));

create policy "purchase_items_own" on purchase_items for all
  using (purchase_id in (select id from purchases where company_id = my_company_id()));

create policy "journal_entries_own" on journal_entries for all
  using (journal_id in (select id from journals where company_id = my_company_id()));

create policy "sauda_items_own" on sauda_items for all
  using (sauda_id in (select id from sauda_orders where company_id = my_company_id()));

create policy "quotation_items_own" on quotation_items for all
  using (quotation_id in (select id from quotations where company_id = my_company_id()));

-- ════════════════════════════════════════════════════════════════
-- STEP 4: SEQUENCE FUNCTIONS (atomic, concurrency-safe)
-- ════════════════════════════════════════════════════════════════

create or replace function peek_sequence(p_company uuid, p_name text)
returns text language plpgsql security definer as $$
declare r sequences%rowtype;
begin
  select * into r from sequences
  where company_id = p_company and seq_name = p_name;
  if not found then
    return p_name || '-0001';
  end if;
  return r.prefix || lpad((r.last_num + 1)::text, r.pad_len, '0') || r.suffix;
end $$;

create or replace function next_sequence(p_company uuid, p_name text)
returns text language plpgsql security definer as $$
declare
  r       sequences%rowtype;
  new_num integer;
begin
  select * into r from sequences
  where company_id = p_company and seq_name = p_name
  for update;

  if not found then
    insert into sequences (company_id, seq_name, prefix, suffix, last_num, pad_len)
    values (p_company, p_name, '', '', 1, 4);
    return '0001';
  end if;

  new_num := r.last_num + 1;
  update sequences set last_num = new_num
  where company_id = p_company and seq_name = p_name;
  return r.prefix || lpad(new_num::text, r.pad_len, '0') || r.suffix;
end $$;

-- ════════════════════════════════════════════════════════════════
-- STEP 5: PERFORMANCE INDEXES
-- ════════════════════════════════════════════════════════════════

create index if not exists idx_profiles_company      on profiles(company_id);
create index if not exists idx_sales_company_date    on sales(company_id, bill_date desc);
create index if not exists idx_purchases_company_date on purchases(company_id, bill_date desc);
create index if not exists idx_payments_company_date on payments(company_id, voucher_date desc);
create index if not exists idx_parties_company_name  on parties(company_id, name);
create index if not exists idx_items_company_name    on items(company_id, name);
create index if not exists idx_sauda_company_status  on sauda_orders(company_id, status);
create index if not exists idx_wb_company_date       on weighbridge_slips(company_id, slip_date desc);

-- ════════════════════════════════════════════════════════════════
-- DONE. All tables, policies, functions, and indexes created.
-- ════════════════════════════════════════════════════════════════
